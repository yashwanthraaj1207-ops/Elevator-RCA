// src/pages/LiveMonitoring.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore } from "../simulation/store";
import { MaintenanceAuditEntry } from "../simulation/maintenance";
import { useTheme } from "../context/ThemeContext";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import {
  Activity,
  Play,
  Pause,
  RotateCcw,
  Radio,
  Clock,
  AlertTriangle,
  CheckCircle2,
  History,
} from "lucide-react";
import { TimelineReplayBar } from "../components/simulation/TimelineReplayBar";

export const LiveMonitoring: React.FC = () => {
  const { theme } = useTheme();
  const sensors = useElevatorStore((s) => s.sensors);
  const running = useElevatorStore((s) => s.running);
  const time = useElevatorStore((s) => s.time);
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const pauseSimulation = useElevatorStore((s) => s.pauseSimulation);
  const resetSimulation = useElevatorStore((s) => s.resetSimulation);
  const tick = useElevatorStore((s) => s.tick);
  const motion = useElevatorStore((s) => s.motion);
  const floors = useElevatorStore((s) => s.floors);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const maintenance = useElevatorStore((s) => s.maintenance);
  const cumulativeMotorTime = useElevatorStore((s) => s.cumulativeMotorTime);
  const operatingCycles = useElevatorStore((s) => s.operatingCycles);
  const degradationState = useElevatorStore((s) => s.degradationState);
  const simSpeed = useElevatorStore((s) => s.simSpeed);
  const setSimSpeed = useElevatorStore((s) => s.setSimSpeed);

  const [selectedChannel, setSelectedChannel] = useState<string>("Vibration");
  const [timeWindow, setTimeWindow] = useState<number>(30); // points to display

  const currentSensor = sensors[selectedChannel] || Object.values(sensors)[0];

  // Prepare chart series data synchronized by timestamp
  const chartData = (currentSensor?.readings || []).slice(-timeWindow).map((r, index) => {
    // Collect aligned readings across sensors at same relative index
    const dataPoint: Record<string, number | string> = {
      time: `${Math.round(r.timestamp / 1000)}s`,
      [selectedChannel]: Number(r.value.toFixed(2)),
    };

    // Add temperature as secondary reference if viewing another channel
    if (selectedChannel !== "Motor Temperature" && sensors["Motor Temperature"]) {
      const tempReadings = sensors["Motor Temperature"].readings;
      const offset = tempReadings.length - (currentSensor.readings.length - index);
      if (offset >= 0 && tempReadings[offset]) {
        dataPoint["Motor Temperature"] = Number(tempReadings[offset].value.toFixed(1));
      }
    }

    return dataPoint;
  });

  const latestVal = currentSensor?.readings[currentSensor.readings.length - 1]?.value ?? 0;
  const isDark = theme === "dark";

  // Dynamic palette: Sage green, Warm Amber, Restrained Coral (NO BLUE)
  const primaryStroke = isDark ? "#91B7A0" : "#668D74"; // Sage
  const secondaryStroke = isDark ? "#E7AA55" : "#C88735"; // Amber
  const thresholdStroke = isDark ? "#E87568" : "#C84D45"; // Coral
  const gridColor = isDark ? "#2D312A" : "#E2DFD6";
  const axisColor = isDark ? "#7E7D75" : "#95978F";

  // Dynamic calibrated thresholds directly from sensor specifications
  const thresholds = {
    warn: currentSensor?.warnThreshold ?? 50,
    crit: currentSensor?.critThreshold ?? 80,
  };

  return (
    <div className="space-y-5">
      {/* Page Title & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Activity className="w-5 h-5 text-sage" />
            Live Synchronized Telemetry Monitoring
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Real-time condition monitoring with multi-channel threshold analytics and ISO 13374 vibration tracking.
          </p>
        </div>

        {/* Global Simulation Engine Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Speed multiplier */}
          <div className="flex items-center bg-card p-1 rounded-lg border border-border text-xs">
            {([1, 2, 5, 10] as const).map((spd) => (
              <button
                key={spd}
                onClick={() => setSimSpeed(spd)}
                className={`px-2 py-0.5 rounded text-xs font-mono font-bold transition-colors ${
                  simSpeed === spd
                    ? "bg-sage text-charcoal-deep shadow-subtle"
                    : "text-text-secondary hover:text-text-primary hover:bg-surface"
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 bg-card p-1.5 rounded-lg border border-border">
            <div className="flex items-center gap-1.5 px-2 text-xs font-mono text-text-secondary">
              <Radio className="w-3.5 h-3.5 text-sage animate-pulse" />
              <span>Clock: {time}s</span>
            </div>

            {running ? (
              <Button variant="amber" size="sm" onClick={pauseSimulation} className="flex items-center gap-1">
                <Pause className="w-3 h-3" />
                Pause
              </Button>
            ) : (
              <Button variant="primary" size="sm" onClick={startSimulation} className="flex items-center gap-1">
                <Play className="w-3 h-3" />
                Stream
              </Button>
            )}

            <Button variant="secondary" size="sm" onClick={tick} className="text-xs" title="Step 1 Second">
              Step +1s
            </Button>

            <Button variant="ghost" size="sm" onClick={resetSimulation} title="Reset Engine">
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>

          <span className="text-[10px] font-mono px-2 py-1 rounded bg-surface border border-border text-text-muted uppercase font-bold">
            SIMULATED
          </span>
        </div>
      </div>

      {/* Deterministic Replay & Timeline Scrubbing Bar */}
      <TimelineReplayBar />

      {/* Real-time Subsystem Operation Bar */}
      <div className="p-3.5 rounded-xl bg-card border border-border shadow-card flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 pr-3 border-r border-border">
            <span className="text-text-muted font-mono text-[11px]">System Status:</span>
            <span
              className={`px-2 py-0.5 rounded font-mono font-bold text-[11px] uppercase border ${
                motion.operatingState === "SIMULATED_SAFETY_STOP" || motion.operatingState === "ERROR" || motion.operatingState === "FAULT_DETECTED"
                  ? "bg-coral/20 text-coral border-coral/40"
                  : motion.operatingState.includes("DOOR")
                  ? "bg-amber-warm/20 text-amber-warm border-amber-warm/40"
                  : motion.operatingState === "MOVING" || motion.operatingState === "RUNNING"
                  ? "bg-sage/20 text-sage border-sage/40"
                  : "bg-surface text-text-primary border-border"
              }`}
            >
              {motion.operatingState}
            </span>
          </div>

          <div className="flex items-center gap-2 pr-3 border-r border-border">
            <span className="text-text-muted font-mono text-[11px]">Motor Run:</span>
            <span className="font-mono font-bold text-text-primary">
              {cumulativeMotorTime}s
            </span>
          </div>

          <div className="flex items-center gap-2 pr-3 border-r border-border">
            <span className="text-text-muted font-mono text-[11px]">Trips:</span>
            <span className="font-mono font-bold text-text-primary">
              {operatingCycles} cycles
            </span>
          </div>

          {degradationState.stage !== "dormant" && (
            <div className="flex items-center gap-2 pr-3 border-r border-border">
              <span className="text-text-muted font-mono text-[11px]">Wear:</span>
              <span className="font-mono font-bold text-amber-warm">
                {Math.round(degradationState.currentDegradation * 100)}% ({degradationState.stage})
              </span>
            </div>
          )}

          <div className="flex items-center gap-2 pr-3 border-r border-border">
            <span className="text-text-muted font-mono text-[11px]">Floor:</span>
            <span className="font-bold text-text-primary font-mono">
              {floors[motion.currentFloor]?.label ?? motion.currentFloor}
            </span>
            <span className="text-text-muted text-[10px]">
              (Target: {floors[motion.targetFloor]?.label ?? motion.targetFloor})
            </span>
          </div>

          <div className="flex items-center gap-2 pr-3 border-r border-border">
            <span className="text-text-muted font-mono text-[11px]">Velocity:</span>
            <span className="font-mono font-bold text-text-primary">
              {motion.speed.toFixed(2)} m/s
            </span>
            <span className="text-[10px] text-sage font-mono uppercase font-bold">
              [{motion.direction}]
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-text-muted font-mono text-[11px]">Doors:</span>
            <span className="font-mono font-semibold text-text-primary">
              {motion.doorState} ({motion.doorProgress}%)
            </span>
          </div>
        </div>

        {activeFault && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-coral/15 border border-coral/30 text-coral text-[11px] font-semibold">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            <span>Active Incident: {activeFault.name}</span>
          </div>
        )}
      </div>

      {/* Top Row: Metric Cards for All 8 Configured Sensor Channels */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
        {Object.entries(sensors).map(([key, s]) => {
          const val = s.readings[s.readings.length - 1]?.value ?? 0;
          const isSelected = selectedChannel === key;
          const isFault = s.status === "fault";
          const isWarning = s.status === "warning";

          return (
            <button
              key={key}
              onClick={() => setSelectedChannel(key)}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                isSelected
                  ? "bg-surface border-sage shadow-subtle ring-1 ring-sage/30"
                  : "bg-card border-border hover:border-border-strong hover:bg-surface/50"
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono text-text-secondary uppercase truncate">
                  {key}
                </span>
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    isFault ? "bg-coral animate-ping" : isWarning ? "bg-amber-warm" : "bg-sage"
                  }`}
                />
              </div>
              <div
                className={`text-base font-bold font-mono ${
                  isFault ? "text-coral" : isWarning ? "text-amber-warm" : "text-text-primary"
                }`}
              >
                {val.toFixed(2)}
                <span className="text-[10px] font-sans font-normal text-text-muted ml-1">
                  {s.unit}
                </span>
              </div>
              <div className="flex items-center justify-between text-[9px] font-mono text-text-muted mt-0.5">
                <span className="uppercase">{s.status}</span>
                <span>Trip: {s.critThreshold}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Time-Series Visualization Panel */}
      <Card className="p-5 border-border space-y-4">
        {/* Chart Header & Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-text-primary">
                  {selectedChannel} Time-Series Stream
                </h3>
                <span className="text-xs font-mono font-bold text-sage">
                  {latestVal.toFixed(2)} {currentSensor?.unit}
                </span>
              </div>
              <p className="text-[11px] text-text-secondary">
                Synchronized historical window • ISO Threshold envelope active
              </p>
            </div>
          </div>

          {/* Time Window Selectors */}
          <div className="flex items-center gap-1.5 bg-surface p-1 rounded-lg border border-border text-xs">
            <span className="text-[11px] font-mono text-text-muted px-2 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Window:
            </span>
            {[15, 30, 50].map((pts) => (
              <button
                key={pts}
                onClick={() => setTimeWindow(pts)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                  timeWindow === pts
                    ? "bg-card text-text-primary font-bold border border-border shadow-subtle"
                    : "text-text-secondary hover:text-text-primary"
                }`}
              >
                {pts}s
              </button>
            ))}
          </div>
        </div>

        {/* Recharts Canvas */}
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
              <XAxis
                dataKey="time"
                stroke={axisColor}
                tick={{ fontSize: 11, fill: axisColor }}
                tickLine={false}
              />
              <YAxis
                stroke={axisColor}
                tick={{ fontSize: 11, fill: axisColor }}
                tickLine={false}
                domain={["auto", "auto"]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: isDark ? "#252923" : "#FFFFFF",
                  borderColor: isDark ? "#333730" : "#E2DFD6",
                  borderRadius: "8px",
                  fontSize: "12px",
                  color: isDark ? "#F3F0E7" : "#252820",
                  fontFamily: "monospace",
                }}
              />
              <Legend
                wrapperStyle={{
                  fontSize: "11px",
                  paddingTop: "8px",
                  color: isDark ? "#AAA99F" : "#6F7169",
                }}
              />

              {/* Critical Alarm Reference Line */}
              <ReferenceLine
                y={thresholds.crit}
                stroke={thresholdStroke}
                strokeDasharray="4 4"
                label={{
                  value: `Trip Limit (${thresholds.crit})`,
                  fill: thresholdStroke,
                  fontSize: 10,
                  position: "insideTopRight",
                }}
              />

              {/* Primary Channel Line: Sage Green */}
              <Line
                type="monotone"
                dataKey={selectedChannel}
                stroke={primaryStroke}
                strokeWidth={2.2}
                dot={{ r: 2, fill: primaryStroke }}
                activeDot={{ r: 5, fill: primaryStroke }}
                isAnimationActive={false}
              />

              {/* Secondary Cross-Channel Correlation: Warm Amber */}
              {selectedChannel !== "Motor Temperature" && (
                <Line
                  type="monotone"
                  dataKey="Motor Temperature"
                  stroke={secondaryStroke}
                  strokeWidth={1.5}
                  strokeDasharray="3 3"
                  dot={false}
                  isAnimationActive={false}
                />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Statistical Summary Footer */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-border text-xs">
          <div className="p-2.5 rounded-lg bg-surface border border-border">
            <span className="text-[10px] font-mono text-text-muted uppercase">Channel Mean</span>
            <div className="text-sm font-bold font-mono text-text-primary mt-0.5">
              {(chartData.reduce((acc, d) => acc + Number(d[selectedChannel] || 0), 0) / (chartData.length || 1)).toFixed(2)}{" "}
              {currentSensor?.unit}
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-surface border border-border">
            <span className="text-[10px] font-mono text-text-muted uppercase">Peak Recorded</span>
            <div className="text-sm font-bold font-mono text-text-primary mt-0.5">
              {Math.max(...chartData.map((d) => Number(d[selectedChannel] || 0)), 0).toFixed(2)}{" "}
              {currentSensor?.unit}
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-surface border border-border">
            <span className="text-[10px] font-mono text-text-muted uppercase">Trip Limit Threshold</span>
            <div className="text-sm font-bold font-mono text-coral mt-0.5">
              {thresholds.crit} {currentSensor?.unit}
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-surface border border-border">
            <span className="text-[10px] font-mono text-text-muted uppercase">Operating Status</span>
            <div className="text-sm font-bold font-mono text-sage mt-0.5 uppercase">
              {currentSensor?.status || "Normal"}
            </div>
          </div>
        </div>
      </Card>

      {/* Timestamped Live Event Timeline & Diagnostics Log */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-border">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-sage" />
            <h3 className="text-sm font-bold text-text-primary tracking-tight">
              Timestamped Event Timeline & Diagnostics Audit
            </h3>
          </div>
          <span className="text-[10px] font-mono text-text-muted">
            Synchronized with shared audit trail
          </span>
        </div>

        <div className="space-y-2">
          {activeFault && (
            <div className="p-3 rounded-lg bg-coral/10 border border-coral/30 flex items-start justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-coral shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <div className="font-bold text-coral flex items-center gap-2">
                    <span>{activeFault.name}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-coral/20 font-mono uppercase">
                      CRITICAL TRIP
                    </span>
                  </div>
                  <p className="text-text-secondary text-[11px] mt-0.5">
                    Target: {activeFault.affectedComponent.replace(/_/g, " ")} • Safety interlocks engaged, cabin halted.
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono text-text-muted shrink-0">
                T+{time}s
              </span>
            </div>
          )}

          {maintenance.auditTrail.length > 0 ? (
            maintenance.auditTrail.slice(-5).reverse().map((entry: MaintenanceAuditEntry) => (
              <div
                key={entry.id}
                className="p-2.5 rounded-lg bg-surface border border-border flex items-start justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-2.5 min-w-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-sage shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <div className="font-semibold text-text-primary flex items-center gap-2">
                      <span className="font-mono text-sage">{entry.id}</span>
                      <span className="text-text-muted">•</span>
                      <span className="truncate">{entry.action}</span>
                    </div>
                    <div className="text-[11px] text-text-muted mt-0.5 font-mono">
                      Actor: {entry.actor} • State: {entry.toState}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-text-muted shrink-0">
                  {new Date(entry.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))
          ) : (
            <div className="p-3 rounded-lg bg-surface border border-border flex items-center justify-between text-xs text-text-secondary">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-sage" />
                <span>System operating nominally. All channels within ISO 18738 baseline limits.</span>
              </div>
              <span className="font-mono text-[10px] text-text-muted">Live Active</span>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default LiveMonitoring;
