import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Box,
  Activity,
  Search,
  FlaskConical,
  Wrench,
  History,
  FileText,
  Database,
  Settings,
  ChevronLeft,
  ChevronRight,
  Shield,
  Clock,
  Radio,
  Compass,
  Sparkles,
  BookOpen,
  LogOut,
  ExternalLink,
  Globe,
} from "lucide-react";
import { useElevatorStore } from "../simulation/store";

interface NavItem {
  to: string;
  label: string;
  icon: React.ReactNode;
  badge?: string;
}

const navItems: NavItem[] = [
  { to: "/overview", label: "Overview", icon: <LayoutDashboard className="w-4 h-4" /> },
  { to: "/digital-twin", label: "Digital Twin", icon: <Box className="w-4 h-4" /> },
  { to: "/live-monitoring", label: "Live Monitoring", icon: <Activity className="w-4 h-4" /> },
  { to: "/investigation", label: "Fault Analysis", icon: <Search className="w-4 h-4" /> },
  { to: "/fault-lab", label: "Fault Lab", icon: <FlaskConical className="w-4 h-4" /> },
  { to: "/guided-investigation", label: "Guided Walkthrough", icon: <Compass className="w-4 h-4 text-sage" /> },
  { to: "/judge-demo", label: "Judge Demo Mode", icon: <Sparkles className="w-4 h-4 text-amber-warm" /> },
  { to: "/methodology", label: "Methodology", icon: <BookOpen className="w-4 h-4" /> },
  { to: "/maintenance", label: "Maintenance", icon: <Wrench className="w-4 h-4" /> },
  { to: "/records", label: "Event History", icon: <History className="w-4 h-4" /> },
  { to: "/report", label: "RCA Report", icon: <FileText className="w-4 h-4" /> },
  { to: "/storage", label: "Storage & Retention", icon: <Database className="w-4 h-4" /> },
  { to: "/settings", label: "Settings", icon: <Settings className="w-4 h-4" /> },
  { to: "/login", label: "Engineer Access", icon: <Shield className="w-4 h-4 text-sage" /> },
];

export const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const running = useElevatorStore((s) => s.running);
  const time = useElevatorStore((s) => s.time);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const assetId = useElevatorStore((s) => s.assetId);
  const session = useElevatorStore((s) => s.maintenanceSession);
  const logoutMaintenance = useElevatorStore((s) => s.logoutMaintenance);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <aside
      className={`relative bg-sidebar border-r border-border flex flex-col transition-all duration-300 select-none z-30 ${
        collapsed ? "w-16" : "w-60"
      }`}
    >
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-3.5 border-b border-border">
        <div className="flex items-center gap-2.5 overflow-hidden">
          {/* Logo Mark: Industrial Hexagon Badge */}
          <div className="w-8 h-8 rounded-lg bg-surface border border-border flex items-center justify-center shrink-0 shadow-subtle">
            <div className="w-4 h-4 rounded-sm bg-sage flex items-center justify-center">
              <span className="text-[10px] font-black text-[#171916] font-mono leading-none">
                E
              </span>
            </div>
          </div>

          {!collapsed && (
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-bold tracking-tight text-text-primary font-mono truncate">
                ELEVATOR<span className="text-sage">·RCA</span>
              </span>
              <span className="text-[10px] text-text-secondary tracking-wider uppercase font-medium">
                Industrial Diagnostics
              </span>
            </div>
          )}
        </div>

        {/* Collapse Toggle Button */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 rounded-md text-text-secondary hover:text-text-primary hover:bg-surface border border-transparent hover:border-border transition-colors"
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 py-3 px-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            title={collapsed ? item.label : undefined}
            className={({ isActive }) =>
              `flex items-center gap-3 px-2.5 py-2 rounded-lg text-xs font-medium transition-all group ${
                isActive
                  ? "bg-surface text-text-primary border border-border shadow-subtle font-semibold"
                  : "text-text-secondary hover:text-text-primary hover:bg-surface/50 border border-transparent"
              } ${collapsed ? "justify-center px-0" : ""}`
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={`transition-colors shrink-0 ${
                    isActive ? "text-sage" : "text-text-muted group-hover:text-text-primary"
                  }`}
                >
                  {item.icon}
                </span>

                {!collapsed && (
                  <span className="truncate flex-1">{item.label}</span>
                )}

                {!collapsed && item.to === "/investigation" && activeFault && (
                  <span className="w-2 h-2 rounded-full bg-coral animate-ping" />
                )}

                {isActive && !collapsed && (
                  <span className="w-1.5 h-1.5 rounded-full bg-sage" />
                )}
              </>
            )}
          </NavLink>
        ))}

        {/* Project Explanation Website Link */}
        <a
          href="https://rca-elevator.netlify.app/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold text-sage hover:bg-sage/15 border border-sage/30 transition-all group mt-2 shadow-subtle"
          title="ELEVATOR-RCA | Explainable Causal AI for Intelligent Elevator Fault Diagnosis"
        >
          <Globe className="w-4 h-4 shrink-0 text-sage" />
          {!collapsed && (
            <>
              <span className="truncate">Project Website</span>
              <ExternalLink className="w-3 h-3 ml-auto opacity-70 group-hover:opacity-100" />
            </>
          )}
        </a>
      </nav>

      {/* Footer System & Simulation Status */}
      <div className="p-3 border-t border-border bg-sidebar/50">
        {!collapsed ? (
          <div className="space-y-2">
            <div className="p-2.5 rounded-lg bg-surface border border-border text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-text-secondary">
                  Telemetry Engine
                </span>
                <span
                  className={`inline-flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${
                    running
                      ? "bg-sage/15 text-sage border border-sage/30"
                      : "bg-surface text-text-muted border border-border"
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      running ? "bg-sage animate-pulse" : "bg-text-muted"
                    }`}
                  />
                  {running ? "ONLINE" : "STANDBY"}
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-text-primary">
                <span className="flex items-center gap-1 text-text-secondary">
                  <Clock className="w-3 h-3 text-text-muted" />
                  Clock:
                </span>
                <span className="font-semibold">{formatTime(time)}</span>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-text-primary">
                <span className="flex items-center gap-1 text-text-secondary">
                  <Radio className="w-3 h-3 text-text-muted" />
                  Target:
                </span>
                <span className="font-semibold text-sage">{assetId}</span>
              </div>
            </div>

            {session ? (
              <div className="flex items-center justify-between pt-1 px-1">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-7 h-7 rounded-full bg-sage/20 border border-sage/40 flex items-center justify-center text-xs font-mono font-bold text-sage shrink-0">
                    {session.user.fullName.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-medium text-text-primary truncate">
                      {session.user.fullName}
                    </span>
                    <span className="text-[10px] font-mono text-sage uppercase font-bold truncate">
                      {session.user.role}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    logoutMaintenance();
                    navigate("/login");
                  }}
                  className="p-1 rounded text-text-muted hover:text-coral hover:bg-surface transition-colors"
                  title="Log out"
                  aria-label="Log out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <NavLink
                to="/login"
                className="flex items-center gap-2 p-1.5 rounded-lg bg-surface hover:bg-surface-hover border border-border text-xs text-text-secondary hover:text-text-primary transition-colors"
              >
                <div className="w-6 h-6 rounded-md bg-sage/15 flex items-center justify-center text-sage">
                  <Shield className="w-3.5 h-3.5" />
                </div>
                <div className="flex flex-col min-w-0 text-left">
                  <span className="text-xs font-semibold text-text-primary">Sign In</span>
                  <span className="text-[10px] text-text-muted">Engineer Access</span>
                </div>
              </NavLink>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 py-1">
            <div
              className={`w-2 h-2 rounded-full ${running ? "bg-sage animate-pulse" : "bg-text-muted"}`}
              title={`Simulation: ${running ? "Running" : "Standby"} (${formatTime(time)})`}
            />
            <Shield className="w-4 h-4 text-text-muted" />
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
