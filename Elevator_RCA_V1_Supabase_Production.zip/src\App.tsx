// src/App.tsx
import React from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { FaultAlertModal } from "./components/modals/FaultAlertModal";
import { ExternalLink, Globe } from "lucide-react";

export const App: React.FC = () => {
  return (
    <div className="flex h-screen w-screen bg-app text-text-primary overflow-hidden transition-colors">
      <FaultAlertModal />
      <Sidebar />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Top Project Explanation Banner */}
        <div className="bg-surface/90 backdrop-blur-sm border-b border-border px-4 py-1.5 text-xs flex items-center justify-between shrink-0 select-none">
          <div className="flex items-center gap-2 text-text-secondary truncate">
            <span className="px-1.5 py-0.5 rounded bg-sage/15 text-sage text-[10px] font-mono font-bold uppercase tracking-wider border border-sage/30 shrink-0">
              Project Explanation
            </span>
            <span className="font-medium text-text-primary truncate">
              ELEVATOR-RCA — Explainable Causal AI for Intelligent Elevator Fault Diagnosis
            </span>
          </div>

          <a
            href="https://rca-elevator.netlify.app/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-sage hover:text-sage/80 font-bold text-xs shrink-0 transition-colors pl-3 group"
            title="Open ELEVATOR-RCA project explanation website"
          >
            <Globe className="w-3.5 h-3.5" />
            <span className="group-hover:underline">Visit Project Website</span>
            <ExternalLink className="w-3 h-3 opacity-70 group-hover:opacity-100" />
          </a>
        </div>

        <Header />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-app transition-colors">
          <div className="max-w-7xl mx-auto w-full space-y-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
