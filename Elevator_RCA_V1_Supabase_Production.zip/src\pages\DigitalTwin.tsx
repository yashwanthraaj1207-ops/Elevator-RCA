// src/pages/DigitalTwin.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { ModelViewer, MODEL_ASSET_PATH } from "../components/digitalTwin/ModelViewer";
import {
  ComponentId,
  normalizeComponentId,
} from "../components/digitalTwin/componentMapping";
import { useElevatorStore, ALL_FAULT_SCENARIOS } from "../simulation/store";
import { evaluateComponentHealth } from "../simulation/componentHealth";
import {
  AlertTriangle,
  CheckCircle,
  Cpu,
  Layers,
  Wrench,
  Activity,
  Box,
  FileCheck,
  Zap,
  Sliders,
  Clock,
  ShieldCheck,
  TrendingDown,
  Info,
} from "lucide-react";
import { TimelineReplayBar } from "../components/simulation/TimelineReplayBar";

export const DigitalTwin: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"inspector" | "diagnostics" | "asset">("inspector");
  const [showInspectorPanel, setShowInspectorPanel] = useState<boolean>(true);

  const selectedComponent = useElevatorStore((s) => s.selectedComponent);
  const selectComponent = useElevatorStore((s) => s.selectComponent);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const diagnostic = useElevatorStore((s) => s.diagnostic);
  const injectFault = useElevatorStore((s) => s.injectFault);
  const clearFault = useElevatorStore((s) => s.clearFault);
  const sensors = useElevatorStore((s) => s.sensors);
  const simTime = useElevatorStore((s) => s.time);

  const selectedId = (normalizeComponentId(selectedComponent) || "bearing_main") as ComponentId;

  // Evaluate real-time component health, RUL, and sensor metrics (Feature 3 & 6)
  const health = evaluateComponentHealth(selectedId, sensors, activeFault, simTime);

  const handleSelectHypothesis = (componentId: string) => {
    const canonical = normalizeComponentId(componentId);
    if (canonical) {
      selectComponent(canonical);
      setActiveTab("inspector");
    }
  };

  const getHealthBadgeStyle = (state: "NORMAL" | "WARNING" | "FAULT") => {
    switch (state) {
      case "NORMAL":
        return "bg-sage/15 text-sage border-sage/30";
      case "WARNING":
        return "bg-amber-warm/15 text-amber-warm border-amber-warm/30";
      case "FAULT":
        return "bg-coral/15 text-coral border-coral/30";
    }
  };

  return (
    <div className="space-y-4">
      {/* Page Title & Breadcrumbs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Box className="w-5 h-5 text-sage" />
            Digital Twin 3D Engineering Workspace
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Direct mesh raycast selection, exploded assembly inspection, and live component health prognostics.
          </p>
        </div>

        {/* Quick Fault Scenario Selector (Feature 4 & 5) */}
        <div className="flex flex-wrap items-center gap-1.5 bg-card p-1.5 rounded-lg border border-border">
          <span className="text-[11px] font-mono text-text-secondary px-2 flex items-center gap-1">
            <Sliders className="w-3 h-3 text-text-muted" />
            Scenario:
          </span>
          <button
            onClick={() => injectFault(ALL_FAULT_SCENARIOS.bearing_degradation)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
              activeFault?.id === "scenario_bearing_degradation"
                ? "bg-coral/20 text-coral border border-coral/60 font-semibold"
                : "bg-surface hover:bg-surface-hover text-text-primary border border-border"
            }`}
          >
            Bearing Fault
          </button>
          <button
            onClick={() => injectFault(ALL_FAULT_SCENARIOS.motor_overheating)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
              activeFault?.id === "scenario_motor_overheating"
                ? "bg-coral/20 text-coral border border-coral/60 font-semibold"
                : "bg-surface hover:bg-surface-hover text-text-primary border border-border"
            }`}
          >
            Motor Overheat
          </button>
          <button
            onClick={() => injectFault(ALL_FAULT_SCENARIOS.door_mechanism_fault)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
              activeFault?.id === "scenario_door_mechanism_fault"
                ? "bg-amber-warm/20 text-amber-warm border border-amber-warm/60 font-semibold"
                : "bg-surface hover:bg-surface-hover text-text-primary border border-border"
            }`}
          >
            Door Obstruction
          </button>
          <button
            onClick={() => injectFault(ALL_FAULT_SCENARIOS.brake_related_fault)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
              activeFault?.id === "scenario_brake_related_fault"
                ? "bg-coral/20 text-coral border border-coral/60 font-semibold"
                : "bg-surface hover:bg-surface-hover text-text-primary border border-border"
            }`}
          >
            Brake Slip
          </button>
          <button
            onClick={() => injectFault(ALL_FAULT_SCENARIOS.mechanical_vibration)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
              activeFault?.id === "scenario_mechanical_vibration"
                ? "bg-amber-warm/20 text-amber-warm border border-amber-warm/60 font-semibold"
                : "bg-surface hover:bg-surface-hover text-text-primary border border-border"
            }`}
          >
            Rail Vibration
          </button>
          <button
            onClick={() => injectFault(ALL_FAULT_SCENARIOS.encoder_fault)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
              activeFault?.id === "scenario_encoder_fault"
                ? "bg-coral/20 text-coral border border-coral/60 font-semibold"
                : "bg-surface hover:bg-surface-hover text-text-primary border border-border"
            }`}
          >
            Encoder Fault
          </button>
          {activeFault && (
            <button
              onClick={clearFault}
              className="px-2.5 py-1 text-xs rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary ml-1 border border-border"
            >
              Clear
            </button>
          )}

          {/* Toggle Inspector Sidebar */}
          <div className="h-4 w-[1px] bg-border mx-1" />
          <button
            onClick={() => setShowInspectorPanel((prev) => !prev)}
            className={`px-2.5 py-1 text-xs rounded-md transition-colors flex items-center gap-1.5 border ${
              showInspectorPanel
                ? "bg-surface hover:bg-surface-hover text-text-primary border-border"
                : "bg-sage/20 text-sage border-sage/60 font-semibold"
            }`}
            title={showInspectorPanel ? "Hide side inspector for widescreen 3D viewing" : "Open side inspector panel"}
          >
            <Cpu className="w-3.5 h-3.5 text-sage" />
            <span>{showInspectorPanel ? "Hide Panel" : "Show Panel"}</span>
          </button>
        </div>
      </div>

      {/* Deterministic Replay & Timeline Scrubbing Bar */}
      <TimelineReplayBar />

      {/* Main Grid: 3D Viewport & Component Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 3D Viewport Container (Feature 1 & Feature 2) */}
        <div className={`${showInspectorPanel ? "lg:col-span-8" : "col-span-12"} flex flex-col h-[750px] transition-all`}>
          <ModelViewer
            className="flex-1"
            selectedComponent={selectedId}
            onSelectComponent={(id) => selectComponent(id)}
            showFloorShaft={true}
            showFloatingInspector={!showInspectorPanel}
          />
        </div>

        {/* Right Inspection & Diagnostic Sidebar */}
        {showInspectorPanel && (
          <div className="lg:col-span-4 flex flex-col h-[750px] space-y-3">
            {/* Tabs */}
            <div className="flex border-b border-border bg-card rounded-t-xl p-1 gap-1">
            <button
              onClick={() => setActiveTab("inspector")}
              className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === "inspector"
                  ? "bg-surface text-text-primary font-semibold border border-border shadow-subtle"
                  : "text-text-secondary hover:text-text-primary"
              }`}
            >
              <Cpu className="w-3.5 h-3.5 text-sage" />
              Health Inspector
            </button>
            <button
              onClick={() => setActiveTab("diagnostics")}
              className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === "diagnostics"
                  ? "bg-surface text-text-primary font-semibold border border-border shadow-subtle"
                  : "text-text-secondary hover:text-text-primary"
              }`}
            >
              <Activity className="w-3.5 h-3.5 text-amber-warm" />
              Diagnostic RCA
              {diagnostic?.hypotheses && diagnostic.hypotheses.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-coral animate-ping" />
              )}
            </button>
            <button
              onClick={() => setActiveTab("asset")}
              className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === "asset"
                  ? "bg-surface text-text-primary font-semibold border border-border shadow-subtle"
                  : "text-text-secondary hover:text-text-primary"
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-text-muted" />
              GLB Diagnostics
            </button>
          </div>

          {/* Tab 1: Detailed Component Health Inspector (Feature 3 & Feature 6) */}
          {activeTab === "inspector" && (
            <Card className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* Header */}
              <div className="flex items-start justify-between border-b border-border pb-3">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-sage font-semibold">
                    {health.category}
                  </span>
                  <h3 className="text-base font-bold text-text-primary flex items-center gap-2">
                    {health.name}
                  </h3>
                  <div className="text-[11px] font-mono text-text-muted mt-0.5">
                    Operating Hours: {health.operatingHours.toLocaleString()} hrs
                  </div>
                </div>

                <span
                  className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold uppercase border ${getHealthBadgeStyle(
                    health.operationalState
                  )}`}
                >
                  {health.operationalState}
                </span>
              </div>

              {/* Health Score & Illustrative RUL Cards (Feature 3 & 6) */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-lg bg-surface border border-border space-y-1">
                  <div className="text-[10px] font-mono text-text-muted uppercase flex items-center justify-between">
                    <span>Health Index</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-sage" />
                  </div>
                  <div className="text-2xl font-bold font-mono text-text-primary flex items-baseline gap-1">
                    <span>{health.healthScore}</span>
                    <span className="text-xs text-text-secondary">/ 100</span>
                  </div>
                  <div className="w-full bg-card h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        health.healthScore >= 75
                          ? "bg-sage"
                          : health.healthScore >= 50
                          ? "bg-amber-warm"
                          : "bg-coral"
                      }`}
                      style={{ width: `${health.healthScore}%` }}
                    />
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-surface border border-border space-y-1">
                  <div className="text-[10px] font-mono text-text-muted uppercase flex items-center justify-between">
                    <span>Estimated RUL</span>
                    <Clock className="w-3.5 h-3.5 text-amber-warm" />
                  </div>
                  <div className="text-lg font-bold font-mono text-text-primary leading-tight">
                    {health.rulValue.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-text-secondary font-mono">
                    {health.rulUnit} ({health.uncertaintyRange})
                  </div>
                  <div className="text-[10px] text-sage font-mono">
                    Conf: {health.confidencePercent}%
                  </div>
                </div>
              </div>

              {/* Notice Banner */}
              <div className="p-2 rounded bg-surface/70 border border-border text-[10px] text-text-muted flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 text-sage shrink-0 mt-0.5" />
                <span>
                  {health.modelDisclosures.notice} Degradation: {health.modelDisclosures.degradationMethod}.
                </span>
              </div>

              {/* 10-Point Health History Sparkline (Feature 3) */}
              <div>
                <div className="text-xs font-semibold text-text-primary uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Health Score History (Rolling Trend)</span>
                  <TrendingDown className="w-3.5 h-3.5 text-text-muted" />
                </div>
                <div className="p-2.5 rounded-lg bg-surface border border-border">
                  <div className="flex items-end justify-between gap-1 h-16 pt-2">
                    {health.healthHistory.map((pt, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                        <div
                          className={`w-full rounded-t transition-all ${
                            pt.score >= 75 ? "bg-sage/70" : pt.score >= 50 ? "bg-amber-warm/70" : "bg-coral/70"
                          }`}
                          style={{ height: `${pt.score}%` }}
                          title={`${pt.timestamp}: ${pt.score}%`}
                        />
                        <span className="text-[8px] font-mono text-text-muted">{pt.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Component Associated Sensors with Individual Engineering Units (Feature 3) */}
              <div>
                <h4 className="text-xs font-semibold text-text-primary uppercase tracking-wider mb-2">
                  Monitored Telemetry Channels & Thresholds
                </h4>
                <div className="space-y-2">
                  {health.sensors.map((s) => (
                    <div
                      key={s.name}
                      className={`p-2.5 rounded-lg border text-xs space-y-1.5 ${
                        s.status === "fault"
                          ? "bg-coral/10 border-coral/40"
                          : s.status === "warning"
                          ? "bg-amber-warm/10 border-amber-warm/40"
                          : "bg-surface border-border"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-semibold text-text-primary">{s.name}</span>
                          <span className="text-[10px] text-text-muted ml-1.5 font-mono">
                            Nominal: {s.baseline} {s.unit}
                          </span>
                        </div>
                        <div className="text-right font-mono">
                          <span className={`font-bold text-sm ${s.status === "fault" ? "text-coral" : s.status === "warning" ? "text-amber-warm" : "text-text-primary"}`}>
                            {s.currentValue.toFixed(2)} {s.unit}
                          </span>
                        </div>
                      </div>

                      {/* Threshold Envelope Bar */}
                      <div className="flex items-center gap-2 text-[10px] font-mono text-text-muted">
                        <span>Limit: {s.critThreshold} {s.unit}</span>
                        <div className="flex-1 bg-card h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${s.status === "fault" ? "bg-coral" : s.status === "warning" ? "bg-amber-warm" : "bg-sage"}`}
                            style={{
                              width: `${Math.min(100, Math.max(5, (s.currentValue / s.critThreshold) * 100))}%`,
                            }}
                          />
                        </div>
                        <span className={s.status === "fault" ? "text-coral font-bold" : "text-sage"}>
                          {s.deviationPercent > 0 ? `+${s.deviationPercent}%` : `${s.deviationPercent}%`}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Detected Anomalies & Evidence (Feature 3 & 5) */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-text-primary uppercase tracking-wider">
                  Condition Assessment & Evidence
                </h4>
                <div className="p-3 rounded-lg bg-surface border border-border space-y-1.5 text-xs">
                  {health.evidenceText.map((ev, i) => (
                    <div key={i} className="flex items-start gap-1.5 text-text-secondary">
                      <span className="text-sage mt-0.5">•</span>
                      <span>{ev}</span>
                    </div>
                  ))}
                  {health.possibleRootCause && (
                    <div className="pt-2 border-t border-border mt-2">
                      <div className="text-[10px] font-mono text-coral font-semibold uppercase">
                        Identified Root Cause:
                      </div>
                      <div className="text-text-primary font-medium mt-0.5">
                        {health.possibleRootCause}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Recommended Action */}
              <div className="border-t border-border pt-3">
                <h4 className="text-xs font-semibold text-text-primary uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Wrench className="w-3.5 h-3.5 text-sage" />
                  Recommended Action
                </h4>
                <p className="text-xs text-text-secondary leading-relaxed bg-surface p-2.5 rounded-lg border border-border">
                  {health.recommendedAction}
                </p>
                <div className="text-[10px] font-mono text-text-muted mt-1 text-right">
                  Last Simulated Inspection: {health.lastSimulatedInspection}
                </div>
              </div>
            </Card>
          )}

          {/* Tab 2: Diagnostic RCA Hypotheses */}
          {activeTab === "diagnostics" && (
            <Card className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-border pb-2">
                <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-amber-warm" />
                  Explainable Root Cause Analysis
                </h3>
                <span className="text-[10px] font-mono text-text-muted">ISO 13374 Pipeline</span>
              </div>

              {diagnostic?.hypotheses && diagnostic.hypotheses.length > 0 ? (
                <div className="space-y-3">
                  {diagnostic.hypotheses.map((hyp) => {
                    const isTop = hyp.rank === 1;
                    return (
                      <div
                        key={hyp.id}
                        onClick={() => handleSelectHypothesis(hyp.componentId)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all ${
                          isTop
                            ? "bg-card border-coral/50 shadow-elevated"
                            : "bg-surface border-border hover:border-text-secondary"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="font-mono text-[10px] text-text-muted font-bold">
                            RANK #{hyp.rank}
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                              isTop ? "bg-coral/20 text-coral" : "bg-amber-warm/20 text-amber-warm"
                            }`}
                          >
                            {(hyp.confidence * 100).toFixed(0)}% Confidence
                          </span>
                        </div>

                        <h4 className="text-xs font-bold text-text-primary mt-1">{hyp.title}</h4>
                        <p className="text-[11px] text-text-secondary mt-0.5 leading-relaxed">
                          {hyp.description}
                        </p>

                        {/* Causal Chain */}
                        {hyp.causalChain && hyp.causalChain.length > 0 && (
                          <div className="mt-2 p-2 rounded bg-app/60 border border-border space-y-1">
                            <span className="text-[9px] font-mono uppercase text-sage font-semibold">
                              Causal Chain:
                            </span>
                            {hyp.causalChain.map((step, idx) => (
                              <div key={idx} className="text-[10px] text-text-primary font-mono">
                                {step}
                              </div>
                            ))}
                          </div>
                        )}

                        {hyp.recommendedAction && (
                          <div className="text-[11px] text-text-primary mt-2 flex items-start gap-1">
                            <Zap className="w-3 h-3 text-sage mt-0.5 shrink-0" />
                            <span>
                              <strong>Action:</strong> {hyp.recommendedAction}
                            </span>
                          </div>
                        )}

                        <div className="mt-2 text-right">
                          <span className="text-[10px] text-sage font-medium hover:underline">
                            Click to select & explode component in 3D &rarr;
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center p-6 text-text-secondary">
                  <CheckCircle className="w-8 h-8 text-sage mb-2" />
                  <p className="text-sm font-semibold text-text-primary">System Normal</p>
                  <p className="text-xs mt-1">
                    No active diagnostic faults. Use the scenario buttons above to simulate bearing wear, door obstruction, or brake slip.
                  </p>
                </div>
              )}
            </Card>
          )}

          {/* Tab 3: Model Preparation Diagnostics (Feature 7) */}
          {activeTab === "asset" && (
            <Card className="flex-1 overflow-y-auto p-4 space-y-3">
              <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider flex items-center gap-1.5 border-b border-border pb-2">
                <FileCheck className="w-4 h-4 text-sage" />
                GLB Model Diagnostics & Blender Preparation
              </h3>

              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-lg bg-surface border border-border">
                  <div className="text-[10px] font-mono text-text-muted uppercase">
                    Asset File & Dimensions
                  </div>
                  <div className="font-mono text-text-primary break-all">{MODEL_ASSET_PATH}</div>
                  <div className="text-[10px] text-sage mt-0.5 font-mono">
                    Triangles: 265,258 • Vertices: 131,975 • Size: 6.06 MB
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-amber-warm/40 bg-amber-warm/10 text-amber-warm space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    Single Merged Mesh Identified in Raw GLB
                  </div>
                  <p className="text-[11px] text-text-secondary leading-relaxed">
                    Source file contains 1 unified primitive (<code className="font-mono font-bold text-text-primary">Node [0]: "Mesh"</code>). At load time, ELEVATOR-RCA's geometric segmentation engine parses triangle centroids and partitions them into 8 discrete physical subassemblies for raycast selection and exploded view.
                  </p>
                </div>

                {/* Subassembly Breakdown Table */}
                <div className="p-2.5 rounded-lg bg-surface border border-border space-y-2">
                  <div className="text-[10px] font-mono text-text-muted uppercase">
                    Segmented Subassemblies (100% Geometry Accounted)
                  </div>
                  <div className="space-y-1 font-mono text-[11px]">
                    <div className="flex justify-between text-text-primary">
                      <span>• Bearing Assembly</span>
                      <span className="text-sage font-bold">27,148 tris (10.2%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Brake Calipers</span>
                      <span className="text-sage font-bold">11,799 tris (4.4%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Traction Motor</span>
                      <span className="text-sage font-bold">19,809 tris (7.5%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Car Door System</span>
                      <span className="text-sage font-bold">20,480 tris (7.7%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Cabin Car Body</span>
                      <span className="text-sage font-bold">111,199 tris (41.9%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Counterweight</span>
                      <span className="text-sage font-bold">13,823 tris (5.2%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Guide Rails</span>
                      <span className="text-sage font-bold">26,741 tris (10.1%)</span>
                    </div>
                    <div className="flex justify-between text-text-primary">
                      <span>• Frame & Bedplate</span>
                      <span className="text-text-muted font-bold">34,259 tris (12.9%)</span>
                    </div>
                  </div>
                </div>

                {/* Step-by-Step Blender Preparation Plan (Feature 7) */}
                <div className="p-3 rounded-lg bg-surface border border-border space-y-2">
                  <div className="text-[10px] font-mono text-text-muted uppercase font-bold">
                    CAD/BIM Pipeline: Blender Model Preparation Plan
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-text-secondary leading-relaxed">
                    <li>Import <code className="font-mono text-text-primary">Elevator D1.glb</code> via File &rarr; Import &rarr; glTF 2.0.</li>
                    <li>Enter Edit Mode (<kbd className="font-mono text-text-primary">Tab</kbd>), select all (<kbd className="font-mono text-text-primary">A</kbd>), press <kbd className="font-mono text-text-primary">P</kbd> &rarr; <em>By Loose Parts</em>.</li>
                    <li>Select separated components in Object Mode &rarr; <em>Object &rarr; Set Origin &rarr; Origin to Geometry</em>.</li>
                    <li>Rename outliner nodes to canonical keys (<code className="font-mono text-text-primary">bearing_main</code>, <code className="font-mono text-text-primary">traction_motor</code>, <code className="font-mono text-text-primary">brake_assembly</code>, etc.).</li>
                    <li>Export as glTF 2.0 Binary (<code className="font-mono text-text-primary">NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb</code>) with custom properties enabled.</li>
                  </ol>
                </div>
              </div>
            </Card>
          )}
        </div>
        )}
      </div>
    </div>
  );
};

export default DigitalTwin;
