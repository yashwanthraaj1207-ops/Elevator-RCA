// src/pages/FaultLab.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore, PRESET_FAULTS, FaultScenario } from "../simulation/store";
import { COMPONENT_CATALOG, ComponentId } from "../components/digitalTwin/componentMapping";
import {
  FlaskConical,
  AlertTriangle,
  CheckCircle2,
  Play,
  RotateCcw,
  ArrowRight,
  Info,
  Radio,
  Timer,
  Activity,
  Gauge,
  TrendingUp,
  Zap,
  BarChart3,
  RefreshCw,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { executeAutomatedBenchmark, BenchmarkReport } from "../simulation/benchmark";

function formatTime(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function formatDelayLabel(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.round(seconds / 60);
  return `${m}m`;
}

export const FaultLab: React.FC = () => {
  const navigate = useNavigate();
  const activeFault = useElevatorStore((s) => s.activeFault);
  const injectFault = useElevatorStore((s) => s.injectFault);
  const clearFault = useElevatorStore((s) => s.clearFault);
  const selectComponent = useElevatorStore((s) => s.selectComponent);
  const demoCountdown = useElevatorStore((s) => s.demoCountdown);
  const demoPendingFault = useElevatorStore((s) => s.demoPendingFault);
  const startDemoCountdown = useElevatorStore((s) => s.startDemoCountdown);
  const cancelDemoCountdown = useElevatorStore((s) => s.cancelDemoCountdown);

  const cumulativeMotorTime = useElevatorStore((s) => s.cumulativeMotorTime);
  const operatingCycles = useElevatorStore((s) => s.operatingCycles);
  const degradationConfig = useElevatorStore((s) => s.degradationConfig);
  const degradationState = useElevatorStore((s) => s.degradationState);
  const startDegradationRun = useElevatorStore((s) => s.startDegradationRun);
  const cancelDegradation = useElevatorStore((s) => s.cancelDegradation);
  const simSpeed = useElevatorStore((s) => s.simSpeed);
  const setSimSpeed = useElevatorStore((s) => s.setSimSpeed);
  const running = useElevatorStore((s) => s.running);
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const pauseSimulation = useElevatorStore((s) => s.pauseSimulation);

  // Local state for degradation settings & delayed fault scheduling
  const [selectedScenarioKey, setSelectedScenarioKey] = useState<string>("bearing_degradation");
  const [triggerMetric, setTriggerMetric] = useState<"motor_time" | "operating_cycles" | "sim_time">("motor_time");
  const [triggerThreshold, setTriggerThreshold] = useState<number>(120); // 2 minutes default
  const [rampDuration, setRampDuration] = useState<number>(20);
  const [scheduledDelaySeconds, setScheduledDelaySeconds] = useState<number>(120); // 2 minutes of elevator usage
  const [benchmarkReport, setBenchmarkReport] = useState<BenchmarkReport | null>(null);
  const [isBenchmarkRunning, setIsBenchmarkRunning] = useState<boolean>(false);

  const handleRunBenchmark = async () => {
    setIsBenchmarkRunning(true);
    try {
      const report = await executeAutomatedBenchmark();
      setBenchmarkReport(report);
    } catch (err) {
      console.error("Benchmark error:", err);
    } finally {
      setIsBenchmarkRunning(false);
    }
  };

  const handleInject = (fault: FaultScenario) => {
    cancelDemoCountdown();
    cancelDegradation();
    injectFault(fault);
    selectComponent(fault.affectedComponent);
  };

  const handleScheduleCountdown = (fault: FaultScenario, customDelay?: number) => {
    cancelDegradation();
    const delay = customDelay ?? scheduledDelaySeconds;
    startDemoCountdown(fault, delay);
  };

  const handleStartDegradation = () => {
    cancelDemoCountdown();
    startDegradationRun(selectedScenarioKey, {
      triggerMetric,
      triggerThreshold,
      rampDuration,
    });
  };

  const degradationPct = Math.round(degradationState.currentDegradation * 100);

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-sage" />
            Simulation Fault Laboratory & Degradation Engine
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Evaluate healthy startup, operating-time wear models, gradual sensor divergence, and causal root cause analysis.
          </p>
        </div>

        {/* Speed & Sim Controls Pill */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-surface p-1 rounded-lg border border-border text-xs">
            <span className="text-[10px] font-mono text-text-muted px-2 uppercase font-bold">
              Clock Speed:
            </span>
            {([1, 2, 5, 10] as const).map((spd) => (
              <button
                key={spd}
                onClick={() => setSimSpeed(spd)}
                className={`px-2 py-0.5 rounded text-xs font-mono font-bold transition-colors ${
                  simSpeed === spd
                    ? "bg-sage text-charcoal-deep shadow-subtle"
                    : "text-text-secondary hover:text-text-primary hover:bg-card"
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-secondary font-mono">
            <Radio className="w-3.5 h-3.5 text-sage animate-pulse" />
            <span>SIMULATED</span>
          </div>
        </div>
      </div>

      {/* Degradation Simulator Banner Card */}
      <Card className="p-5 border border-border space-y-4 bg-card shadow-card">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-sage/15 text-sage border border-sage/30">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-text-primary flex items-center gap-2">
                <span>Operating-Time-Dependent Degradation Model</span>
                {degradationConfig.enabled && (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-sage/15 border border-sage/30 text-sage uppercase animate-pulse">
                    Degradation Active
                  </span>
                )}
              </h2>
              <p className="text-xs text-text-secondary">
                Starts 100% healthy, runs normally, then gradually degrades based on cumulative motor run time or cycles.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="px-2.5 py-1 rounded bg-surface border border-border">
              <span className="text-text-muted">Motor Run: </span>
              <strong className="text-text-primary">{cumulativeMotorTime}s</strong>
            </div>
            <div className="px-2.5 py-1 rounded bg-surface border border-border">
              <span className="text-text-muted">Trips: </span>
              <strong className="text-text-primary">{operatingCycles} cycles</strong>
            </div>
          </div>
        </div>

        {/* Live Degradation Progress & Stage Gauge */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-3.5 rounded-xl bg-surface border border-border text-xs">
          <div>
            <span className="text-text-muted text-[11px] block">Target Scenario:</span>
            <span className="font-bold text-text-primary font-mono">
              {PRESET_FAULTS[selectedScenarioKey]?.name || "Main Drive Bearing Degradation"}
            </span>
          </div>
          <div>
            <span className="text-text-muted text-[11px] block">Trigger Condition:</span>
            <span className="font-semibold text-text-primary font-mono">
              {triggerMetric === "motor_time"
                ? `After ${triggerThreshold}s motor run time`
                : triggerMetric === "operating_cycles"
                ? `After ${triggerThreshold} completed trips`
                : `After ${triggerThreshold}s simulation time`}
            </span>
          </div>
          <div>
            <span className="text-text-muted text-[11px] block">Degradation Progress:</span>
            <div className="flex items-center gap-2 mt-1">
              <div className="flex-1 h-2 rounded-full bg-card overflow-hidden border border-border">
                <div
                  className={`h-full transition-all duration-300 ${
                    degradationPct >= 70
                      ? "bg-coral"
                      : degradationPct >= 35
                      ? "bg-amber-warm"
                      : "bg-sage"
                  }`}
                  style={{ width: `${degradationPct}%` }}
                />
              </div>
              <span className="font-mono font-bold text-text-primary">{degradationPct}%</span>
            </div>
          </div>
          <div>
            <span className="text-text-muted text-[11px] block">Current Stage:</span>
            <span
              className={`inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                degradationState.stage === "critical_fault"
                  ? "bg-coral/20 text-coral border border-coral/40"
                  : degradationState.stage === "warning_envelope"
                  ? "bg-amber-warm/20 text-amber-warm border border-amber-warm/40"
                  : degradationState.stage === "degrading_healthy"
                  ? "bg-sage/20 text-sage border border-sage/40"
                  : "bg-surface text-text-secondary border border-border"
              }`}
            >
              {degradationState.stage === "critical_fault"
                ? "Critical Fault Confirmed"
                : degradationState.stage === "warning_envelope"
                ? "Warning Envelope Breached"
                : degradationState.stage === "degrading_healthy"
                ? "Normal Wear (<35%)"
                : "Dormant / Baseline"}
            </span>
          </div>
        </div>

        {/* Configuration Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
          <div>
            <label className="text-[11px] font-semibold text-text-secondary block mb-1">
              Component Wear Scenario:
            </label>
            <select
              value={selectedScenarioKey}
              onChange={(e) => setSelectedScenarioKey(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage font-mono"
            >
              <option value="bearing_degradation">Main Drive Bearing Degradation</option>
              <option value="motor_overheating">Motor Stator Thermal Breakdown</option>
              <option value="door_mechanism_fault">Door Obstruction & Splay Resistance</option>
              <option value="brake_related_fault">Electromechanical Brake Slip</option>
              <option value="mechanical_vibration">Guide Rail Column Vibration</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-text-secondary block mb-1">
              Trigger Metric & Threshold:
            </label>
            <div className="flex gap-2">
              <select
                value={triggerMetric}
                onChange={(e) => {
                  const m = e.target.value as any;
                  setTriggerMetric(m);
                  if (m === "operating_cycles") {
                    setTriggerThreshold(3);
                  } else {
                    setTriggerThreshold(120);
                  }
                }}
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage font-mono"
              >
                <option value="motor_time">Motor Operating Time</option>
                <option value="operating_cycles">Operating Trips</option>
                <option value="sim_time">Simulation Elapsed Time</option>
              </select>
              <select
                value={triggerThreshold}
                onChange={(e) => setTriggerThreshold(Number(e.target.value))}
                className="w-40 px-2 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage font-mono"
              >
                {triggerMetric === "operating_cycles" ? (
                  <>
                    <option value={1}>After 1 Trip</option>
                    <option value={2}>After 2 Trips</option>
                    <option value={3}>After 3 Trips (Recommended)</option>
                    <option value={5}>After 5 Trips</option>
                    <option value={10}>After 10 Trips</option>
                  </>
                ) : (
                  <>
                    <option value={20}>After 20s (Demo)</option>
                    <option value={60}>After 1 Min (60s)</option>
                    <option value={120}>After 2 Mins (120s - Recommended)</option>
                    <option value={180}>After 3 Mins (180s)</option>
                    <option value={300}>After 5 Mins (300s)</option>
                  </>
                )}
              </select>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-text-secondary block mb-1">
              Degradation Ramp Duration:
            </label>
            <div className="flex items-center gap-2">
              <select
                value={rampDuration}
                onChange={(e) => setRampDuration(Number(e.target.value))}
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage font-mono"
              >
                <option value={15}>15s (Accelerated Demonstration)</option>
                <option value={30}>30s (Standard Wear Ramp)</option>
                <option value={60}>60s (Extended Operating Ramp)</option>
              </select>

              {degradationConfig.enabled ? (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={cancelDegradation}
                  className="shrink-0 text-xs text-coral hover:bg-coral/10 border-coral/30"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Stop</span>
                </Button>
              ) : (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleStartDegradation}
                  className="shrink-0 text-xs font-bold flex items-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Start Degradation</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Active Fault Status Banner */}
      <Card className={`p-4.5 border transition-all ${activeFault ? "border-coral/50 bg-coral/5" : "border-border"}`}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div
              className={`p-2.5 rounded-xl ${
                activeFault ? "bg-coral/15 text-coral" : "bg-sage/15 text-sage"
              }`}
            >
              {activeFault ? (
                <AlertTriangle className="w-6 h-6 animate-pulse" />
              ) : (
                <CheckCircle2 className="w-6 h-6" />
              )}
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-text-muted">
                Active Simulation Incident
              </div>
              <div className="text-base font-bold text-text-primary">
                {activeFault ? activeFault.name : "Normal Baseline (All Components Healthy)"}
              </div>
              {activeFault && (
                <div className="text-xs text-coral mt-0.5 font-medium">
                  Affected Target Component:{" "}
                  <span className="font-mono font-bold">
                    {COMPONENT_CATALOG[activeFault.affectedComponent as ComponentId]?.label ||
                      activeFault.affectedComponent}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeFault && (
              <Button
                variant="secondary"
                size="sm"
                onClick={clearFault}
                className="flex items-center gap-1.5 text-xs"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Clear Active Fault
              </Button>
            )}
            <Button
              variant="primary"
              size="sm"
              onClick={() => navigate("/digital-twin")}
              className="flex items-center gap-1.5 text-xs"
            >
              View in 3D Twin
              <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </Card>

      {/* Delayed Fault Countdown Banner */}
      {demoCountdown !== null && demoPendingFault && (
        <div className="p-4 rounded-xl bg-amber-warm/15 border-2 border-amber-warm/50 flex flex-wrap items-center justify-between gap-3 text-xs shadow-card animate-pulse">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-amber-warm/25 text-amber-warm shrink-0">
              <Timer className="w-5 h-5 animate-spin" />
            </div>
            <div>
              <div className="font-bold text-amber-warm font-mono text-sm uppercase flex items-center gap-2">
                <span>Elevator Operating Normally in Service: T-{formatTime(demoCountdown)} Remaining</span>
              </div>
              <p className="text-text-secondary text-[11px] mt-0.5">
                Elevator cabin is actively traveling between floors, opening/closing doors, and carrying simulated passengers. Damage for <strong>{demoPendingFault.name}</strong> will trigger automatically after this elevator operating duration concludes.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="amber"
              size="sm"
              onClick={() => {
                const fault = demoPendingFault;
                cancelDemoCountdown();
                handleInject(fault);
              }}
              className="text-xs font-semibold"
            >
              Trigger Now (Skip Wait)
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={cancelDemoCountdown}
              className="text-xs"
            >
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Preset Scenarios Grid (Instant and Timed Injection) */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-text-primary flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-warm" />
              <span>Canonical Diagnostic Scenarios</span>
            </h3>
            <span className="text-[10px] font-mono text-text-muted">
              Trigger after a few minutes of realistic elevator usage or perform instant injection
            </span>
          </div>

          {/* Global Delay Duration Selector */}
          <div className="flex items-center gap-2 bg-surface p-1.5 rounded-lg border border-border text-xs">
            <Timer className="w-3.5 h-3.5 text-amber-warm" />
            <span className="text-[11px] text-text-secondary font-medium">
              Usage Before Damage:
            </span>
            <select
              value={scheduledDelaySeconds}
              onChange={(e) => setScheduledDelaySeconds(Number(e.target.value))}
              className="px-2 py-0.5 rounded bg-card border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage font-bold"
            >
              <option value={10}>10s (Quick Demo)</option>
              <option value={60}>1 Minute of Normal Travel</option>
              <option value={120}>2 Minutes of Normal Travel (Recommended)</option>
              <option value={180}>3 Minutes of Normal Travel</option>
              <option value={300}>5 Minutes of Extended Travel</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.values(PRESET_FAULTS).map((scenario) => {
            const isActive = activeFault?.id === scenario.id;
            const isPending = demoPendingFault?.id === scenario.id;
            const componentMeta = COMPONENT_CATALOG[scenario.affectedComponent as ComponentId];

            return (
              <Card
                key={scenario.id}
                className={`p-4.5 flex flex-col justify-between transition-all border ${
                  isActive
                    ? "border-coral shadow-subtle ring-1 ring-coral/30 bg-coral/5"
                    : isPending
                    ? "border-amber-warm shadow-subtle ring-1 ring-amber-warm/30 bg-amber-warm/5"
                    : "border-border hover:border-border-strong hover:bg-surface/30"
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-surface border border-border text-text-secondary font-medium">
                      {componentMeta?.category || "Drive & Hoist"}
                    </span>
                    {isActive ? (
                      <span className="text-[10px] font-bold text-coral bg-coral/15 border border-coral/30 px-2 py-0.5 rounded uppercase font-mono">
                        Active In Simulation
                      </span>
                    ) : isPending ? (
                      <span className="text-[10px] font-bold text-amber-warm bg-amber-warm/15 border border-amber-warm/30 px-2 py-0.5 rounded uppercase font-mono animate-pulse">
                        Triggering in {formatTime(demoCountdown ?? 0)}
                      </span>
                    ) : null}
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-text-primary">{scenario.name}</h3>
                    <p className="text-xs text-text-secondary mt-1 leading-relaxed">
                      {scenario.description}
                    </p>
                  </div>

                  <div className="bg-surface p-2.5 rounded-lg border border-border text-xs space-y-1">
                    <span className="text-[10px] font-mono text-text-muted uppercase font-bold">
                      Expected Telemetry Divergence:
                    </span>
                    {Object.entries(scenario.sensorDeltas).map(([k, v]) => (
                      <div key={k} className="flex justify-between font-mono text-[11px]">
                        <span className="text-text-secondary">{k}:</span>
                        <span className="text-coral font-bold">+{v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-border flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-text-muted font-mono truncate max-w-[120px]">
                    {componentMeta?.label || scenario.affectedComponent}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleScheduleCountdown(scenario)}
                      className="px-2.5 py-1 rounded bg-surface hover:bg-surface-hover text-amber-warm hover:text-amber-warm/90 border border-amber-warm/40 text-[11px] font-semibold transition-colors flex items-center gap-1"
                      title={`Run elevator normally for ${formatDelayLabel(scheduledDelaySeconds)}, then trigger ${scenario.name}`}
                    >
                      <Timer className="w-3.5 h-3.5" />
                      <span>After {formatDelayLabel(scheduledDelaySeconds)}</span>
                    </button>

                    <Button
                      variant={isActive ? "secondary" : "primary"}
                      size="sm"
                      onClick={() => handleInject(scenario)}
                      className="flex items-center gap-1 text-xs font-semibold"
                    >
                      <Play className="w-3 h-3" />
                      {isActive ? "Re-Apply" : "Inject Now"}
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* 4. Automated Fault Detection & Diagnostic Benchmark Suite */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              4
            </span>
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-sage" />
                Automated Fault Detection & Diagnostic Benchmark Suite
              </h2>
              <p className="text-[11px] text-text-secondary mt-0.5">
                Evaluates repeatable healthy and faulty test scenarios, empirical detection delay, false alarm rejection, subsystem isolation, and root-cause ranking.
              </p>
            </div>
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={handleRunBenchmark}
            disabled={isBenchmarkRunning}
            className="flex items-center gap-1.5 text-xs font-semibold"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isBenchmarkRunning ? "animate-spin" : ""}`} />
            <span>{isBenchmarkRunning ? "Executing Test Runs..." : "Execute Benchmark Suite (7 Scenarios)"}</span>
          </Button>
        </div>

        {benchmarkReport ? (
          <div className="space-y-4">
            {/* KPI Summary Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              <div className="p-3 rounded-lg bg-surface border border-border">
                <span className="text-[10px] font-mono text-text-muted uppercase">Scenarios Evaluated</span>
                <div className="text-lg font-bold font-mono text-text-primary mt-1">
                  {benchmarkReport.totalScenarios}
                </div>
                <div className="text-[10px] text-text-secondary mt-0.5 font-mono">
                  1 Healthy + 6 Faults
                </div>
              </div>

              <div className="p-3 rounded-lg bg-surface border border-border">
                <span className="text-[10px] font-mono text-text-muted uppercase">Subsystem ID Accuracy</span>
                <div className="text-lg font-bold font-mono text-sage mt-1">
                  {benchmarkReport.overallSubsystemAccuracy.toFixed(1)}%
                </div>
                <div className="text-[10px] text-text-secondary mt-0.5 font-mono">
                  Ground Truth Matched
                </div>
              </div>

              <div className="p-3 rounded-lg bg-surface border border-border">
                <span className="text-[10px] font-mono text-text-muted uppercase">Top-1 RCA Accuracy</span>
                <div className="text-lg font-bold font-mono text-sage mt-1">
                  {benchmarkReport.overallRootCauseRankingAccuracy.toFixed(1)}%
                </div>
                <div className="text-[10px] text-text-secondary mt-0.5 font-mono">
                  Ranked #1 Hypothesis
                </div>
              </div>

              <div className="p-3 rounded-lg bg-surface border border-border">
                <span className="text-[10px] font-mono text-text-muted uppercase">Mean Detection Delay</span>
                <div className="text-lg font-bold font-mono text-text-primary mt-1">
                  {benchmarkReport.meanDetectionDelaySeconds.toFixed(1)}s
                </div>
                <div className="text-[10px] text-text-secondary mt-0.5 font-mono">
                  Simulated Response Time
                </div>
              </div>

              <div className="p-3 rounded-lg bg-surface border border-border">
                <span className="text-[10px] font-mono text-text-muted uppercase">Baseline False Alarms</span>
                <div className="text-lg font-bold font-mono text-sage mt-1">
                  {benchmarkReport.totalFalseAlarms}
                </div>
                <div className="text-[10px] text-text-secondary mt-0.5 font-mono">
                  0 Spurious Trips
                </div>
              </div>
            </div>

            {/* Scenario Breakdown Table */}
            <div className="overflow-x-auto border border-border rounded-lg">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-surface text-text-secondary border-b border-border">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Scenario</th>
                    <th className="py-2.5 px-3 font-semibold">Target Subsystem</th>
                    <th className="py-2.5 px-3 font-semibold">Detection Delay</th>
                    <th className="py-2.5 px-3 font-semibold">Subsystem Isolation</th>
                    <th className="py-2.5 px-3 font-semibold">Top-1 RCA Ranking</th>
                    <th className="py-2.5 px-3 font-semibold">Tripped Sensors</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {benchmarkReport.scenarioResults.map((res) => (
                    <tr key={res.scenarioId} className="hover:bg-surface/40 transition-colors">
                      <td className="py-2 px-3 font-sans font-medium text-text-primary">
                        {res.scenarioName}
                      </td>
                      <td className="py-2 px-3 text-text-secondary">
                        {res.groundTruthComponent}
                      </td>
                      <td className="py-2 px-3 font-bold text-text-primary">
                        {res.detectionDelaySeconds !== null ? `${res.detectionDelaySeconds}s` : "N/A (Healthy)"}
                      </td>
                      <td className="py-2 px-3">
                        {res.subsystemIdentifiedCorrectly ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-sage bg-sage/15 px-2 py-0.5 rounded border border-sage/30">
                            <CheckCircle className="w-3 h-3" /> MATCHED
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-coral bg-coral/15 px-2 py-0.5 rounded border border-coral/30">
                            <XCircle className="w-3 h-3" /> MISMATCH
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3">
                        {res.rootCauseRankedTop1 ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-sage bg-sage/15 px-2 py-0.5 rounded border border-sage/30">
                            <CheckCircle className="w-3 h-3" /> RANK #1
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-coral bg-coral/15 px-2 py-0.5 rounded border border-coral/30">
                            <XCircle className="w-3 h-3" /> NOT RANK 1
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-text-muted">
                        {res.trippedSensors.length > 0 ? res.trippedSensors.join(", ") : "None (Baseline)"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="text-[11px] text-text-muted font-mono flex items-center justify-between">
              <span>Benchmark Execution: {benchmarkReport.timestamp}</span>
              <span>Methodology: Isolated multi-tick virtual engine evaluation</span>
            </div>
          </div>
        ) : (
          <div className="p-6 rounded-lg bg-surface border border-border text-center space-y-2">
            <BarChart3 className="w-8 h-8 text-sage mx-auto mb-1 opacity-75" />
            <div className="text-sm font-semibold text-text-primary">Automated Benchmark Ready for Execution</div>
            <p className="text-xs text-text-secondary max-w-md mx-auto">
              Click &quot;Execute Benchmark Suite&quot; to run an automated suite of 7 deterministic operational scenarios in isolated simulation passes, recording true detection delay, false-alarm rejection, and root-cause ranking precision.
            </p>
          </div>
        )}
      </Card>

      {/* Engineering Notice Banner */}
      <div className="p-4 rounded-xl bg-surface border border-border text-xs text-text-secondary flex items-start gap-3">
        <Info className="w-4 h-4 text-sage mt-0.5 shrink-0" />
        <div className="leading-relaxed">
          <strong className="text-text-primary">Engineering Note:</strong> Fault injection operates entirely within the in-memory deterministic simulation loop. It applies physics-calibrated signal deltas without requiring physical elevator hardware connections.
        </div>
      </div>
    </div>
  );
};

export default FaultLab;
