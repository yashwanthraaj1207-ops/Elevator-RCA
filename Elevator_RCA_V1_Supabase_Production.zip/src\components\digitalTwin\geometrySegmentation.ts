// src/components/digitalTwin/geometrySegmentation.ts
/**
 * Geometry Segmentation Engine for ELEVATOR-RCA
 *
 * Processes `NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb` into 18 discrete physical component
 * subassemblies for direct mesh raycast selection, exploded view inspection,
 * kinematic cabin travel, and sliding door animation.
 *
 * Provides an auditable Model Preparation Diagnostic Report.
 */

import * as THREE from "three";
import * as BufferGeometryUtils from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { ComponentId, COMPONENT_CATALOG, VerificationTier } from "./componentMapping";

export interface SegmentedComponentData {
  id: ComponentId;
  label: string;
  category: "Drive & Hoist" | "Car & Doors" | "Guidance & Balance" | "Shaft & Safety" | "Electrical & Sensors";
  triangleCount: number;
  vertexCount: number;
  percentageOfModel: number;
  meshCount: number;
  geometry: THREE.BufferGeometry;
  localCenter: THREE.Vector3;
  boundingBox: THREE.Box3;
  originalPosition: THREE.Vector3;
  explodedOffset: THREE.Vector3;
  targetNodeName: string;
  isCabinPart: boolean;
  isDoorLeft: boolean;
  isDoorRight: boolean;
  isCounterweight: boolean;
  isRotatingPart: boolean;
  verificationTier: VerificationTier;
  verificationNote: string;
}

export interface GeometrySegmentationReport {
  assetPath: string;
  rawTotalTriangles: number;
  rawTotalVertices: number;
  rawTotalMeshes: number;
  isSingleMergedMesh: boolean;
  mergedMeshName: string;
  scaleFactor: number;
  originalCenter: [number, number, number];
  originalDimensions: [number, number, number];
  components: Record<ComponentId, SegmentedComponentData>;
  blenderPreparationPlan: {
    step1: string;
    step2: string;
    step3: string;
    step4: string;
    step5: string;
  };
}

/**
 * 18 Exploded View Vectors: Physical offsets separating components along engineering axes
 */
export const COMPONENT_EXPLODED_OFFSETS: Record<ComponentId, [number, number, number]> = {
  traction_motor: [0.95, 0.65, 0.45],       // Up and right
  bearing_main: [0.55, 0.45, 0.75],         // Forward-right
  brake_assembly: [1.25, 0.35, 0.25],       // Lateral right
  traction_sheave: [0.0, 0.95, 0.0],        // Overhead up
  cabin_body: [0.0, 0.0, 1.25],             // Pulls forward
  cabin_floor: [0.0, -0.65, 0.85],          // Down and forward
  door_left: [-0.85, 0.0, 1.65],            // Outward left and forward
  door_right: [0.85, 0.0, 1.65],            // Outward right and forward
  door_operator: [0.0, 0.75, 1.45],         // Up and forward
  door_system: [0.0, 0.0, 1.65],            // Forward
  counterweight: [0.0, 0.0, -1.35],         // Rearward
  guide_rail_left: [-1.25, 0.0, 0.0],       // Lateral left
  guide_rail_right: [1.25, 0.0, -0.25],     // Lateral right
  suspension_ropes: [-0.45, 0.35, 0.65],    // Forward-left
  position_encoder: [0.95, 0.85, -0.35],    // Up and rear-right
  sensor_assembly: [0.85, 0.95, 0.55],      // High diagonal
  safety_buffers: [0.0, -1.15, 0.25],       // Downward into pit
  shaft_frame: [0.0, 0.0, 0.0],             // Base structural anchor
  electrical_controller: [-1.15, 0.75, -0.25], // High lateral left
};

/**
 * Classifies a raw mesh from Elevator_D1_Working.glb into one of 18 component groups
 * based on its normalized spatial centroid and bounding dimensions relative to the elevator shaft.
 */
export function classifyMeshSpatial(
  normCenter: THREE.Vector3,
  normSize: THREE.Vector3
): ComponentId {
  const x = normCenter.x;
  const y = normCenter.y;
  const z = normCenter.z;
  const sx = normSize.x;
  const sy = normSize.y;
  const sz = normSize.z;

  // 1. Structural Perimeter Frame (applies at all elevations)
  // If a mesh sits along the outer corner columns or perimeter structural trusses
  const isOuterColumn = (Math.abs(x) > 0.10 && Math.abs(z) > 0.09) || Math.abs(x) > 0.115 || Math.abs(z) > 0.115;
  const isRoofTopCap = y > 0.46; // The uppermost structural roof truss / cap beams

  // Pit area (y <= -0.32)
  if (y <= -0.32) {
    // True safety buffer cylinders are located in the pit beneath car & counterweight
    if (y < -0.36 && Math.abs(x) < 0.08 && z > -0.04 && z < 0.04 && sy < 0.15 && sx < 0.08 && sz < 0.08) {
      return "safety_buffers";
    }
    return "shaft_frame";
  }

  // Structural roof truss cap
  if (isRoofTopCap) {
    return "shaft_frame";
  }

  // Top Machinery Room (0.30 <= y <= 0.46)
  if (y >= 0.30) {
    // If outer perimeter frame or columns at top, it belongs to the shaft structural frame
    if (isOuterColumn) {
      if (x < -0.08 && z < 0) return "electrical_controller";
      return "shaft_frame";
    }

    // Inside machinery room:
    if (Math.abs(x) < 0.045 && Math.abs(z) < 0.055) return "traction_sheave";
    if (x >= 0.02 && x <= 0.075 && Math.abs(z) <= 0.055) return "bearing_main";
    if (x > 0.065 && z >= 0.012) return "brake_assembly";
    if (x > 0.065 && z < 0.012) return "position_encoder";
    if (x > 0.02) {
      if (y > 0.40 && z > 0.02) return "sensor_assembly";
      return "traction_motor";
    }
    if (x < -0.035) {
      if (x < -0.065 && z < 0) return "electrical_controller";
      return "shaft_frame";
    }
    return "traction_motor";
  }

  // Guide rails (continuous vertical T-rails running up the sides near z ~ 0)
  if (Math.abs(z) <= 0.04 && y > -0.32 && y < 0.30) {
    if (x < -0.095 && x >= -0.115) return "guide_rail_left";
    if (x > 0.095 && x <= 0.115) return "guide_rail_right";
  }

  // Counterweight (rear column z < -0.045, central-right x > 0.01 to 0.095)
  if (z < -0.045 && x > 0.01 && x < 0.095 && y > -0.32 && y < 0.30) {
    return "counterweight";
  }

  // Suspension ropes (vertical cables above cabin, central x, middle-high y)
  if (y > 0.14 && y < 0.30 && Math.abs(x) < 0.05 && z >= -0.01 && z <= 0.055) {
    return "suspension_ropes";
  }

  // Door Operator (header drive mechanism above cabin entrance)
  if (z >= 0.032 && y >= 0.13 && y < 0.25 && Math.abs(x) < 0.095) {
    return "door_operator";
  }

  // Cabin Doors (front sliding door panels)
  if (z >= 0.030 && y >= -0.15 && y < 0.13 && Math.abs(x) < 0.095) {
    if (x < -0.005) return "door_left";
    return "door_right";
  }

  // Cabin Floor (bottom platform)
  if (y >= -0.18 && y <= -0.08 && Math.abs(x) < 0.095 && z > -0.05 && z < 0.035) {
    return "cabin_floor";
  }

  // Cabin Body (enclosure, walls, ceiling)
  if (y > -0.08 && y < 0.18 && Math.abs(x) < 0.095 && z > -0.05 && z < 0.035) {
    return "cabin_body";
  }

  // Base structural shaft frame (outer trusses, columns, cross-braces)
  return "shaft_frame";
}

/**
 * Decomposes Elevator_D1_Working.glb into 18 physical component subassemblies.
 * Scales, centers, and optimizes geometries into unified BufferGeometries for 60+ FPS performance.
 */
export function segmentGlbModel(rawScene: THREE.Group): GeometrySegmentationReport {
  rawScene.updateMatrixWorld(true);

  const meshes: THREE.Mesh[] = [];
  rawScene.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      meshes.push(child as THREE.Mesh);
    }
  });

  if (meshes.length === 0) {
    throw new Error("Unable to locate any meshes in GLTF scene.");
  }

  // Compute global bounding box across all 7,847 meshes
  const overallBox = new THREE.Box3();
  const tempBox = new THREE.Box3();

  for (const mesh of meshes) {
    mesh.updateMatrixWorld(true);
    if (!mesh.geometry.boundingBox) {
      mesh.geometry.computeBoundingBox();
    }
    tempBox.copy(mesh.geometry.boundingBox || new THREE.Box3());
    tempBox.applyMatrix4(mesh.matrixWorld);
    overallBox.union(tempBox);
  }

  const origCenter = overallBox.getCenter(new THREE.Vector3());
  const origSize = overallBox.getSize(new THREE.Vector3());
  const maxDim = Math.max(origSize.x, origSize.y, origSize.z);

  // Target standard height of 3.8m for optimal framing and crisp viewing
  const targetHeight = 3.8;
  const scale = maxDim > 0 ? targetHeight / maxDim : 1;
  const normScale = maxDim > 0 ? 1.0 / maxDim : 1;

  // Buckets for all 18 component IDs
  const componentKeys = Object.keys(COMPONENT_CATALOG) as ComponentId[];
  const buckets: Record<ComponentId, THREE.BufferGeometry[]> = {} as any;
  const meshCounts: Record<ComponentId, number> = {} as any;

  for (const key of componentKeys) {
    buckets[key] = [];
    meshCounts[key] = 0;
  }

  let totalTriangles = 0;
  let totalVertices = 0;

  // Process and bucket every mesh
  for (const mesh of meshes) {
    const origGeom = mesh.geometry;
    if (!origGeom.attributes.position) continue;

    if (!origGeom.boundingBox) {
      origGeom.computeBoundingBox();
    }

    const mBox = (origGeom.boundingBox || new THREE.Box3()).clone().applyMatrix4(mesh.matrixWorld);
    const mCenter = mBox.getCenter(new THREE.Vector3());
    const mSize = mBox.getSize(new THREE.Vector3());

    const normCenter = mCenter.clone().sub(origCenter).multiplyScalar(normScale);
    const normSize = mSize.clone().multiplyScalar(normScale);

    const compId = classifyMeshSpatial(normCenter, normSize);

    // Clone geometry, apply mesh's world transform, then center & scale
    const geom = origGeom.clone();
    geom.applyMatrix4(mesh.matrixWorld);

    // Apply scale & center to vertices
    const pos = geom.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const vx = (pos.getX(i) - origCenter.x) * scale;
      const vy = (pos.getY(i) - origCenter.y) * scale;
      const vz = (pos.getZ(i) - origCenter.z) * scale;
      pos.setXYZ(i, vx, vy, vz);
    }
    pos.needsUpdate = true;

    if (!geom.attributes.normal) {
      geom.computeVertexNormals();
    }

    const triCount = geom.index ? geom.index.count / 3 : pos.count / 3;
    totalTriangles += triCount;
    totalVertices += pos.count;

    buckets[compId].push(geom);
    meshCounts[compId]++;
  }

  // Merge geometries for each component bucket
  function mergeBucket(geoms: THREE.BufferGeometry[]): THREE.BufferGeometry {
    if (geoms.length === 0) return new THREE.BufferGeometry();
    if (geoms.length === 1) {
      geoms[0].computeBoundingBox();
      return geoms[0];
    }
    const merged = BufferGeometryUtils.mergeGeometries(geoms, false);
    if (!merged) return geoms[0] || new THREE.BufferGeometry();
    merged.computeBoundingBox();
    return merged;
  }

  const components = {} as Record<ComponentId, SegmentedComponentData>;

  for (const id of componentKeys) {
    const meta = COMPONENT_CATALOG[id];
    const geoms = buckets[id] || [];
    const mergedGeom = mergeBucket(geoms);
    const box = mergedGeom.boundingBox || new THREE.Box3();
    const localCenter = box.getCenter(new THREE.Vector3());

    const triCount = mergedGeom.index
      ? mergedGeom.index.count / 3
      : mergedGeom.attributes.position
      ? mergedGeom.attributes.position.count / 3
      : 0;

    const percentage = totalTriangles > 0 ? (triCount / totalTriangles) * 100 : 0;
    const exploded = COMPONENT_EXPLODED_OFFSETS[id] || [0, 0, 0];

    const isCabin = id === "cabin_body" || id === "cabin_floor" || id === "door_operator" || id === "door_left" || id === "door_right" || id === "door_system";
    const isDL = id === "door_left";
    const isDR = id === "door_right";
    const isCW = id === "counterweight";
    const isRot = id === "traction_sheave";

    components[id] = {
      id,
      label: meta.label,
      category: meta.category,
      triangleCount: Math.round(triCount),
      vertexCount: mergedGeom.attributes.position ? mergedGeom.attributes.position.count : 0,
      percentageOfModel: Number(percentage.toFixed(1)),
      meshCount: meshCounts[id] || 0,
      geometry: mergedGeom,
      localCenter,
      boundingBox: box,
      originalPosition: localCenter.clone(),
      explodedOffset: new THREE.Vector3(...exploded),
      targetNodeName: meta.targetNodeName,
      isCabinPart: isCabin,
      isDoorLeft: isDL,
      isDoorRight: isDR,
      isCounterweight: isCW,
      isRotatingPart: isRot,
      verificationTier: meta.verificationTier,
      verificationNote: meta.verificationNote,
    };
  }

  return {
    assetPath: "/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb",
    rawTotalTriangles: Math.round(totalTriangles),
    rawTotalVertices: totalVertices,
    rawTotalMeshes: meshes.length,
    isSingleMergedMesh: meshes.length <= 1,
    mergedMeshName: meshes.length === 1 ? meshes[0].name || "Elevator_Mesh" : "Elevator_Loose_Parts_Assembly",
    scaleFactor: Number(scale.toFixed(4)),
    originalCenter: [origCenter.x, origCenter.y, origCenter.z],
    originalDimensions: [origSize.x, origSize.y, origSize.z],
    components,
    blenderPreparationPlan: {
      step1: "Import Elevator D1.glb via File -> Import -> glTF 2.0.",
      step2: "Enter Edit Mode (Tab), select all (A), press P -> By Loose Parts to isolate components.",
      step3: "Group isolated meshes into 18 collections matching canonical IDs (bearing_main, traction_motor, cabin_body, door_left, etc.).",
      step4: "For each collection, Join (Ctrl+J) and set Origin to Geometry (Object -> Set Origin).",
      step5: "Export as glTF 2.0 Binary (NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb) with custom node names preserved.",
    },
  };
}
