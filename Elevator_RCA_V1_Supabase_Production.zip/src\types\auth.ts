// src/types/auth.ts
import { User, Session } from "@supabase/supabase-js";

export type CertifiedRole = "admin" | "lead_pe" | "field_technician" | "apprentice";

export interface UserProfile {
  id: string; // matches auth.users.id
  email?: string;
  full_name: string;
  role: CertifiedRole;
  badge_number: string;
  authorized_assets: string[];
  created_at?: string;
  updated_at?: string;
}

export interface AuthState {
  user: User | null;
  session: Session | null;
  profile: UserProfile | null;
  isLoading: boolean;
  isOnline: boolean;
  isOfflineMode: boolean;
  authError: string | null;
}

export interface AuthContextType extends AuthState {
  signInWithEmail: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUpWithEmail: (
    email: string,
    password: string,
    fullName: string,
    role: CertifiedRole,
    badgeNumber?: string
  ) => Promise<{ success: boolean; confirmationRequired?: boolean; error?: string }>;
  resetPasswordForEmail: (email: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  loginOfflineDemo: (role?: CertifiedRole, customAssetId?: string) => void;
  refreshProfile: () => Promise<void>;
}

