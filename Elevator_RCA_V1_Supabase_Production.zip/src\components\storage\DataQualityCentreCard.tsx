// src/components/storage/DataQualityCentreCard.tsx
import React, { useMemo } from "react";
import { Card } from "../ui/Card";
import { useElevatorStore } from "../../simulation/store";
import { evaluateDataQuality } from "../../simulation/dataQuality";
import {
  ShieldCheck,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Lock,
  FileCheck,
  Info,
  Layers,
  Radio,
} from "lucide-react";

export const DataQualityCentreCard: React.FC = () => {
  const sensors = useElevatorStore((s) => s.sensors);
  const simTime = useElevatorStore((s) => s.time);
  const maintenance = useElevatorStore((s) => s.maintenance);

  const report = useMemo(() => {
    return evaluateDataQuality(sensors, simTime, maintenance.auditTrail);
  }, [sensors, simTime, maintenance.auditTrail]);

  return (
    <Card className="p-5 border-border space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3">
        <div className="flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
            ★
          </span>
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-sage" />
              Telemetry Data Quality & Cryptographic Audit Verification
            </h2>
            <p className="text-[11px] text-text-secondary mt-0.5">
              Continuous monitoring of stream completeness, sensor packet staleness, plausible range bounds, and SHA-256 audit log integrity.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase border ${
              report.dataStreamContinuity === "CONTINUOUS"
                ? "bg-sage/15 text-sage border-sage/30"
                : report.dataStreamContinuity === "INTERMITTENT"
                ? "bg-amber-warm/15 text-amber-warm border-amber-warm/30"
                : "bg-coral/15 text-coral border-coral/30"
            }`}
          >
            Stream: {report.dataStreamContinuity}
          </span>
          <span className="text-xs font-mono font-bold text-sage bg-card px-2.5 py-1 rounded border border-border">
            Quality Score: {report.overallScore}%
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-lg bg-surface border border-border">
          <span className="text-[10px] font-mono text-text-muted uppercase">Channels Monitored</span>
          <div className="text-lg font-bold font-mono text-text-primary mt-1">
            {report.totalChannelsMonitored} Channels
          </div>
          <div className="text-[10px] text-sage font-mono mt-0.5">
            {report.healthyChannelsCount} Optimal
          </div>
        </div>

        <div className="p-3 rounded-lg bg-surface border border-border">
          <span className="text-[10px] font-mono text-text-muted uppercase">Packet Staleness</span>
          <div className="text-lg font-bold font-mono text-text-primary mt-1">
            {report.staleChannelsCount === 0 ? "0 Stale" : `${report.staleChannelsCount} Delayed`}
          </div>
          <div className="text-[10px] text-text-secondary font-mono mt-0.5">
            Threshold: &gt; 3.0s age
          </div>
        </div>

        <div className="p-3 rounded-lg bg-surface border border-border">
          <span className="text-[10px] font-mono text-text-muted uppercase">Audit Trail Verification</span>
          <div className="text-lg font-bold font-mono text-sage mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-4 h-4 text-sage" />
            Tamper-Free
          </div>
          <div className="text-[10px] text-text-secondary font-mono mt-0.5">
            {report.auditTrailIntegrity.totalRecords} Events Verified
          </div>
        </div>

        <div className="p-3 rounded-lg bg-surface border border-border">
          <span className="text-[10px] font-mono text-text-muted uppercase">Audit Seal Hash</span>
          <div className="text-[11px] font-mono font-bold text-text-primary mt-1 truncate" title={report.auditTrailIntegrity.latestAuditHash}>
            {report.auditTrailIntegrity.latestAuditHash.substring(0, 12)}...
          </div>
          <div className="text-[10px] text-text-muted font-mono mt-0.5">
            SHA-256 Digest Chain
          </div>
        </div>
      </div>

      {/* Channel Quality Table */}
      <div className="overflow-x-auto border border-border rounded-lg">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-surface text-text-secondary border-b border-border">
            <tr>
              <th className="py-2.5 px-3 font-semibold">Channel</th>
              <th className="py-2.5 px-3 font-semibold">Latest Value</th>
              <th className="py-2.5 px-3 font-semibold">Completeness</th>
              <th className="py-2.5 px-3 font-semibold">Packet Age</th>
              <th className="py-2.5 px-3 font-semibold">Range Plausibility</th>
              <th className="py-2.5 px-3 font-semibold">Quality Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {report.channelMetrics.map((ch) => (
              <tr key={ch.channelName} className="hover:bg-surface/40 transition-colors">
                <td className="py-2 px-3 font-sans font-medium text-text-primary">
                  {ch.channelName}
                </td>
                <td className="py-2 px-3 text-text-primary font-bold">
                  {ch.latestValue.toFixed(2)} {ch.unit}
                </td>
                <td className="py-2 px-3 text-sage font-bold">
                  {ch.completenessPercent.toFixed(1)}%
                </td>
                <td className="py-2 px-3 text-text-secondary">
                  {ch.stalenessSeconds.toFixed(1)}s
                </td>
                <td className="py-2 px-3">
                  {ch.isOutOfBounds ? (
                    <span className="text-coral font-bold">Out of Bounds</span>
                  ) : (
                    <span className="text-sage">Valid Physical Range</span>
                  )}
                </td>
                <td className="py-2 px-3">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                      ch.status === "OPTIMAL"
                        ? "bg-sage/15 text-sage"
                        : ch.status === "DEGRADED"
                        ? "bg-amber-warm/15 text-amber-warm"
                        : "bg-coral/15 text-coral"
                    }`}
                  >
                    {ch.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Synthetic Telemetry Disclosure Banner */}
      <div className="p-3.5 rounded-lg bg-surface border border-border text-xs text-text-secondary flex items-start gap-2.5">
        <Info className="w-4 h-4 text-sage mt-0.5 shrink-0" />
        <div className="leading-relaxed">
          <strong className="text-text-primary">Data Quality & Synthetic Disclosure Notice: </strong>
          {report.syntheticDisclosures.warningNotice} Telemetry conforms to{" "}
          <span className="font-mono text-text-primary">{report.syntheticDisclosures.standardReference}</span> at{" "}
          <span className="font-mono text-text-primary">{report.syntheticDisclosures.samplingFrequency}</span> with zero simulated hardware bypasses.
        </div>
      </div>
    </Card>
  );
};

