import React from "react";
import { createBrowserRouter, RouterProvider, Navigate } from "react-router-dom";
import App from "./App";
import Overview from "./pages/Overview";
import DigitalTwin from "./pages/DigitalTwin";
import LiveMonitoring from "./pages/LiveMonitoring";
import FaultLab from "./pages/FaultLab";
import Investigation from "./pages/Investigation";
import Maintenance from "./pages/Maintenance";
import Records from "./pages/Records";
import Storage from "./pages/Storage";
import Settings from "./pages/Settings";
import InvestigationReport from "./pages/InvestigationReport";
import GuidedInvestigation from "./pages/GuidedInvestigation";
import JudgeDemoMode from "./pages/JudgeDemoMode";
import Methodology from "./pages/Methodology";
import Login from "./pages/Login";
import { ProtectedRoute } from "./components/auth/ProtectedRoute";

const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/",
    element: (
      <ProtectedRoute>
        <App />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <Navigate to="/overview" replace /> },
      { path: "overview", element: <Overview /> },
      { path: "digital-twin", element: <DigitalTwin /> },
      { path: "live-monitoring", element: <LiveMonitoring /> },
      {
        path: "fault-lab",
        element: (
          <ProtectedRoute requiredRoles={["admin", "lead_pe", "field_technician"]}>
            <FaultLab />
          </ProtectedRoute>
        ),
      },
      { path: "investigation", element: <Investigation /> },
      { path: "guided-investigation", element: <GuidedInvestigation /> },
      { path: "judge-demo", element: <JudgeDemoMode /> },
      { path: "methodology", element: <Methodology /> },
      {
        path: "maintenance",
        element: (
          <ProtectedRoute requiredRoles={["admin", "lead_pe", "field_technician"]}>
            <Maintenance />
          </ProtectedRoute>
        ),
      },
      { path: "records", element: <Records /> },
      { path: "report", element: <InvestigationReport /> },
      { path: "investigation-report", element: <InvestigationReport /> },
      {
        path: "storage",
        element: (
          <ProtectedRoute requiredRoles={["admin", "lead_pe"]}>
            <Storage />
          </ProtectedRoute>
        ),
      },
      { path: "settings", element: <Settings /> },
    ],
  },
  {
    path: "*",
    element: <Navigate to="/login" replace />,
  },
]);

const AppRouter: React.FC = () => <RouterProvider router={router} />;

export default AppRouter;
