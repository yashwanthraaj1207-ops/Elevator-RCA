// src/simulation/engine.ts
/**
 * Deterministic Shared Simulation Engine for ELEVATOR-RCA Prototype.
 *
 * Implements:
 * - Healthy startup by default (all sensors strictly within normal baseline ranges).
 * - Multi-floor elevator kinematics (12 floors: Ground to Floor 11, 0.0m to 35.2m).
 * - Continuous automatic passenger cycling with realistic door operations.
 * - Cumulative motor operating time & operating cycle (trips) tracking.
 * - Time & cycle-dependent component degradation models (e.g. bearing wear, motor thermal rise, brake slip).
 * - Multi-sample persistence confirmation (3 consecutive samples) to eliminate false alarms.
 * - Hysteresis reset rule to prevent alert flickering.
 * - Single-event confirmed fault tripping, safety stop interlock, and diagnostic hooks.
 * - Independent fault tracking, verified repair retest clearance, and pristine simulation resets.
 *
 * NOTE: Simulation research prototype only; not certified for physical control.
 */

import {
  FloorDefinition,
  PRESET_FLOORS,
  FLOOR_HEIGHT_METERS,
  DoorState,
  TravelPhase,
} from "./floors";

export type Status = "normal" | "warning" | "fault";

export interface SensorReading {
  timestamp: number; // ms since simulation start
  value: number;
}

export interface SensorData {
  name: string;
  unit: string;
  readings: SensorReading[];
  status: Status;
  baseline: number;
  warnThreshold: number;
  critThreshold: number;
  consecutiveWarnSamples?: number;
  consecutiveCritSamples?: number;
}

export interface FaultScenario {
  id: string;
  name: string;
  description: string;
  affectedComponent: string;
  severity: "warning" | "fault";
  sensorDeltas: Record<string, number>;
  expectedSymptoms: string[];
  inhibitsMovement?: boolean; // Critical faults inhibit movement and take elevator OUT OF SERVICE
}

export type OperatingState =
  | "IDLE"
  | "PRE_START_CHECK"
  | "STARTING"
  | "RUNNING"
  | "FAULT_DETECTED"
  | "CONTROLLED_STOP"
  | "DIAGNOSING"
  | "REPAIR_IN_PROGRESS"
  | "RESTART_CHECK"
  | "RECOVERY_VERIFICATION"
  | "REPAIR_VERIFICATION"
  | "RETURN_TO_SERVICE"
  | "STOPPED"
  | "ERROR"
  | "READY"
  | "DOORS_OPENING"
  | "DOORS_OPEN"
  | "DOORS_CLOSING"
  | "ACCELERATING"
  | "MOVING"
  | "DECELERATING"
  | "ARRIVING"
  | "SIMULATED_SAFETY_STOP"
  | "UNDER_INSPECTION"
  | "UNDER_REPAIR"
  | "RECOVERY"
  | "RETURNING_TO_GROUND"
  | "SERVICE_READY";

export interface MotionState {
  currentFloor: number; // 0 to 11 (0 = Ground)
  targetFloor: number;
  direction: "UP" | "DOWN" | "IDLE";
  speed: number; // m/s
  position: number; // meters from pit (0 to 35.2m)
  doorProgress: number; // 0% closed, 100% open
  doorState: DoorState;
  travelPhase: TravelPhase;
  operatingState: OperatingState;
  brakeEngaged: number; // 100% holding, 0% released
  payloadMass: number; // kg
  serviceState: "IN_SERVICE" | "OUT_OF_SERVICE" | "RECOVERY_MODE";
  callQueue: number[];
  recoveryPermitted: boolean;
  groundReturnInProgress: boolean;
}

export interface DegradationConfig {
  enabled: boolean;
  scenarioKey: string;
  scenarioName: string;
  affectedComponent: string;
  triggerMetric: "motor_time" | "operating_cycles" | "sim_time";
  triggerThreshold: number; // e.g. 20 (motor seconds) or 2 (trips)
  rampDuration: number; // e.g. 20 (seconds from 0% to 100%)
  sensorDeltas: Record<string, number>;
}

export type DegradationStage =
  | "dormant"
  | "degrading_healthy"
  | "warning_envelope"
  | "critical_fault"
  | "repaired";

export interface DegradationState {
  currentDegradation: number; // 0.0 to 1.0 (0% to 100%)
  stage: DegradationStage;
  affectedComponent: string;
  affectedSensor: string;
  elapsedSinceTrigger: number;
  triggerReached: boolean;
}

export interface SimulationSnapshot {
  time: number;
  cumulativeMotorTime: number;
  operatingCycles: number;
  motion: MotionState;
  sensors: Record<string, { value: number; status: Status; unit: string }>;
  activeFault?: FaultScenario;
  degradationStage: DegradationStage;
  eventDescription?: string;
}

export const BASELINE_CHANNELS: Record<string, Omit<SensorData, "readings" | "status">> = {
  "Motor Temperature": {
    name: "Motor Temperature",
    unit: "°C",
    baseline: 42.0,
    warnThreshold: 55.0,
    critThreshold: 70.0,
  },
  "Motor Current": {
    name: "Motor Current",
    unit: "A",
    baseline: 12.5,
    warnThreshold: 18.0,
    critThreshold: 24.0,
  },
  "Vibration": {
    name: "Vibration",
    unit: "g",
    baseline: 0.04,
    warnThreshold: 0.09,
    critThreshold: 0.15,
  },
  "Elevator Speed": {
    name: "Elevator Speed",
    unit: "m/s",
    baseline: 1.5,
    warnThreshold: 1.75,
    critThreshold: 2.0,
  },
  "Cabin Position": {
    name: "Cabin Position",
    unit: "m",
    baseline: 0.0, // starts at Ground floor (0m)
    warnThreshold: 36.5,
    critThreshold: 37.5,
  },
  "Payload Mass": {
    name: "Payload Mass",
    unit: "kg",
    baseline: 450,
    warnThreshold: 1350,
    critThreshold: 1600,
  },
  "Door State": {
    name: "Door State",
    unit: "%",
    baseline: 0,
    warnThreshold: 110,
    critThreshold: 125,
  },
  "Brake State": {
    name: "Brake State",
    unit: "%",
    baseline: 0,
    warnThreshold: 110,
    critThreshold: 125,
  },
};

export class SimulationEngine {
  private time: number = 0;
  private running: boolean = false;
  private cumulativeMotorTime: number = 0;
  private operatingCycles: number = 0;
  private autoCycleEnabled: boolean = true;
  private isInstantInjection: boolean = false;

  private sensors: Record<string, SensorData> = {};
  private channelStats: Record<
    string,
    {
      consecutiveWarn: number;
      consecutiveCrit: number;
      status: Status;
    }
  > = {};

  private motion: MotionState = {
    currentFloor: 0, // Ground
    targetFloor: 0,
    direction: "IDLE",
    speed: 0,
    position: 0.0,
    doorProgress: 0,
    doorState: "CLOSED",
    travelPhase: "IDLE",
    operatingState: "IDLE",
    brakeEngaged: 100,
    payloadMass: 450,
    serviceState: "IN_SERVICE",
    callQueue: [],
    recoveryPermitted: true,
    groundReturnInProgress: false,
  };

  private activeFault?: FaultScenario;
  private floors: FloorDefinition[] = PRESET_FLOORS;

  // Operating-time-dependent degradation state
  private degradationConfig: DegradationConfig = {
    enabled: false,
    scenarioKey: "bearing_degradation",
    scenarioName: "Main Drive Bearing Degradation",
    affectedComponent: "bearing_main",
    triggerMetric: "motor_time",
    triggerThreshold: 20,
    rampDuration: 20,
    sensorDeltas: {
      Vibration: 0.12,
      "Motor Temperature": 14.0,
    },
  };

  private degradationState: DegradationState = {
    currentDegradation: 0,
    stage: "dormant",
    affectedComponent: "bearing_main",
    affectedSensor: "Vibration",
    elapsedSinceTrigger: 0,
    triggerReached: false,
  };

  private newFaultConfirmed: boolean = false;
  private newWarningConfirmed: boolean = false;
  private timelineHistory: SimulationSnapshot[] = [];
  private static readonly MAX_TIMELINE_HISTORY = 300;

  constructor() {
    this.reset();
  }

  start() {
    this.running = true;
    if (this.motion.serviceState === "IN_SERVICE" && this.motion.operatingState === "IDLE") {
      this.motion.operatingState = "READY";
    }
    // If starting from idle with empty queue and autoCycle is enabled, schedule travel to Floor 4
    if (
      this.autoCycleEnabled &&
      this.motion.travelPhase === "IDLE" &&
      this.motion.callQueue.length === 0 &&
      this.motion.serviceState === "IN_SERVICE"
    ) {
      this.requestFloor(4);
    }
  }

  setAutoCycle(enabled: boolean) {
    this.autoCycleEnabled = enabled;
  }

  isAutoCycleEnabled(): boolean {
    return this.autoCycleEnabled;
  }

  pause() {
    this.running = false;
  }

  emergencyStop() {
    this.motion.serviceState = "OUT_OF_SERVICE";
    this.motion.operatingState = "SIMULATED_SAFETY_STOP";
    this.motion.speed = 0;
    this.motion.direction = "IDLE";
    this.motion.travelPhase = "IDLE";
    this.motion.brakeEngaged = 100;
    this.motion.callQueue = [];
    this.motion.recoveryPermitted = false;
    this.motion.groundReturnInProgress = false;
  }

  toggleDoorCycle() {
    if (this.motion.travelPhase === "IDLE" && this.motion.speed === 0) {
      if (this.motion.doorState === "CLOSED") {
        this.motion.doorState = "OPENING";
        this.motion.operatingState = "DOORS_OPENING";
        this.motion.doorProgress = 50;
      } else {
        this.motion.doorState = "CLOSING";
        this.motion.operatingState = "DOORS_CLOSING";
        this.motion.doorProgress = 50;
      }
    }
  }

  setOperatingState(state: OperatingState) {
    this.motion.operatingState = state;
  }

  setFloors(floors: FloorDefinition[]) {
    this.floors = floors;
  }

  setDegradationConfig(config: Partial<DegradationConfig>) {
    this.degradationConfig = {
      ...this.degradationConfig,
      ...config,
    };
  }

  startDegradationRun(scenario: FaultScenario, config?: Partial<DegradationConfig>) {
    this.degradationConfig = {
      enabled: true,
      scenarioKey: scenario.id,
      scenarioName: scenario.name,
      affectedComponent: scenario.affectedComponent,
      triggerMetric: config?.triggerMetric || "motor_time",
      triggerThreshold: config?.triggerThreshold ?? 20,
      rampDuration: config?.rampDuration ?? 20,
      sensorDeltas: { ...scenario.sensorDeltas },
    };

    const primarySensor = Object.keys(scenario.sensorDeltas)[0] || "Vibration";

    this.degradationState = {
      currentDegradation: 0,
      stage: "dormant",
      affectedComponent: scenario.affectedComponent,
      affectedSensor: primarySensor,
      elapsedSinceTrigger: 0,
      triggerReached: false,
    };

    this.isInstantInjection = false;

    // Ensure simulation is running
    if (!this.running) {
      this.start();
    }
  }

  clearDegradation() {
    this.degradationConfig.enabled = false;
    this.degradationState = {
      currentDegradation: 0,
      stage: "dormant",
      affectedComponent: "bearing_main",
      affectedSensor: "Vibration",
      elapsedSinceTrigger: 0,
      triggerReached: false,
    };
  }

  reset() {
    this.time = 0;
    this.running = false;
    this.cumulativeMotorTime = 0;
    this.operatingCycles = 0;
    this.activeFault = undefined;
    this.isInstantInjection = false;
    this.newFaultConfirmed = false;
    this.newWarningConfirmed = false;

    this.clearDegradation();

    this.motion = {
      currentFloor: 0,
      targetFloor: 0,
      direction: "IDLE",
      speed: 0,
      position: 0.0,
      doorProgress: 0,
      doorState: "CLOSED",
      travelPhase: "IDLE",
      operatingState: "IDLE",
      brakeEngaged: 100,
      payloadMass: 450,
      serviceState: "IN_SERVICE",
      callQueue: [],
      recoveryPermitted: true,
      groundReturnInProgress: false,
    };

    const initial: Record<string, SensorData> = {};
    const initStats: Record<string, { consecutiveWarn: number; consecutiveCrit: number; status: Status }> = {};

    for (const [key, meta] of Object.entries(BASELINE_CHANNELS)) {
      initial[key] = {
        ...meta,
        readings: [{ timestamp: 0, value: meta.baseline }],
        status: "normal",
        consecutiveWarnSamples: 0,
        consecutiveCritSamples: 0,
      };
      initStats[key] = {
        consecutiveWarn: 0,
        consecutiveCrit: 0,
        status: "normal",
      };
    }
    this.sensors = initial;
    this.channelStats = initStats;
    this.timelineHistory = [];
    this.recordCurrentSnapshot("System baseline initialized");
  }

  requestFloor(targetFloorIndex: number): boolean {
    if (targetFloorIndex < 0 || targetFloorIndex >= this.floors.length) {
      return false;
    }

    if (this.motion.serviceState === "OUT_OF_SERVICE" && !this.motion.groundReturnInProgress) {
      return false;
    }

    if (this.motion.currentFloor === targetFloorIndex && this.motion.travelPhase === "IDLE") {
      this.motion.doorState = "OPENING";
      this.motion.operatingState = "DOORS_OPENING";
      this.motion.doorProgress = 50;
      return true;
    }

    if (!this.motion.callQueue.includes(targetFloorIndex)) {
      this.motion.callQueue.push(targetFloorIndex);
    }

    if (this.motion.travelPhase === "IDLE") {
      this.motion.targetFloor = targetFloorIndex;
    }

    return true;
  }

  returnToGround(): boolean {
    if (this.motion.serviceState === "OUT_OF_SERVICE" && !this.motion.recoveryPermitted) {
      return false;
    }
    this.motion.groundReturnInProgress = true;
    this.motion.operatingState = "RETURNING_TO_GROUND";
    this.motion.callQueue = [0];
    this.motion.targetFloor = 0;
    return true;
  }

  injectFault(fault: FaultScenario) {
    this.activeFault = fault;
    this.isInstantInjection = true;

    if (fault.severity === "fault" || fault.inhibitsMovement) {
      this.motion.serviceState = "OUT_OF_SERVICE";
      this.motion.operatingState = "SIMULATED_SAFETY_STOP";
      this.motion.speed = 0;
      this.motion.direction = "IDLE";
      this.motion.travelPhase = "IDLE";
      this.motion.brakeEngaged = 100;
      this.motion.callQueue = [];
      this.motion.recoveryPermitted = false;
      this.motion.groundReturnInProgress = false;
    } else {
      this.motion.operatingState = "FAULT_DETECTED";
    }
  }

  clearFault() {
    this.activeFault = undefined;
    this.isInstantInjection = false;
    this.clearDegradation();

    // Reset channel stats to clear persisted trips
    for (const key of Object.keys(this.channelStats)) {
      this.channelStats[key] = {
        consecutiveWarn: 0,
        consecutiveCrit: 0,
        status: "normal",
      };
    }
  }

  setServiceState(state: "IN_SERVICE" | "OUT_OF_SERVICE" | "RECOVERY_MODE") {
    this.motion.serviceState = state;
    if (state === "IN_SERVICE") {
      this.motion.operatingState = "READY";
      this.motion.recoveryPermitted = true;
      this.motion.groundReturnInProgress = false;
    } else if (state === "RECOVERY_MODE") {
      this.motion.operatingState = "RECOVERY";
    } else {
      this.motion.operatingState = "SIMULATED_SAFETY_STOP";
    }
  }

  setRecoveryPermitted(permitted: boolean) {
    this.motion.recoveryPermitted = permitted;
  }

  consumeNewFaultConfirmed(): boolean {
    const val = this.newFaultConfirmed;
    this.newFaultConfirmed = false;
    return val;
  }

  consumeNewWarningConfirmed(): boolean {
    const val = this.newWarningConfirmed;
    this.newWarningConfirmed = false;
    return val;
  }

  /**
   * Deterministic 1s tick generator
   */
  tick() {
    if (!this.running) return;

    this.time += 1;

    // 1. Accumulate cumulative motor run time when speed > 0
    if (this.motion.speed > 0) {
      this.cumulativeMotorTime += 1;
    }

    // 2. Kinematics & Continuous Operation
    if (this.motion.serviceState !== "OUT_OF_SERVICE" || this.motion.groundReturnInProgress) {
      if (this.motion.travelPhase === "IDLE" && this.motion.callQueue.length > 0) {
        this.motion.targetFloor = this.motion.callQueue[0];
      }

      const targetElevation = this.motion.targetFloor * FLOOR_HEIGHT_METERS;
      const currentPos = this.motion.position;
      const dist = targetElevation - currentPos;

      if (Math.abs(dist) > 0.05) {
        this.motion.doorProgress = 0;
        this.motion.doorState = "CLOSED";
        this.motion.brakeEngaged = 0;

        const dir = dist > 0 ? "UP" : "DOWN";
        this.motion.direction = dir;

        const absDist = Math.abs(dist);
        let targetSpeed = 1.5;
        if (this.motion.groundReturnInProgress) {
          this.motion.operatingState = "RETURNING_TO_GROUND";
        }

        if (absDist < 1.0) {
          this.motion.travelPhase = "DECELERATING";
          if (!this.motion.groundReturnInProgress) this.motion.operatingState = "DECELERATING";
          targetSpeed = 0.5;
        } else if (absDist < 2.0) {
          this.motion.travelPhase = "LEVELING";
          if (!this.motion.groundReturnInProgress) this.motion.operatingState = "ARRIVING";
          targetSpeed = 0.9;
        } else {
          this.motion.travelPhase = "CRUISING";
          if (!this.motion.groundReturnInProgress) this.motion.operatingState = "MOVING";
          targetSpeed = 1.5;
        }

        const step = targetSpeed * 1.0;
        if (dir === "UP") {
          this.motion.position = Math.min(targetElevation, currentPos + step);
        } else {
          this.motion.position = Math.max(targetElevation, currentPos - step);
        }
        this.motion.speed = targetSpeed;
      } else {
        // Arrived at floor
        this.motion.position = targetElevation;
        this.motion.currentFloor = this.motion.targetFloor;
        this.motion.direction = "IDLE";
        this.motion.speed = 0;
        this.motion.travelPhase = "IDLE";
        this.motion.brakeEngaged = 100;

        if (this.motion.callQueue.length > 0 && this.motion.callQueue[0] === this.motion.currentFloor) {
          this.motion.callQueue.shift();
        }

        // Realistic sequential Door Cycle upon floor arrival
        if (this.motion.doorState === "CLOSED" && this.motion.doorProgress === 0) {
          this.motion.doorState = "OPENING";
          this.motion.operatingState = "DOORS_OPENING";
          this.motion.doorProgress = 60;
        } else if (this.motion.doorState === "OPENING") {
          this.motion.doorState = "OPEN";
          this.motion.operatingState = "DOORS_OPEN";
          this.motion.doorProgress = 100;
        } else if (this.motion.doorState === "OPEN") {
          this.motion.doorState = "CLOSING";
          this.motion.operatingState = "DOORS_CLOSING";
          this.motion.doorProgress = 40;
        } else {
          // Door fully closed - trip cycle completed
          this.motion.doorState = "CLOSED";
          this.motion.operatingState = this.motion.serviceState === "IN_SERVICE" ? "READY" : "IDLE";
          this.motion.doorProgress = 0;

          // Increment operating cycles counter
          this.operatingCycles += 1;

          // Continuous automatic travel dispatch during normal operation
          if (
            this.autoCycleEnabled &&
            this.motion.serviceState === "IN_SERVICE" &&
            this.motion.callQueue.length === 0
          ) {
            const AUTO_SCHEDULE = [4, 8, 11, 6, 2, 0];
            const nextFloor = AUTO_SCHEDULE[this.operatingCycles % AUTO_SCHEDULE.length];
            this.requestFloor(nextFloor);
          }
        }

        if (this.motion.groundReturnInProgress && this.motion.currentFloor === 0) {
          this.motion.groundReturnInProgress = false;
        }
      }
    } else {
      // OUT OF SERVICE: Stationary
      this.motion.operatingState = "SIMULATED_SAFETY_STOP";
      this.motion.speed = 0;
      this.motion.direction = "IDLE";
      this.motion.travelPhase = "IDLE";
      this.motion.brakeEngaged = 100;
      this.motion.doorState = "CLOSED";
      this.motion.doorProgress = 0;
    }

    // 3. Operating-Time-Dependent Degradation Progress
    if (this.degradationConfig.enabled) {
      let metricValue = this.cumulativeMotorTime;
      if (this.degradationConfig.triggerMetric === "operating_cycles") {
        metricValue = this.operatingCycles;
      } else if (this.degradationConfig.triggerMetric === "sim_time") {
        metricValue = this.time;
      }

      if (metricValue >= this.degradationConfig.triggerThreshold) {
        this.degradationState.triggerReached = true;
        this.degradationState.elapsedSinceTrigger += 1;

        const ramp = Math.max(1, this.degradationConfig.rampDuration);
        this.degradationState.currentDegradation = Math.min(
          1.0,
          this.degradationState.elapsedSinceTrigger / ramp
        );

        if (this.degradationState.currentDegradation < 0.35) {
          this.degradationState.stage = "degrading_healthy";
        } else if (this.degradationState.currentDegradation < 0.7) {
          this.degradationState.stage = "warning_envelope";
        } else {
          this.degradationState.stage = "critical_fault";
        }
      } else {
        this.degradationState.triggerReached = false;
        this.degradationState.currentDegradation = 0;
        this.degradationState.stage = "dormant";
      }
    }

    // 4. Sensor Dynamics Synthesis
    const baseWave = Math.sin(this.time / 8) * 0.5;
    const newSensors: Record<string, SensorData> = {};

    let detectedCriticalFaultOnTick = false;
    let detectedWarningOnTick = false;

    for (const [key, meta] of Object.entries(BASELINE_CHANNELS)) {
      let nominalVal = meta.baseline;

      switch (key) {
        case "Motor Temperature":
          nominalVal = meta.baseline + (this.time % 60) * 0.05 + baseWave * 0.8;
          break;
        case "Motor Current":
          nominalVal =
            this.motion.speed > 0
              ? (this.motion.direction === "UP" ? 14.2 : 9.8) + baseWave * 0.8
              : 2.1;
          break;
        case "Vibration":
          nominalVal =
            this.motion.speed > 0
              ? 0.032 + Math.abs(Math.sin(this.time / 3)) * 0.012
              : 0.008;
          break;
        case "Elevator Speed":
          nominalVal = this.motion.speed;
          break;
        case "Cabin Position":
          nominalVal = this.motion.position;
          break;
        case "Payload Mass":
          nominalVal = this.motion.payloadMass;
          break;
        case "Door State":
          nominalVal = this.motion.doorProgress;
          break;
        case "Brake State":
          nominalVal = this.motion.brakeEngaged;
          break;
      }

      // Delta from direct fault injection
      let delta = this.activeFault?.sensorDeltas[key] ?? 0;

      // Delta from gradual operational degradation
      if (this.degradationConfig.enabled && this.degradationState.currentDegradation > 0) {
        const degDelta =
          (this.degradationConfig.sensorDeltas[key] ?? 0) *
          this.degradationState.currentDegradation;
        delta += degDelta;
      }

      const finalValue = Math.max(0, nominalVal + delta);

      // Raw unconfirmed threshold evaluation
      let rawStatus: Status = "normal";
      if (key === "Brake State") {
        if (
          this.activeFault?.affectedComponent === "brake_assembly" ||
          this.degradationState.affectedComponent === "brake_assembly"
        ) {
          rawStatus = delta > 30 ? "fault" : delta > 15 ? "warning" : "normal";
        } else {
          rawStatus = "normal";
        }
      } else if (key === "Door State") {
        if (
          this.activeFault?.affectedComponent === "door_system" ||
          this.degradationState.affectedComponent === "door_system"
        ) {
          rawStatus = delta > 30 ? "fault" : delta > 15 ? "warning" : "normal";
        } else {
          rawStatus = "normal";
        }
      } else if (key === "Cabin Position") {
        if (finalValue > meta.critThreshold) {
          rawStatus = "fault";
        } else if (finalValue > meta.warnThreshold) {
          rawStatus = "warning";
        } else {
          rawStatus = "normal";
        }
      } else {
        if (finalValue >= meta.critThreshold) {
          rawStatus = "fault";
        } else if (finalValue >= meta.warnThreshold) {
          rawStatus = "warning";
        } else {
          rawStatus = "normal";
        }
      }

      // 5. Multi-Sample Persistence Confirmation & Hysteresis
      const stats = this.channelStats[key] || {
        consecutiveWarn: 0,
        consecutiveCrit: 0,
        status: "normal",
      };

      const confirmationNeeded = this.isInstantInjection ? 1 : 3;

      if (rawStatus === "fault") {
        stats.consecutiveCrit += 1;
        stats.consecutiveWarn += 1;
        if (stats.consecutiveCrit >= confirmationNeeded) {
          stats.status = "fault";
          detectedCriticalFaultOnTick = true;
        }
      } else if (rawStatus === "warning") {
        stats.consecutiveCrit = Math.max(0, stats.consecutiveCrit - 1);
        stats.consecutiveWarn += 1;
        if (stats.consecutiveWarn >= confirmationNeeded) {
          stats.status = "warning";
          detectedWarningOnTick = true;
        }
      } else {
        // Hysteresis clearing
        if (finalValue <= meta.warnThreshold * 0.92) {
          stats.consecutiveCrit = 0;
          stats.consecutiveWarn = 0;
          stats.status = "normal";
        }
      }

      this.channelStats[key] = stats;

      const prevReadings = this.sensors[key]?.readings || [];
      const updatedReadings = [
        ...prevReadings,
        { timestamp: this.time * 1000, value: finalValue },
      ].slice(-60);

      newSensors[key] = {
        ...meta,
        readings: updatedReadings,
        status: stats.status,
        consecutiveWarnSamples: stats.consecutiveWarn,
        consecutiveCritSamples: stats.consecutiveCrit,
      };
    }

    this.sensors = newSensors;

    // 6. Confirmed Critical Fault Shutdown Policy
    if (detectedCriticalFaultOnTick) {
      if (this.motion.serviceState !== "OUT_OF_SERVICE") {
        this.motion.serviceState = "OUT_OF_SERVICE";
        this.motion.operatingState = "SIMULATED_SAFETY_STOP";
        this.motion.speed = 0;
        this.motion.direction = "IDLE";
        this.motion.travelPhase = "IDLE";
        this.motion.brakeEngaged = 100;
        this.motion.callQueue = [];
        this.motion.recoveryPermitted = false;
        this.motion.groundReturnInProgress = false;

        // Auto-instantiate activeFault scenario from degradation config if not set
        if (!this.activeFault && this.degradationConfig.enabled) {
          this.activeFault = {
            id: this.degradationConfig.scenarioKey,
            name: this.degradationConfig.scenarioName,
            description: `Operational degradation confirmed on ${this.degradationConfig.affectedComponent} after ${this.cumulativeMotorTime}s runtime.`,
            affectedComponent: this.degradationConfig.affectedComponent,
            severity: "fault",
            sensorDeltas: { ...this.degradationConfig.sensorDeltas },
            expectedSymptoms: [
              `Critical sensor threshold exceeded on ${this.degradationState.affectedSensor}`,
              "Emergency safety stop engaged",
            ],
            inhibitsMovement: true,
          };
        }

        this.newFaultConfirmed = true;
      }
    } else if (detectedWarningOnTick && !detectedCriticalFaultOnTick) {
      this.newWarningConfirmed = true;
    }

    // 7. Deterministic Replay Snapshot Recording
    this.recordCurrentSnapshot();
  }

  private recordCurrentSnapshot(eventDesc?: string) {
    const sensorSnapshots: Record<string, { value: number; status: Status; unit: string }> = {};
    for (const [k, v] of Object.entries(this.sensors)) {
      const latestReading = v.readings[v.readings.length - 1];
      sensorSnapshots[k] = {
        value: latestReading ? latestReading.value : v.baseline,
        status: v.status,
        unit: v.unit,
      };
    }

    const snap: SimulationSnapshot = {
      time: this.time,
      cumulativeMotorTime: this.cumulativeMotorTime,
      operatingCycles: this.operatingCycles,
      motion: { ...this.motion, callQueue: [...this.motion.callQueue] },
      sensors: sensorSnapshots,
      activeFault: this.activeFault ? { ...this.activeFault } : undefined,
      degradationStage: this.degradationState.stage,
      eventDescription: eventDesc,
    };

    this.timelineHistory.push(snap);
    if (this.timelineHistory.length > SimulationEngine.MAX_TIMELINE_HISTORY) {
      this.timelineHistory.shift();
    }
  }

  getTimelineHistory(): SimulationSnapshot[] {
    return [...this.timelineHistory];
  }

  getSnapshotAtTime(t: number): SimulationSnapshot | undefined {
    return this.timelineHistory.find((s) => s.time === t);
  }

  getState() {
    return {
      time: this.time,
      running: this.running,
      cumulativeMotorTime: this.cumulativeMotorTime,
      operatingCycles: this.operatingCycles,
      sensors: this.sensors,
      activeFault: this.activeFault,
      motion: this.motion,
      floors: this.floors,
      degradationConfig: this.degradationConfig,
      degradationState: this.degradationState,
      newFaultConfirmed: this.newFaultConfirmed,
      newWarningConfirmed: this.newWarningConfirmed,
      timelineHistory: this.timelineHistory,
    };
  }
}

export const engine = new SimulationEngine();
