// src/pages/Login.tsx
/**
 * Certified Engineer Authentication Workstation for ELEVATOR-RCA
 *
 * Integrated with Supabase Authentication (@supabase/supabase-js)
 * Features:
 * - Supabase Email & Password Login with session persistence
 * - Supabase User Registration with Certified Role assignment & metadata
 * - Supabase Password Recovery Flow with email dispatch
 * - Offline / Demo Mode fallback for field technicians working in shielded elevator shafts
 * - One-click instant login ("Quick Evaluator Access - Lead PE")
 * - Selectable demo technician cards with auto-fill
 * - Complete adherence to industrial theme (charcoal, sage, warm amber, coral - zero blue)
 */

import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";
import { useElevatorStore } from "../simulation/store";
import { CertifiedRole } from "../types/auth";
import { DEMO_CREDENTIALS_HINT } from "../auth/maintenanceAuth";
import { isSupabaseConfigured } from "../lib/supabase";
import {
  ShieldCheck,
  Lock,
  Mail,
  User,
  Key,
  Eye,
  EyeOff,
  AlertCircle,
  Building2,
  Info,
  LogOut,
  ArrowRight,
  Cpu,
  CheckCircle2,
  Sun,
  Moon,
  Zap,
  Radio,
  UserPlus,
  RefreshCw,
  BadgeCheck,
  Wifi,
  WifiOff,
} from "lucide-react";
import { Button } from "../components/ui/Button";

type AuthMode = "login" | "register" | "forgot_password" | "offline_demo";

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  const {
    user,
    session,
    profile,
    isLoading: authLoading,
    isOnline,
    isOfflineMode,
    signInWithEmail,
    signUpWithEmail,
    resetPasswordForEmail,
    signOut,
    loginOfflineDemo,
  } = useAuth();

  const assetId = useElevatorStore((s) => s.assetId);

  // Form mode: login | register | forgot_password | offline_demo
  const [authMode, setAuthMode] = useState<AuthMode>("login");

  // Form inputs
  const [email, setEmail] = useState<string>("technician@elevator-rca.io");
  const [password, setPassword] = useState<string>("elevator!tech4812");
  const [fullName, setFullName] = useState<string>("M. Vance");
  const [role, setRole] = useState<CertifiedRole>("field_technician");
  const [badgeNumber, setBadgeNumber] = useState<string>("BT-4812");
  const [inputAssetId, setInputAssetId] = useState<string>(assetId);
  const [offlineUsername, setOfflineUsername] = useState<string>("tech_vance");

  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Default destination is /overview unless user was redirected from a specific protected page
  const from = (location.state as any)?.from?.pathname || "/overview";

  // Handle Login submission
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!email.trim() || !password) {
      setErrorMessage("Please enter both email and password.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await signInWithEmail(email, password);
      if (res.success) {
        navigate(from, { replace: true });
      } else {
        setErrorMessage(res.error || "Authentication failed. Please verify credentials.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Handle Registration submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!email.trim() || !password || !fullName.trim()) {
      setErrorMessage("Please fill in all required fields.");
      return;
    }

    if (password.length < 6) {
      setErrorMessage("Password must be at least 6 characters long.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await signUpWithEmail(email, password, fullName, role, badgeNumber);
      if (res.success) {
        if (res.confirmationRequired) {
          setSuccessMessage(
            "Account created successfully! A confirmation link has been sent to your email. Please verify your address to log in."
          );
        } else {
          setSuccessMessage("Account created and authenticated successfully!");
          setTimeout(() => navigate(from, { replace: true }), 1000);
        }
      } else {
        setErrorMessage(res.error || "Failed to create certified account.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Handle Password Reset submission
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!email.trim()) {
      setErrorMessage("Please enter your registered email address.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await resetPasswordForEmail(email);
      if (res.success) {
        setSuccessMessage("Password reset email sent! Please check your inbox for instructions.");
      } else {
        setErrorMessage(res.error || "Failed to send password recovery email.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Handle Offline / Demo Login
  const handleOfflineLogin = (selectedRole: CertifiedRole = "lead_pe") => {
    setErrorMessage(null);
    setSuccessMessage(null);
    loginOfflineDemo(selectedRole, inputAssetId);
    navigate(from, { replace: true });
  };

  // Quick 1-click Demo Entry
  const handleQuickDemo = (userKey: string) => {
    const hint = DEMO_CREDENTIALS_HINT.find((c) => c.username === userKey);
    if (!hint) return;

    if (isSupabaseConfigured) {
      // In Supabase mode, auto-fill standard credentials or login offline
      setEmail(`${userKey}@elevator-rca.io`);
      setPassword(hint.pass);
    }

    const targetRole: CertifiedRole =
      userKey === "pe_topson" ? "lead_pe" : userKey === "admin_sys" ? "admin" : "field_technician";

    handleOfflineLogin(targetRole);
  };

  const activeSessionUser = profile || user;

  return (
    <div className="min-h-screen w-full bg-app text-text-primary flex flex-col justify-between p-4 md:p-8 transition-colors select-none">
      {/* Top Bar: Brand, Elevator Status & Theme Toggle */}
      <header className="max-w-5xl w-full mx-auto flex items-center justify-between pb-6 border-b border-border">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-surface border border-border flex items-center justify-center shrink-0 shadow-subtle">
            <div className="w-5 h-5 rounded-md bg-sage flex items-center justify-center">
              <span className="text-xs font-black text-[#171916] font-mono leading-none">
                E
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-text-primary font-mono">
                ELEVATOR<span className="text-sage">·RCA</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sage/15 border border-sage/30 text-sage font-semibold uppercase">
                v1.1.0
              </span>
            </div>
            <p className="text-[11px] text-text-muted">
              Causal AI Diagnostics & 3D Digital Twin Workstation
            </p>
          </div>
        </div>

        {/* Right Status & Theme Controls */}
        <div className="flex items-center gap-3">
          {/* Cloud vs Offline Status Pill */}
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface border border-border text-xs font-mono">
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-sage" />
                <span className="text-sage font-bold">Cloud Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-warm" />
                <span className="text-amber-warm font-bold">Offline Cache</span>
              </>
            )}
          </div>

          {/* Target Asset Connection Status */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-surface border border-border text-xs">
            <Radio className="w-3.5 h-3.5 text-sage animate-pulse" />
            <span className="text-text-muted font-mono">Target:</span>
            <span className="font-mono font-bold text-text-primary">{assetId}</span>
          </div>

          {/* Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg bg-surface border border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors flex items-center justify-center shadow-subtle"
            title={`Switch to ${theme === "dark" ? "Light (Ivory)" : "Dark (Graphite)"} Mode`}
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <Sun className="w-4 h-4 text-amber-warm transition-transform duration-200 rotate-0 hover:rotate-45" />
            ) : (
              <Moon className="w-4 h-4 text-text-primary transition-transform duration-200 -rotate-12 hover:rotate-0" />
            )}
          </button>
        </div>
      </header>

      {/* Main Center Workstation Card */}
      <main className="max-w-2xl w-full mx-auto py-8 space-y-6">
        {/* Hero Title & Subtitle */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-sage/15 border border-sage/30 text-sage shadow-card mb-1">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-text-primary">
            Certified Engineer Authentication
          </h1>
          <p className="text-xs md:text-sm text-text-secondary max-w-lg mx-auto">
            Secure Supabase authentication for certified elevator technicians, lead engineers, and field safety auditors.
          </p>
        </div>

        {/* Instant 1-Click Demo Launch Pill */}
        {!session && !isOfflineMode && (
          <div className="p-3.5 rounded-xl bg-card border border-sage/40 shadow-card flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-xs">
              <div className="w-7 h-7 rounded-lg bg-sage/20 text-sage flex items-center justify-center shrink-0">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-text-primary block">
                  Quick Evaluator & Demo Access
                </span>
                <span className="text-[11px] text-text-muted">
                  Instant certified login as Lead Diagnostic PE (N. Topson)
                </span>
              </div>
            </div>
            <Button
              variant="primary"
              disabled={submitting}
              onClick={() => handleQuickDemo("pe_topson")}
              className="w-full sm:w-auto px-4 py-2 text-xs font-bold flex items-center justify-center gap-1.5 shrink-0"
            >
              <span>Instant Launch (Lead PE)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}

        {/* Main Authentication Card */}
        <div className="bg-card border border-border rounded-xl shadow-elevated p-6 space-y-5">
          {session || isOfflineMode ? (
            /* Active Certified Session View */
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-surface border border-sage/40 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-sage font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-sage" />
                    {isOfflineMode ? "Offline Certified Session Active" : "Supabase Certified Session Active"}
                  </span>
                  <span className="text-[10px] font-mono text-text-muted">
                    {isOfflineMode ? "Local Vault" : "Cloud Token Verified"}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                  <div>
                    <span className="text-text-muted text-[11px] block">Technician Name:</span>
                    <span className="font-bold text-text-primary text-sm">
                      {profile?.full_name || user?.email || "Certified Engineer"}
                    </span>
                  </div>
                  <div>
                    <span className="text-text-muted text-[11px] block">Role Designation:</span>
                    <span className="font-mono font-bold text-sage uppercase px-2 py-0.5 rounded bg-sage/15 border border-sage/30 inline-block mt-0.5">
                      {profile?.role || "field_technician"}
                    </span>
                  </div>
                  <div>
                    <span className="text-text-muted text-[11px] block">Badge Number:</span>
                    <span className="font-mono font-semibold text-text-primary">
                      {profile?.badge_number || "BT-4812"}
                    </span>
                  </div>
                  <div>
                    <span className="text-text-muted text-[11px] block">Target Elevator:</span>
                    <span className="font-mono text-text-secondary">{assetId} (North Tower)</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <Button
                  variant="primary"
                  onClick={() => navigate(from, { replace: true })}
                  className="w-full flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-bold"
                >
                  <span>Enter Project Workspace</span>
                  <ArrowRight className="w-4 h-4" />
                </Button>

                <Button
                  variant="secondary"
                  onClick={signOut}
                  className="w-full sm:w-auto flex items-center justify-center gap-1.5 text-xs text-coral hover:bg-coral/10 border-coral/30 py-2.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out</span>
                </Button>
              </div>
            </div>
          ) : (
            /* Authentication Tabs & Forms */
            <div className="space-y-4">
              {/* Mode Switcher Tabs */}
              <div className="flex p-1 rounded-lg bg-surface border border-border text-xs gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode("login");
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className={`flex-1 py-1.5 rounded-md font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                    authMode === "login"
                      ? "bg-card text-text-primary shadow-subtle border border-border"
                      : "text-text-secondary hover:text-text-primary"
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAuthMode("register");
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className={`flex-1 py-1.5 rounded-md font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                    authMode === "register"
                      ? "bg-card text-text-primary shadow-subtle border border-border"
                      : "text-text-secondary hover:text-text-primary"
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAuthMode("forgot_password");
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className={`flex-1 py-1.5 rounded-md font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                    authMode === "forgot_password"
                      ? "bg-card text-text-primary shadow-subtle border border-border"
                      : "text-text-secondary hover:text-text-primary"
                  }`}
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Recovery</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAuthMode("offline_demo");
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className={`flex-1 py-1.5 rounded-md font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                    authMode === "offline_demo"
                      ? "bg-card text-text-primary shadow-subtle border border-border"
                      : "text-text-secondary hover:text-text-primary"
                  }`}
                >
                  <Radio className="w-3.5 h-3.5 text-amber-warm" />
                  <span>Offline</span>
                </button>
              </div>

              {/* Status Alert Banners */}
              {errorMessage && (
                <div className="p-3 rounded-lg bg-coral/15 border border-coral/40 text-coral text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{errorMessage}</span>
                </div>
              )}

              {successMessage && (
                <div className="p-3 rounded-lg bg-sage/15 border border-sage/40 text-sage text-xs flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{successMessage}</span>
                </div>
              )}

              {/* 1. Supabase Sign In Form */}
              {authMode === "login" && (
                <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
                  <div className="space-y-1">
                    <label className="font-semibold text-text-primary flex items-center justify-between">
                      <span>Engineer Work Email</span>
                      <span className="font-mono text-[10px] text-text-muted">Supabase Auth</span>
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="technician@elevator-rca.io"
                        className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-surface border border-border text-xs text-text-primary placeholder:text-text-muted focus:outline-none focus:border-sage transition-colors font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-text-primary flex items-center justify-between">
                      <span>Password</span>
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-[10px] text-text-secondary hover:text-text-primary flex items-center gap-1 font-mono"
                      >
                        {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showPassword ? "Hide" : "Show"}</span>
                      </button>
                    </label>
                    <div className="relative">
                      <Key className="w-4 h-4 text-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? "text" : "password"}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full pl-9 pr-9 py-2.5 rounded-lg bg-surface border border-border text-xs text-text-primary placeholder:text-text-muted focus:outline-none focus:border-sage transition-colors font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 text-[11px]">
                    <span className="text-text-muted font-mono">
                      Target: <strong className="text-text-primary">{assetId}</strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => setAuthMode("forgot_password")}
                      className="text-sage hover:underline"
                    >
                      Forgot password?
                    </button>
                  </div>

                  <Button
                    type="submit"
                    variant="primary"
                    disabled={submitting}
                    className="w-full py-2.5 text-xs font-bold flex items-center justify-center gap-2 mt-2"
                  >
                    {submitting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Verifying with Supabase...</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        <span>Sign In with Supabase</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </Button>
                </form>
              )}

              {/* 2. Supabase Register Form */}
              {authMode === "register" && (
                <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="font-semibold text-text-primary">Full Name</label>
                      <input
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="M. Vance"
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-semibold text-text-primary">Certified Role</label>
                      <select
                        value={role}
                        onChange={(e) => setRole(e.target.value as CertifiedRole)}
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
                      >
                        <option value="field_technician">Field Technician</option>
                        <option value="lead_pe">Lead PE Engineer</option>
                        <option value="admin">System Administrator</option>
                        <option value="apprentice">Apprentice Technician</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-text-primary">Work Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="engineer@elevator-rca.io"
                      className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="font-semibold text-text-primary">Password (min 6 chars)</label>
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-semibold text-text-primary">License / Badge ID</label>
                      <input
                        type="text"
                        value={badgeNumber}
                        onChange={(e) => setBadgeNumber(e.target.value)}
                        placeholder="BT-4812"
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    variant="primary"
                    disabled={submitting}
                    className="w-full py-2.5 text-xs font-bold flex items-center justify-center gap-2 mt-2"
                  >
                    {submitting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Creating Supabase Profile...</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Register Certified Engineer Account</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </Button>
                </form>
              )}

              {/* 3. Password Recovery Form */}
              {authMode === "forgot_password" && (
                <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5 text-xs">
                  <div className="p-3 rounded-lg bg-surface border border-border text-[11px] text-text-secondary leading-relaxed">
                    Enter your certified engineer email. We will dispatch a password recovery link through Supabase Auth service.
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-text-primary">Registered Email Address</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="technician@elevator-rca.io"
                      className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setAuthMode("login")}
                      className="flex-1 text-xs"
                    >
                      Back to Sign In
                    </Button>
                    <Button
                      type="submit"
                      variant="primary"
                      disabled={submitting}
                      className="flex-1 text-xs font-bold"
                    >
                      {submitting ? "Sending Recovery..." : "Send Recovery Link"}
                    </Button>
                  </div>
                </form>
              )}

              {/* 4. Offline / Demo Mode */}
              {authMode === "offline_demo" && (
                <div className="space-y-3.5 text-xs">
                  <div className="p-3 rounded-lg bg-amber-warm/10 border border-amber-warm/30 text-amber-warm text-[11px] leading-relaxed flex items-start gap-2">
                    <Radio className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>
                      <strong>Offline Shaft Mode:</strong> Intended for elevator hoistways and machine rooms without cellular or cloud connectivity. Operates the complete digital twin, simulation engine, and fault lab locally.
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="font-semibold text-text-primary">Target Asset</label>
                      <input
                        type="text"
                        value={inputAssetId}
                        onChange={(e) => setInputAssetId(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="font-semibold text-text-primary">Technician ID</label>
                      <input
                        type="text"
                        value={offlineUsername}
                        onChange={(e) => setOfflineUsername(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => handleOfflineLogin("field_technician")}
                      className="text-xs"
                    >
                      Enter as Field Tech
                    </Button>
                    <Button
                      type="button"
                      variant="primary"
                      onClick={() => handleOfflineLogin("lead_pe")}
                      className="text-xs font-bold"
                    >
                      Enter as Lead PE
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Demo Credentials Quick-Selection Cards */}
        <div className="bg-card border border-border rounded-xl p-4 space-y-3 shadow-card">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-text-primary flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-sage" />
              Certified Demonstration Profiles:
            </span>
            <span className="text-[10px] font-mono text-text-muted">Click to auto-fill or instant launch</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {DEMO_CREDENTIALS_HINT.map((c) => (
              <div
                key={c.username}
                className="p-3 rounded-lg bg-surface hover:bg-surface-hover border border-border text-left transition-all hover:border-sage/50 flex flex-col justify-between gap-2 group"
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-text-primary group-hover:text-sage transition-colors">
                      {c.username}
                    </span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-card border border-border text-text-muted uppercase">
                      {c.role.split(" ")[0]}
                    </span>
                  </div>
                  <div className="font-mono text-[10px] text-text-secondary truncate">
                    {c.role}
                  </div>
                  <div className="text-[10px] text-text-muted font-mono">
                    Asset: ELEV-001
                  </div>
                </div>

                <div className="flex items-center gap-1.5 pt-1 border-t border-border/50">
                  <button
                    type="button"
                    onClick={() => {
                      setEmail(`${c.username}@elevator-rca.io`);
                      setPassword(c.pass);
                      setAuthMode("login");
                    }}
                    className="flex-1 py-1 px-1.5 rounded text-[10px] font-mono text-text-secondary hover:text-text-primary hover:bg-card border border-transparent hover:border-border transition-colors text-center"
                  >
                    Fill
                  </button>
                  <button
                    type="button"
                    disabled={submitting}
                    onClick={() => handleQuickDemo(c.username)}
                    className="flex-1 py-1 px-1.5 rounded text-[10px] font-mono font-bold text-sage hover:bg-sage/15 border border-sage/30 transition-colors text-center"
                  >
                    1-Click In
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Demonstration Disclaimer Note */}
        <div className="p-3.5 rounded-xl bg-card border border-amber-warm/40 text-xs flex items-start gap-3 shadow-card">
          <Info className="w-4 h-4 text-amber-warm shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <div className="font-bold text-amber-warm font-mono uppercase tracking-wider text-[10px]">
              Prototype Security & Demonstration Notice
            </div>
            <p className="text-text-secondary text-[11px] leading-relaxed">
              This application is connected to live Supabase cloud project (<code className="font-mono text-sage">vfhtxpjkgkoezxeutwco</code>) for user authentication and audit synchronization, with full offline vault resilience for elevator hoistways without internet connectivity.
            </p>
          </div>
        </div>
      </main>

      {/* Bottom Footer */}
      <footer className="max-w-5xl w-full mx-auto pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-text-muted font-mono">
        <div>ELEVATOR-RCA • Explainable Causal AI & Digital Twin System</div>
        <div>Supabase Auth & Cloud Database Ready</div>
      </footer>
    </div>
  );
};

export default Login;
