// testWorkflow.ts
/**
 * Comprehensive Automated Verification Suite for ELEVATOR-RCA Research Prototype
 *
 * Acceptance Tests:
 * Test A: Healthy Startup - All components start healthy, no false alarms, normal sensor ranges
 * Test B: Normal Multi-Floor Operation - Cabin travels, levels, opens/closes doors, brake holds/releases without premature faults
 * Test C: Delayed Operating-Time-Dependent Degradation - Progressive bearing wear, warning threshold, confirmed multi-sample critical fault
 * Test D: Long-Running Stability - Accelerated cycles, bounded 60-sample telemetry window, cumulative metrics tracking
 * Test E: Maintenance Retest & Return-to-Service - Negative retest blocks restart, verified repair clears fault, Ground return certifies IN_SERVICE
 * Test F: Simulation Baseline Reset - Degradation cleared, sensors restored to baseline, time and counters reset
 * Test G: Canonical Fault Scenarios & RCA Diagnostic Hypotheses
 * Test H: Maintenance Authentication Adapter & RBAC Gatekeepers
 * Test I: Prerequisite-Gated Archival & Immutable Audit Trail Integrity
 */

import { useElevatorStore, ALL_FAULT_SCENARIOS } from "./src/simulation/store";
import { maintenanceAuthAdapter } from "./src/auth/maintenanceAuth";
import { evaluateComponentHealth } from "./src/simulation/componentHealth";
import { ComponentId } from "./src/components/digitalTwin/componentMapping";
import * as fs from "fs";
import * as path from "path";
import { getAudioMuted, setAudioMuted, playWarningBeep, playCriticalBeep } from "./src/utils/audioAnnouncement";
import { executeAutomatedBenchmark } from "./src/simulation/benchmark";
import { evaluateDataQuality } from "./src/simulation/dataQuality";
import { supabase, isSupabaseConfigured } from "./src/lib/supabase";
import { syncService } from "./src/lib/syncService";

const ALL_COMPONENTS: ComponentId[] = [
  "shaft_frame",
  "cabin_body",
  "cabin_floor",
  "door_left",
  "door_right",
  "door_operator",
  "door_system",
  "traction_motor",
  "traction_sheave",
  "bearing_main",
  "brake_assembly",
  "counterweight",
  "guide_rail_left",
  "guide_rail_right",
  "suspension_ropes",
  "position_encoder",
  "sensor_assembly",
  "safety_buffers",
  "electrical_controller",
];

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ FAILED: ${message}`);
    process.exit(1);
  } else {
    console.log(`  ✓ ${message}`);
  }
}

async function runTestSuite() {
  console.log("===============================================================");
  console.log("   ELEVATOR-RCA COMPREHENSIVE AUTOMATED VERIFICATION SUITE");
  console.log("===============================================================\n");

  // =========================================================================
  // TEST A: Healthy Startup
  // =========================================================================
  console.log("[TEST A] Healthy Startup Verification...");
  useElevatorStore.getState().resetSimulation();
  useElevatorStore.getState().startSimulation();

  let state = useElevatorStore.getState();
  assert(state.running === true, "Simulation running after start");
  assert(state.activeFault === undefined, "No active fault at startup");
  assert(state.faultAlertDismissed === true, "Fault alert modal dismissed at startup");
  assert(state.diagnostic === undefined, "No diagnostic incident open at startup");
  assert(state.motion.serviceState === "IN_SERVICE", "Elevator begins in IN_SERVICE state");

  // Verify all sensor readings are in nominal ranges
  const sensorChannels = [
    "Motor Temperature",
    "Motor Current",
    "Vibration",
    "Elevator Speed",
    "Cabin Position",
    "Payload Mass",
    "Door State",
    "Brake State",
  ];
  for (const ch of sensorChannels) {
    const s = state.sensors[ch];
    assert(!!s, `Sensor channel "${ch}" is present`);
    assert(s.status === "normal", `Sensor "${ch}" initial status is "normal" (got "${s.status}")`);
    const val = s.readings.slice(-1)[0]?.value ?? 0;
    assert(val <= s.critThreshold, `Sensor "${ch}" value (${val}) is within critical threshold (${s.critThreshold})`);
  }

  // Verify all 19 components evaluate as NORMAL with >= 90% health and 0 anomalies
  for (const compId of ALL_COMPONENTS) {
    const health = evaluateComponentHealth(compId, state.sensors, undefined, state.time);
    assert(health.operationalState === "NORMAL", `Component "${compId}" operationalState is NORMAL`);
    assert(health.healthScore >= 90, `Component "${compId}" healthScore is ${health.healthScore}% (>= 90%)`);
    assert(health.detectedAnomalies.length === 0, `Component "${compId}" has 0 detected anomalies`);
  }
  console.log(">> Test A (Healthy Startup) PASSED.\n");

  // =========================================================================
  // TEST B: Normal Multi-Floor Operation
  // =========================================================================
  console.log("[TEST B] Normal Multi-Floor Kinematic Operation (No Premature False Alarms)...");
  
  // Disable auto-cycle during explicit manual trip testing
  useElevatorStore.getState().setAutoCycle(false);

  // Trip 1: Ground to Floor 4
  assert(useElevatorStore.getState().requestFloor(4), "Request to Floor 4 accepted");
  // Advance simulation to travel, level, open doors, close doors
  for (let i = 0; i < 30; i++) {
    useElevatorStore.getState().tick();
    if (useElevatorStore.getState().motion.currentFloor === 4) break;
  }
  state = useElevatorStore.getState();
  assert(state.motion.currentFloor === 4, `Cabin reached Floor 4 (got ${state.motion.currentFloor})`);
  assert(state.activeFault === undefined, "No premature fault after traveling to Floor 4");

  // Trip 2: Floor 4 to Top Floor 11 (testing upper-floor position limit 35.2m without false alarm)
  assert(useElevatorStore.getState().requestFloor(11), "Request to Top Floor 11 accepted");
  for (let i = 0; i < 35; i++) {
    useElevatorStore.getState().tick();
    if (useElevatorStore.getState().motion.currentFloor === 11) break;
  }
  state = useElevatorStore.getState();
  assert(state.motion.currentFloor === 11, `Cabin reached Top Floor 11 (${state.motion.position.toFixed(1)}m)`);
  assert(state.sensors["Cabin Position"].status === "normal", `Cabin position sensor status at Floor 11 is "normal"`);
  assert(state.activeFault === undefined, "No position overtravel false alarm at top floor");

  // Cycle door open and close at Floor 11
  useElevatorStore.getState().toggleDoorCycle();
  for (let i = 0; i < 5; i++) {
    useElevatorStore.getState().tick();
  }
  state = useElevatorStore.getState();
  // Check Door State (100% open) & Brake State (100% engaged) at stop
  assert(state.sensors["Door State"].status === "normal", "Door State 100% opening does not trigger false alarm");
  assert(state.sensors["Brake State"].status === "normal", "Brake State holding engagement does not trigger false alarm");

  // Trip 3: Return to Ground Floor
  assert(useElevatorStore.getState().requestFloor(0), "Request to Ground accepted");
  for (let i = 0; i < 40; i++) {
    useElevatorStore.getState().tick();
    if (useElevatorStore.getState().motion.currentFloor === 0) break;
  }
  state = useElevatorStore.getState();
  assert(state.motion.currentFloor === 0, `Cabin returned to Ground Floor (got ${state.motion.currentFloor})`);
  assert(state.cumulativeMotorTime > 0, `Cumulative motor run time tracked (${state.cumulativeMotorTime.toFixed(1)}s)`);
  assert(state.activeFault === undefined, "Cabin healthy across full multi-floor trips");
  
  // Re-enable auto-cycle
  useElevatorStore.getState().setAutoCycle(true);
  console.log(">> Test B (Normal Multi-Floor Operation) PASSED.\n");

  // =========================================================================
  // TEST C: Delayed Operating-Time-Dependent Degradation
  // =========================================================================
  console.log("[TEST C] Delayed Operating-Time-Dependent Degradation (Bearing Wear)...");
  
  // Configure degradation: trigger when cumulative motor time reaches current + 4s, ramp over 8s
  const currentMotorTime = useElevatorStore.getState().cumulativeMotorTime;
  const triggerAt = currentMotorTime + 4; // 4 seconds of motor travel needed
  const rampDuration = 8; // 8 seconds of wear ramp

  useElevatorStore.getState().startDegradationRun("bearing_degradation", {
    triggerMetric: "motor_time",
    triggerThreshold: triggerAt,
    rampDuration: rampDuration,
  });

  // Verify degradation run is active in store
  assert(useElevatorStore.getState().degradationConfig.enabled === true, "Degradation run is enabled");
  assert(useElevatorStore.getState().degradationState.stage === "dormant", "Degradation stage starts as 'dormant'");

  // Dispatch elevator to Floor 6 to accumulate motor time
  useElevatorStore.getState().requestFloor(6);

  // Phase 1: Advance ticks while below trigger threshold -> should remain healthy
  let reachedTrigger = false;
  for (let i = 0; i < 30; i++) {
    useElevatorStore.getState().tick();
    state = useElevatorStore.getState();
    if (state.cumulativeMotorTime < triggerAt) {
      assert(state.degradationState.stage === "dormant", "Remains in dormant before threshold");
      assert(state.activeFault === undefined, "No fault triggered before threshold");
    } else {
      reachedTrigger = true;
      break;
    }
  }
  assert(reachedTrigger, `Successfully reached trigger threshold (${triggerAt.toFixed(1)}s motor time)`);

  // Phase 2: Advance through ramp -> stage enters warning_envelope/critical_fault, vibration ramps up, warning appears
  let sawWarning = false;
  for (let i = 0; i < 40; i++) {
    useElevatorStore.getState().tick();
    state = useElevatorStore.getState();
    if (
      state.degradationState.stage === "warning_envelope" ||
      state.degradationState.stage === "critical_fault"
    ) {
      if (state.sensors["Vibration"].status === "warning") {
        sawWarning = true;
      }
    }
    if (state.activeFault) break;
  }
  assert(sawWarning, "Degradation produced confirmed 'warning' status on Vibration channel");

  // Phase 3: Continue running until critical limit is confirmed via 3 consecutive samples
  for (let i = 0; i < 30; i++) {
    if (useElevatorStore.getState().activeFault) break;
    useElevatorStore.getState().tick();
  }
  state = useElevatorStore.getState();
  assert(state.activeFault !== undefined, "Critical fault confirmed and injected into activeFault");
  assert(state.activeFault?.affectedComponent === "bearing_main", `Affected component is bearing_main (got ${state.activeFault?.affectedComponent})`);
  assert(state.faultAlertDismissed === false, "Fault alert modal triggered (faultAlertDismissed=false)");
  assert(state.motion.serviceState === "OUT_OF_SERVICE", "Service state transitioned to OUT_OF_SERVICE");
  assert(state.motion.speed === 0, "Elevator motion halted upon critical fault confirmation");
  assert(!!state.diagnostic, "Diagnostic pipeline automatically generated root-cause hypotheses");
  assert(state.diagnostic!.hypotheses[0].componentId === "bearing_main", "Top RCA hypothesis identifies bearing_main");
  console.log(">> Test C (Delayed Degradation) PASSED.\n");

  // =========================================================================
  // TEST D: Long-Running Stability & Telemetry Bounds
  // =========================================================================
  console.log("[TEST D] Long-Running Stability & Window Bounds...");
  // Clear fault temporarily to run accelerated simulation
  useElevatorStore.getState().clearFault();
  useElevatorStore.getState().setSimSpeed(10);
  assert(useElevatorStore.getState().simSpeed === 10, "Simulation clock multiplier set to 10x");

  for (let i = 0; i < 100; i++) {
    useElevatorStore.getState().tick();
  }
  state = useElevatorStore.getState();
  for (const ch of sensorChannels) {
    const s = state.sensors[ch];
    assert(s.readings.length <= 60, `Sensor "${ch}" rolling window strictly bounded (length=${s.readings.length} <= 60)`);
  }
  assert(state.time >= 150, `Time advances correctly under accelerated execution (${state.time} ticks)`);
  useElevatorStore.getState().setSimSpeed(1);
  console.log(">> Test D (Long-Running Stability) PASSED.\n");

  // =========================================================================
  // TEST E: Maintenance Retest, Verified Repair & Return-to-Service
  // =========================================================================
  console.log("[TEST E] Maintenance Retest & Return-to-Service Workflow...");
  
  // Re-inject critical fault to test repair verification
  const critFault = ALL_FAULT_SCENARIOS["bearing_degradation"];
  useElevatorStore.getState().injectFault(critFault);
  state = useElevatorStore.getState();
  assert(state.motion.serviceState === "OUT_OF_SERVICE", "Service is OUT_OF_SERVICE");

  // Authorize maintenance technician
  const authRes = await maintenanceAuthAdapter.login("ELEV-001", "tech_vance", "elevator!tech4812");
  assert(authRes.success === true && !!authRes.session, "Authorized technician authenticated");
  useElevatorStore.getState().loginMaintenance(authRes.session!);

  // Progress through FSM
  useElevatorStore.getState().openInvestigation();
  useElevatorStore.getState().startRepair("M. Vance (Field Tech)", "Flushed housing, replaced bearing assembly", "Roller Bearing #22214");
  useElevatorStore.getState().submitForVerification("M. Vance (Field Tech)");

  // Negative retest: should fail and block return-to-service
  const failedRetest = useElevatorStore.getState().verifyRepair("M. Vance (Field Tech)", true);
  assert(failedRetest.passed === false, "Negative retest correctly fails");
  state = useElevatorStore.getState();
  assert(state.maintenance.state === "verification_failed", "FSM in verification_failed");
  assert(state.activeFault !== undefined, "Active fault remains open on failed verification");
  assert(useElevatorStore.getState().requestRecovery() === false, "Recovery blocked after failed verification");

  // Re-repair and positive retest
  useElevatorStore.getState().startRepair("M. Vance (Field Tech)", "Verified shaft alignment and torque", "OEM Spacers");
  useElevatorStore.getState().submitForVerification("M. Vance (Field Tech)");
  const passedRetest = useElevatorStore.getState().verifyRepair("M. Vance (Field Tech)", false);
  assert(passedRetest.passed === true, "Retest passed successfully");
  state = useElevatorStore.getState();
  assert(state.maintenance.state === "repair_verified", "FSM in repair_verified");
  assert(state.activeFault === undefined, "Active fault cleared upon verified repair");
  assert(state.sensors["Vibration"].status === "normal", "Vibration sensor reset to normal status");

  // Controlled Return-to-Service: Step 1 Recovery to Ground
  const recoveryAccepted = useElevatorStore.getState().requestRecovery();
  assert(recoveryAccepted === true, "Controlled recovery to Ground floor initiated");
  assert(useElevatorStore.getState().motion.serviceState === "RECOVERY_MODE", "Elevator in RECOVERY_MODE");

  for (let i = 0; i < 40; i++) {
    useElevatorStore.getState().tick();
  }
  state = useElevatorStore.getState();
  assert(state.motion.currentFloor === 0, `Cabin reached Ground floor (floor=${state.motion.currentFloor})`);

  // Controlled Return-to-Service: Step 2 Confirm IN_SERVICE
  const restored = useElevatorStore.getState().confirmReturnToService();
  assert(restored === true, "Return-to-Service confirmed at Ground floor");
  assert(useElevatorStore.getState().motion.serviceState === "IN_SERVICE", "Service state restored to IN_SERVICE");
  console.log(">> Test E (Maintenance Retest & Return-to-Service) PASSED.\n");

  // =========================================================================
  // TEST F: Baseline Simulation Reset
  // =========================================================================
  console.log("[TEST F] Baseline Simulation Reset...");
  useElevatorStore.getState().resetSimulation();
  state = useElevatorStore.getState();

  assert(state.running === false, "Simulation stopped after reset");
  assert(state.time === 0, "Simulation time reset to 0");
  assert(state.cumulativeMotorTime === 0, "Cumulative motor time reset to 0");
  assert(state.operatingCycles === 0, "Operating cycles reset to 0");
  assert(state.activeFault === undefined, "Active fault cleared after reset");
  assert(state.diagnostic === undefined, "Diagnostic cleared after reset");
  assert(state.degradationConfig.enabled === false, "Degradation state deactivated");
  assert(state.degradationState.stage === "dormant", "Degradation stage reset to dormant");
  assert(state.sensors["Vibration"].status === "normal", "Vibration status reset to normal");
  assert(state.sensors["Motor Temperature"].status === "normal", "Motor temperature status reset to normal");
  console.log(">> Test F (Baseline Simulation Reset) PASSED.\n");

  // =========================================================================
  // TEST G: All 8 Canonical Fault Scenarios & Diagnostic RCA Pipeline
  // =========================================================================
  console.log("[TEST G] Evaluating All 8 Canonical Fault Scenarios in Diagnostic Core...");
  const scenariosToTest = [
    { key: "normal", expectedComp: "cabin_body" },
    { key: "motor_overheating", expectedComp: "traction_motor" },
    { key: "excessive_load", expectedComp: "cabin_body" },
    { key: "mechanical_vibration", expectedComp: "guide_rail_left" },
    { key: "traction_motor_fault", expectedComp: "traction_motor" },
    { key: "bearing_degradation", expectedComp: "bearing_main" },
    { key: "door_mechanism_fault", expectedComp: "door_system" },
    { key: "brake_related_fault", expectedComp: "brake_assembly" },
    { key: "encoder_fault", expectedComp: "position_encoder" },
  ];

  for (const { key, expectedComp } of scenariosToTest) {
    const scenario = ALL_FAULT_SCENARIOS[key];
    assert(!!scenario, `Scenario "${key}" exists in canonical registry`);

    useElevatorStore.getState().injectFault(scenario);
    useElevatorStore.getState().tick();

    const currState = useElevatorStore.getState();
    assert(currState.activeFault?.id === scenario.id, `Scenario "${scenario.name}" injected active fault`);

    if (key !== "normal") {
      const diag = currState.diagnostic;
      assert(!!diag, `Diagnostic investigation created for "${scenario.name}"`);
      assert(diag!.hypotheses.length > 0, `Diagnostic hypotheses generated (count=${diag!.hypotheses.length})`);

      const topHyp = diag!.hypotheses[0];
      assert(
        topHyp.componentId === expectedComp,
        `Top ranked hypothesis component matches expected "${expectedComp}" (got "${topHyp.componentId}")`
      );
      assert(topHyp.confidence > 0.5, `Confidence score is meaningful (${(topHyp.confidence * 100).toFixed(0)}%)`);
      assert(topHyp.causalChain.length > 0, `Causal chain generated (${topHyp.causalChain.length} stages)`);
    }

    useElevatorStore.getState().clearFault();
  }
  console.log(">> Test G (All Canonical Scenarios & RCA) PASSED.\n");

  // =========================================================================
  // TEST H: Authentication Adapter & RBAC Gatekeepers
  // =========================================================================
  console.log("[TEST H] Testing Maintenance Authentication Adapter & RBAC Gatekeepers...");
  const badLogin = await maintenanceAuthAdapter.login("ELEV-001", "tech_vance", "wrong_password");
  assert(badLogin.success === false, "Invalid password correctly rejected");

  const badAsset = await maintenanceAuthAdapter.login("ELEV-999", "tech_vance", "elevator!tech4812");
  assert(badAsset.success === false, "Unauthorized elevator asset correctly denied");

  const validLogin = await maintenanceAuthAdapter.login("ELEV-001", "tech_vance", "elevator!tech4812");
  assert(validLogin.success === true && !!validLogin.session, "Authorized technician login succeeded");
  console.log(">> Test H (Authentication Adapter & RBAC) PASSED.\n");

  // =========================================================================
  // TEST I: Prerequisite-Gated Archival & Immutable Audit Trail Integrity
  // =========================================================================
  // Complete repair verification on any open fault before archiving
  if (useElevatorStore.getState().maintenance.state !== "repair_verified") {
    useElevatorStore.getState().openInvestigation();
    useElevatorStore.getState().startRepair("M. Vance (Field Tech)", "Restored nominal baseline tolerances");
    useElevatorStore.getState().submitForVerification("M. Vance (Field Tech)");
    useElevatorStore.getState().verifyRepair("M. Vance (Field Tech)", false);
  }

  useElevatorStore.getState().requestArchival();
  useElevatorStore.getState().confirmArchival();
  useElevatorStore.getState().verifyBackup();
  const cleanup = useElevatorStore.getState().executeRawLogCleanup();
  assert(cleanup.success === true, "Prerequisite-gated raw log cleanup approved");

  const auditEntries = useElevatorStore.getState().maintenance.auditTrail;
  assert(auditEntries.length >= 8, `Audit trail contains comprehensive history (${auditEntries.length} logged events)`);
  console.log(">> Test I (Archival & Audit Trail) PASSED.\n");

  // =========================================================================
  // TEST J: Scenario E — Door Mechanism Obstruction & Motion Inhibition
  // =========================================================================
  console.log("[TEST J] Scenario E: Door Mechanism Obstruction, Motion Inhibition & Recovery...");
  useElevatorStore.getState().resetSimulation();
  useElevatorStore.getState().startSimulation();
  useElevatorStore.getState().setAutoCycle(false);

  // 1. Dispatch cabin to Floor 2
  assert(useElevatorStore.getState().requestFloor(2), "Request to Floor 2 accepted");
  for (let i = 0; i < 20; i++) {
    useElevatorStore.getState().tick();
    if (useElevatorStore.getState().motion.currentFloor === 2) break;
  }
  let sJ = useElevatorStore.getState();
  assert(sJ.motion.currentFloor === 2, `Cabin arrived at Floor 2 (got ${sJ.motion.currentFloor})`);

  // 2. Door cycle starts opening upon arrival; inject door mechanism fault (obstruction/safety edge)
  const doorFault = ALL_FAULT_SCENARIOS["door_mechanism_fault"];
  assert(!!doorFault, "door_mechanism_fault exists in canonical fault scenarios");
  useElevatorStore.getState().injectFault(doorFault);
  useElevatorStore.getState().tick();

  sJ = useElevatorStore.getState();
  assert(sJ.activeFault?.id === doorFault.id, `Active fault matches ${doorFault.id}`);
  assert(sJ.activeFault?.affectedComponent === "door_system", "Affected component is door_system");
  assert(sJ.motion.serviceState === "OUT_OF_SERVICE", "Service state forced OUT_OF_SERVICE due to door interlock trip");
  assert(sJ.motion.speed === 0, "Elevator speed locked to 0 m/s");
  assert(sJ.motion.brakeEngaged === 100, "Brake holding at 100% engagement");

  // 3. Attempt to dispatch while door fault active -> must be inhibited
  const dispatchBlocked = useElevatorStore.getState().requestFloor(5);
  assert(dispatchBlocked === false, "Dispatch to Floor 5 blocked while OUT_OF_SERVICE with door fault");

  for (let i = 0; i < 5; i++) {
    useElevatorStore.getState().tick();
  }
  sJ = useElevatorStore.getState();
  assert(sJ.motion.currentFloor === 2, "Cabin did not move while door interlock fault remained active");
  assert(sJ.motion.speed === 0, "Speed remained zero during inhibited movement");

  // 4. Technician repair workflow for door obstruction
  useElevatorStore.getState().openInvestigation();
  useElevatorStore.getState().startRepair(
    "M. Vance (Field Tech)",
    "Cleared obstruction in door sill guide rail and realigned safety curtain interlock",
    "Door Sill Guide Clip OEM-D44"
  );
  useElevatorStore.getState().submitForVerification("M. Vance (Field Tech)");

  // 5. Run verification re-test
  const doorRetest = useElevatorStore.getState().verifyRepair("M. Vance (Field Tech)", false);
  assert(doorRetest.passed === true, "Door repair retest passed successfully");
  sJ = useElevatorStore.getState();
  assert(sJ.maintenance.state === "repair_verified", "Maintenance FSM state is repair_verified");
  assert(sJ.activeFault === undefined, "Active fault cleared after verified repair");

  // 6. Return elevator to service via controlled recovery to Ground floor
  const doorRecovery = useElevatorStore.getState().requestRecovery();
  assert(doorRecovery === true, "Controlled recovery permitted following door repair verification");
  assert(useElevatorStore.getState().motion.serviceState === "RECOVERY_MODE", "Elevator in RECOVERY_MODE");

  for (let i = 0; i < 30; i++) {
    useElevatorStore.getState().tick();
    if (useElevatorStore.getState().motion.currentFloor === 0) break;
  }
  sJ = useElevatorStore.getState();
  assert(sJ.motion.currentFloor === 0, `Cabin safely returned to Ground floor (${sJ.motion.currentFloor})`);

  const doorRestored = useElevatorStore.getState().confirmReturnToService();
  assert(doorRestored === true, "Return-to-service confirmed at Ground floor");
  assert(useElevatorStore.getState().motion.serviceState === "IN_SERVICE", "Service state is IN_SERVICE");
  console.log(">> Test J (Scenario E: Door Obstruction & Recovery) PASSED.\n");

  // =========================================================================
  // TEST K: Scenario F — Audio Announcement & 3D Model Asset Resilience
  // =========================================================================
  console.log("[TEST K] Scenario F: Audio Announcement & 3D Model Asset Resilience...");

  // 1. Audio Mute / Unmute state controls
  const initialMute = getAudioMuted();
  assert(typeof initialMute === "boolean", "getAudioMuted returns boolean");

  setAudioMuted(true);
  assert(getAudioMuted() === true, "Audio successfully muted via setAudioMuted(true)");

  setAudioMuted(false);
  assert(getAudioMuted() === false, "Audio successfully unmuted via setAudioMuted(false)");

  // Restore initial mute state
  setAudioMuted(initialMute);

  // 2. Web Audio synthesize calls run gracefully without throwing exceptions
  await playWarningBeep();
  await playCriticalBeep();
  assert(true, "Web Audio synthesized warning and critical beeps execute without rejection");

  // 3. 3D Model GLB asset resilience & verification
  const glbPath = path.resolve(process.cwd(), "public/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb");
  assert(fs.existsSync(glbPath), `Replacement GLB model exists at: ${glbPath}`);

  const glbStat = fs.statSync(glbPath);
  assert(glbStat.size > 10 * 1024 * 1024, `GLB file size is ${glbStat.size} bytes (> 10 MB, exactly 13,257,892 bytes)`);

  // Verify ModelViewer.tsx references the exact model path
  const modelViewerPath = path.resolve(process.cwd(), "src/components/digitalTwin/ModelViewer.tsx");
  assert(fs.existsSync(modelViewerPath), "ModelViewer.tsx exists");
  const modelViewerCode = fs.readFileSync(modelViewerPath, "utf-8");
  assert(
    modelViewerCode.includes("/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb"),
    "ModelViewer.tsx references /models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb"
  );

  console.log(">> Test K (Scenario F: Audio & Model Resilience) PASSED.\n");

  // =========================================================================
  // TEST L: Sensor Replay & Deterministic Timeline Scrubbing
  // =========================================================================
  console.log("[TEST L] Sensor Replay & Deterministic Timeline Scrubbing...");
  useElevatorStore.getState().resetSimulation();
  useElevatorStore.getState().startSimulation();

  for (let i = 0; i < 15; i++) {
    useElevatorStore.getState().tick();
  }

  let hist = useElevatorStore.getState().timelineHistory;
  assert(hist.length >= 15, `Timeline history accumulated ${hist.length} snapshots (expected >= 15)`);

  const targetSnapshotTime = hist[5].time;
  useElevatorStore.getState().startReplay(targetSnapshotTime);
  assert(useElevatorStore.getState().replayMode === true, "Replay mode active after startReplay");
  assert(useElevatorStore.getState().replayTime === targetSnapshotTime, "Replay time matched target snapshot time");

  // Verify live tick advancement is frozen during replay mode
  const replayTickTime = useElevatorStore.getState().time;
  useElevatorStore.getState().tick();
  assert(useElevatorStore.getState().time === replayTickTime, "Live tick advancement strictly gated during replay mode");

  // Test seek and step
  useElevatorStore.getState().stepReplay(2);
  assert(useElevatorStore.getState().replayTime === targetSnapshotTime + 2, "stepReplay(+2) advanced replay time by 2 seconds");

  useElevatorStore.getState().stopReplay();
  assert(useElevatorStore.getState().replayMode === false, "Replay mode deactivated after stopReplay");
  assert(useElevatorStore.getState().replayTime === null, "Replay time reset to null upon return to live telemetry");
  console.log(">> Test L (Deterministic Replay Engine) PASSED.\n");

  // =========================================================================
  // TEST M: Automated Fault Benchmark Suite Execution
  // =========================================================================
  console.log("[TEST M] Automated Fault Benchmark Suite Execution...");
  const benchmarkReport = await executeAutomatedBenchmark();
  assert(benchmarkReport.totalScenarios === 7, `Benchmark executed 7 scenarios (got ${benchmarkReport.totalScenarios})`);
  assert(benchmarkReport.healthyScenariosEvaluated === 1, "Evaluated exactly 1 healthy baseline scenario");
  assert(benchmarkReport.faultScenariosEvaluated === 6, "Evaluated 6 canonical failure scenarios");
  assert(benchmarkReport.totalFalseAlarms === 0, `Zero false alarms on healthy baseline (got ${benchmarkReport.totalFalseAlarms})`);
  assert(benchmarkReport.overallSubsystemAccuracy >= 85, `Overall subsystem isolation accuracy is ${benchmarkReport.overallSubsystemAccuracy}% (expected >= 85%)`);
  assert(benchmarkReport.overallRootCauseRankingAccuracy >= 85, `Overall Top-1 root cause ranking accuracy is ${benchmarkReport.overallRootCauseRankingAccuracy}% (expected >= 85%)`);
  assert(benchmarkReport.meanDetectionDelaySeconds > 0 && benchmarkReport.meanDetectionDelaySeconds < 10, `Empirical mean detection delay is ${benchmarkReport.meanDetectionDelaySeconds}s`);
  console.log(">> Test M (Automated Benchmark Suite) PASSED.\n");

  // =========================================================================
  // TEST N: Before-and-After Verification Safety Gate
  // =========================================================================
  console.log("[TEST N] Before-and-After Verification Safety Gate...");
  useElevatorStore.getState().injectFault(ALL_FAULT_SCENARIOS.motor_overheating);
  assert(useElevatorStore.getState().motion.serviceState === "OUT_OF_SERVICE", "Service is OUT_OF_SERVICE following motor overheat");

  useElevatorStore.getState().openInvestigation();
  useElevatorStore.getState().startRepair("N. Topson", "Checked thermal coupling and replaced cooling fan");
  useElevatorStore.getState().submitForVerification("N. Topson");

  // Forced failure retest must block recovery
  const forcedFailRetest = useElevatorStore.getState().verifyRepair("N. Topson", true);
  assert(forcedFailRetest.passed === false, "Failed retest verification accurately flagged");
  assert(useElevatorStore.getState().requestRecovery() === false, "Elevator recovery strictly blocked after failed retest verification");

  // Corrective re-repair following failed verification
  useElevatorStore.getState().startRepair("N. Topson", "Replaced sensor module and thermal heat sink");
  useElevatorStore.getState().submitForVerification("N. Topson");

  // Successful retest must permit recovery
  const passedRetestVerif = useElevatorStore.getState().verifyRepair("N. Topson", false);
  assert(passedRetestVerif.passed === true, "Retest verification passed successfully");
  assert(useElevatorStore.getState().requestRecovery() === true, "Controlled recovery permitted after passing retest verification");
  console.log(">> Test N (Before-and-After Verification Safety Gate) PASSED.\n");

  // =========================================================================
  // TEST O: Maintenance Work Orders & Diagnostic Hypothesis Verdicts
  // =========================================================================
  console.log("[TEST O] Maintenance Work Orders & Diagnostic Hypothesis Verdicts...");
  useElevatorStore.getState().injectFault(ALL_FAULT_SCENARIOS.bearing_degradation);
  const curDiag = useElevatorStore.getState().diagnostic;
  assert(curDiag !== undefined && curDiag.hypotheses.length > 0, "Diagnostic generated active hypotheses");

  const topHypId = curDiag!.hypotheses[0].id;
  useElevatorStore.getState().confirmHypothesis(topHypId, "Physical micrometer check confirmed spall crater");
  const confirmedHyp = useElevatorStore.getState().diagnostic!.hypotheses.find((h) => h.id === topHypId);
  assert(confirmedHyp?.technicianVerdict === "confirmed", "Technician verdict confirmed in store");
  assert(confirmedHyp?.technicianNotes?.includes("micrometer"), "Technician notes persisted with hypothesis");

  // Work order checklist step toggle
  const activeWO = useElevatorStore.getState().maintenance.activeWorkOrder;
  assert(activeWO !== undefined, "Active maintenance work order automatically instantiated");
  if (activeWO && activeWO.inspectionSteps.length > 0) {
    const firstStepId = activeWO.inspectionSteps[0].id;
    useElevatorStore.getState().toggleWorkOrderStep(firstStepId, true);
    const updatedWO = useElevatorStore.getState().maintenance.activeWorkOrder;
    assert(updatedWO?.inspectionSteps[0].completed === true, "Work order checklist step marked completed");
  }
  console.log(">> Test O (Work Orders & Hypothesis Verdicts) PASSED.\n");

  // =========================================================================
  // TEST P: Telemetry Data Quality & Cryptographic Stream Health
  // =========================================================================
  console.log("[TEST P] Telemetry Data Quality & Cryptographic Stream Health...");
  const sP = useElevatorStore.getState();
  const dataQualityReport = evaluateDataQuality(sP.sensors, sP.time, sP.maintenance.auditTrail);
  assert(dataQualityReport.overallScore > 0, `Overall data quality score is ${dataQualityReport.overallScore}%`);
  assert(dataQualityReport.totalChannelsMonitored === Object.keys(sP.sensors).length, "All registered telemetry channels monitored");
  assert(dataQualityReport.auditTrailIntegrity.tamperFree === true, "Audit trail verified tamper-free");
  assert(dataQualityReport.syntheticDisclosures.standardReference.includes("ISO"), "Disclosures reference ISO standards");
  // =========================================================================
  // TEST Q: Supabase Client, Offline Resilience & Telemetry Sync Pipeline
  // =========================================================================
  console.log("[TEST Q] Supabase Client, Offline Resilience & Telemetry Sync Pipeline...");
  assert(typeof supabase === "object" && supabase !== null, "Supabase client instance is initialized");
  assert(typeof supabase.auth === "object", "Supabase Auth module is available");
  assert(typeof supabase.from === "function", "Supabase Database query builder is available");
  assert(isSupabaseConfigured === true, "Supabase configuration flags active credentials");

  // Verify syncService handles offline and online queueing gracefully
  const initialPending = syncService.getPendingCount();
  assert(typeof initialPending === "number", "SyncService returns numeric pending count");

  const testWO = useElevatorStore.getState().maintenance.activeWorkOrder;
  if (testWO) {
    const res = await syncService.pushWorkOrderToCloud(testWO, "test-user-id");
    assert(res.success === true, "SyncService successfully queued or sent work order to cloud");
  }

  const testAudit = useElevatorStore.getState().maintenance.auditTrail[0];
  if (testAudit) {
    const res = await syncService.pushAuditEntryToCloud(testAudit, "test-user-id");
    assert(res.success === true, "SyncService successfully queued or sent audit entry to cloud");
  }

  console.log(">> Test Q (Supabase Client & Sync Pipeline) PASSED.\n");

  console.log("===============================================================");
  console.log("  ALL TESTS PASSED! ELEVATOR-RCA PROTOYPE VERIFIED 100%");
  console.log("===============================================================");
  process.exit(0);
}

runTestSuite().catch((err) => {
  console.error("Test execution failed:", err);
  process.exit(1);
});
