// src/components/digitalTwin/ModelViewer.tsx
import React, { useEffect, useRef, useState, useMemo, useCallback } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Line } from "@react-three/drei";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader.js";
import {
  ComponentId,
  normalizeComponentId,
  getComponentVerificationBadge,
} from "./componentMapping";
import {
  segmentGlbModel,
  GeometrySegmentationReport,
  SegmentedComponentData,
} from "./geometrySegmentation";
import { useElevatorStore } from "../../simulation/store";
import { useTheme } from "../../context/ThemeContext";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import {
  AlertCircle,
  RotateCcw,
  Eye,
  EyeOff,
  Minimize2,
  Play,
  Pause,
  Compass,
  Focus,
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize,
  Layers,
  ChevronDown,
  Grid,
  RotateCw,
  Terminal,
  AlertOctagon,
  DoorOpen,
  Activity,
} from "lucide-react";
import { HierarchyInspectorModal } from "./HierarchyInspectorModal";

export const MODEL_ASSET_PATH = "/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb";
export const FALLBACK_MODEL_ASSET_PATH = "/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb";

// Cache segmented report in memory to avoid re-parsing on re-renders
let cachedSegmentationReport: GeometrySegmentationReport | null = null;

/**
 * Standard PBR Material definitions for all 18 individual components.
 * Strict compliance: Zero blue color. Distinct metallic/graphite/bronze/amber contrasts.
 */
interface MaterialProfile {
  color: string;
  roughness: number;
  metalness: number;
}

const COMPONENT_BASE_MATERIALS: Record<ComponentId, { dark: MaterialProfile; light: MaterialProfile }> = {
  traction_motor: {
    dark: { color: "#3A4236", roughness: 0.35, metalness: 0.70 }, // Heavy cast iron drive motor casing
    light: { color: "#525C4E", roughness: 0.35, metalness: 0.65 },
  },
  bearing_main: {
    dark: { color: "#9E8E6E", roughness: 0.22, metalness: 0.85 }, // Precision bronze bearing alloy
    light: { color: "#B4A688", roughness: 0.22, metalness: 0.80 },
  },
  brake_assembly: {
    dark: { color: "#4C544A", roughness: 0.38, metalness: 0.75 }, // Machined iron brake caliper
    light: { color: "#646C62", roughness: 0.38, metalness: 0.68 },
  },
  traction_sheave: {
    dark: { color: "#788275", roughness: 0.25, metalness: 0.85 }, // Machined alloy traction sheave wheel
    light: { color: "#929C8E", roughness: 0.25, metalness: 0.80 },
  },
  cabin_body: {
    dark: { color: "#8E988D", roughness: 0.30, metalness: 0.70 }, // Satin stainless passenger enclosure
    light: { color: "#B8C0B5", roughness: 0.32, metalness: 0.60 },
  },
  cabin_floor: {
    dark: { color: "#2A2E28", roughness: 0.75, metalness: 0.25 }, // Heavy textured non-slip platform floor
    light: { color: "#42483E", roughness: 0.75, metalness: 0.22 },
  },
  door_left: {
    dark: { color: "#A8B2A6", roughness: 0.20, metalness: 0.85 }, // Polished left door panel
    light: { color: "#CCD4CA", roughness: 0.22, metalness: 0.80 },
  },
  door_right: {
    dark: { color: "#A8B2A6", roughness: 0.20, metalness: 0.85 }, // Polished right door panel
    light: { color: "#CCD4CA", roughness: 0.22, metalness: 0.80 },
  },
  door_operator: {
    dark: { color: "#586254", roughness: 0.40, metalness: 0.65 }, // Header drive mechanism
    light: { color: "#768072", roughness: 0.40, metalness: 0.58 },
  },
  door_system: {
    dark: { color: "#A8B2A6", roughness: 0.20, metalness: 0.85 },
    light: { color: "#CCD4CA", roughness: 0.22, metalness: 0.80 },
  },
  counterweight: {
    dark: { color: "#363C34", roughness: 0.55, metalness: 0.60 }, // Heavy ballast sub-weights
    light: { color: "#4E554C", roughness: 0.55, metalness: 0.52 },
  },
  guide_rail_left: {
    dark: { color: "#C2CAC0", roughness: 0.18, metalness: 0.90 }, // Machined vertical polished steel T-rail
    light: { color: "#DDE2DA", roughness: 0.20, metalness: 0.85 },
  },
  guide_rail_right: {
    dark: { color: "#C2CAC0", roughness: 0.18, metalness: 0.90 }, // Machined vertical polished steel T-rail
    light: { color: "#DDE2DA", roughness: 0.20, metalness: 0.85 },
  },
  suspension_ropes: {
    dark: { color: "#B8C0B5", roughness: 0.22, metalness: 0.92 }, // Steel wire hoist cables
    light: { color: "#D2D8D0", roughness: 0.24, metalness: 0.88 },
  },
  position_encoder: {
    dark: { color: "#5A6458", roughness: 0.30, metalness: 0.75 }, // Precision encoder housing
    light: { color: "#727C70", roughness: 0.30, metalness: 0.70 },
  },
  sensor_assembly: {
    dark: { color: "#647062", roughness: 0.30, metalness: 0.75 }, // Telemetry sensors
    light: { color: "#7C887A", roughness: 0.30, metalness: 0.70 },
  },
  safety_buffers: {
    dark: { color: "#7A6840", roughness: 0.45, metalness: 0.55 }, // Industrial buffer cylinders
    light: { color: "#948052", roughness: 0.45, metalness: 0.50 },
  },
  shaft_frame: {
    dark: { color: "#222620", roughness: 0.65, metalness: 0.35 }, // Structural shaft frame and pit bedplate
    light: { color: "#3A4036", roughness: 0.65, metalness: 0.30 },
  },
  electrical_controller: {
    dark: { color: "#60685C", roughness: 0.45, metalness: 0.55 }, // Control cabinet
    light: { color: "#7A8476", roughness: 0.45, metalness: 0.50 },
  },
};

interface InteractiveComponentMeshProps {
  data: SegmentedComponentData;
  isSelected: boolean;
  isHovered: boolean;
  isFaulted: boolean;
  isExploded: boolean;
  isIsolated: boolean;
  isVisible: boolean;
  isAnySelected: boolean;
  isDark: boolean;
  visualMode: "shaded" | "diagnostic" | "wireframe";
  isDraggingRef: React.RefObject<boolean>;
  onSelect: (id: ComponentId) => void;
  onHover: (id: ComponentId | null) => void;
  onDoubleClick: (id: ComponentId) => void;
  cabinVerticalOffset: number;
  counterweightOffset: number;
  vibrationJitter: number;
  doorSlideOffset: number;
  motionDirection?: "UP" | "DOWN" | "IDLE";
  speed?: number;
}

/**
 * Individual Interactive Mesh for a physical component sub-assembly
 */
const InteractiveComponentMesh: React.FC<InteractiveComponentMeshProps> = ({
  data,
  isSelected,
  isHovered,
  isFaulted,
  isExploded,
  isIsolated,
  isVisible,
  isAnySelected,
  isDark,
  visualMode,
  isDraggingRef,
  onSelect,
  onHover,
  onDoubleClick,
  cabinVerticalOffset,
  counterweightOffset,
  vibrationJitter,
  doorSlideOffset,
  motionDirection,
  speed,
}) => {
  const meshRef = useRef<THREE.Mesh>(null!);
  const currentPos = useRef(new THREE.Vector3(0, 0, 0));

  // Determine target transform
  const targetPos = useMemo(() => {
    const p = new THREE.Vector3(0, 0, 0);

    // Apply exploded offset if active
    if (isExploded) {
      p.add(data.explodedOffset);
    }

    // Apply kinematic vertical movement based on component classification
    if (data.isCabinPart) {
      p.y += cabinVerticalOffset;
      if (data.isDoorLeft) {
        // Left door slides laterally left (-X) relative to cabin entrance
        p.x -= doorSlideOffset;
      } else if (data.isDoorRight) {
        // Right door slides laterally right (+X) relative to cabin entrance
        p.x += doorSlideOffset;
      }
    } else if (data.isCounterweight) {
      // Counterweight travels in counter-balance opposite to cabin
      p.y += counterweightOffset;
    }

    // Apply micro-vibration displacement during active vibration/bearing fault
    if (isFaulted && (data.id === "bearing_main" || data.id === "guide_rail_left")) {
      p.x += vibrationJitter;
      p.y += vibrationJitter * 0.5;
    }

    return p;
  }, [isExploded, data, cabinVerticalOffset, counterweightOffset, doorSlideOffset, isFaulted, vibrationJitter]);

  // Smooth lerp animation for translation
  useFrame((_, delta) => {
    if (meshRef.current) {
      // Lerp position smoothly to target
      currentPos.current.lerp(targetPos, Math.min(1, delta * 7.5));
      meshRef.current.position.copy(currentPos.current);
    }
  });

  // Calculate material appearance with bright, high-contrast PBR highlights & zero unintended transparency
  const materialProps = useMemo(() => {
    const isWire = visualMode === "wireframe";

    if (isSelected) {
      return {
        color: isFaulted ? "#E87568" : "#91B7A0",
        emissive: isFaulted ? "#D45648" : "#72A083",
        emissiveIntensity: 0.90,
        roughness: 0.18,
        metalness: 0.88,
        transparent: false,
        opacity: 1.0,
        wireframe: isWire,
      };
    }

    if (isFaulted) {
      return {
        color: "#E87568",
        emissive: "#A6382F",
        emissiveIntensity: 0.85,
        roughness: 0.25,
        metalness: 0.78,
        transparent: false,
        opacity: 1.0,
        wireframe: isWire,
      };
    }

    if (isHovered) {
      return {
        color: "#C2DFCE",
        emissive: "#547860",
        emissiveIntensity: 0.50,
        roughness: 0.22,
        metalness: 0.82,
        transparent: false,
        opacity: 1.0,
        wireframe: isWire,
      };
    }

    if (visualMode === "diagnostic") {
      // Diagnostic Health color-coding
      return {
        color: "#7AA48A",
        emissive: "#3D624B",
        emissiveIntensity: 0.45,
        roughness: 0.32,
        metalness: 0.7,
        transparent: false,
        opacity: 1.0,
        wireframe: false,
      };
    }

    // Base component visual palette
    const baseMat = COMPONENT_BASE_MATERIALS[data.id][isDark ? "dark" : "light"];

    // Contextual ghosting if another component is isolated
    if (isIsolated) {
      return {
        color: isDark ? "#282C24" : "#D4D0C5",
        emissive: "#000000",
        emissiveIntensity: 0.0,
        roughness: 0.6,
        metalness: 0.2,
        transparent: true,
        opacity: 0.12,
        wireframe: true, // Clean wireframe cage when isolated so central component is fully unobstructed
      };
    }

    // Focus de-emphasis when another component is selected:
    // Retain full opacity (transparent: false) to prevent depth-buffer z-fighting and fragmentation.
    // Dim diffuse tone and increase roughness so the selected component vividly pops out!
    if (isAnySelected) {
      return {
        color: baseMat.color,
        emissive: "#000000",
        emissiveIntensity: 0.0,
        roughness: Math.min(1.0, baseMat.roughness + 0.2),
        metalness: baseMat.metalness * 0.7,
        transparent: false,
        opacity: 1.0,
        wireframe: isWire,
      };
    }

    return {
      color: baseMat.color,
      emissive: "#000000",
      emissiveIntensity: 0.0,
      roughness: baseMat.roughness,
      metalness: baseMat.metalness,
      transparent: false,
      opacity: 1.0,
      wireframe: isWire,
    };
  }, [isSelected, isFaulted, isHovered, isIsolated, isAnySelected, data.id, isDark, visualMode]);

  if (!isVisible && isIsolated) {
    return null;
  }

  return (
    <group>
      <mesh
        ref={meshRef}
        geometry={data.geometry}
        userData={{ componentId: data.id }}
        castShadow
        receiveShadow
        onClick={(e) => {
          e.stopPropagation();
          if (isDraggingRef.current) return;
          onSelect(data.id);
        }}
        onDoubleClick={(e) => {
          e.stopPropagation();
          onDoubleClick(data.id);
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          document.body.style.cursor = "pointer";
          onHover(data.id);
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto";
          onHover(null);
        }}
      >
        <meshStandardMaterial
          {...materialProps}
          envMapIntensity={1.2}
          side={THREE.DoubleSide}
          depthWrite={!materialProps.transparent}
          depthTest={true}
        />
      </mesh>

      {/* Exploded Inspection Leader Line connecting to assembly origin */}
      {isExploded && isVisible && (
        <Line
          points={[
            [targetPos.x, targetPos.y, targetPos.z],
            [
              data.id === "cabin_body" || data.id === "door_system" ? 0 : 0,
              data.id === "cabin_body" || data.id === "door_system" ? cabinVerticalOffset : 0,
              0,
            ],
          ]}
          color={isFaulted ? "#E87568" : isSelected ? "#91B7A0" : "#7A8274"}
          lineWidth={1.5}
          dashed
          dashScale={20}
        />
      )}
    </group>
  );
};

/**
 * Camera Controller handling smooth target glide and camera position transition.
 * Only animates when isAnimating is explicitly set, immediately yielding control to
 * OrbitControls once target is reached or when user manually touches controls.
 */
interface CameraTransitionTarget {
  target: THREE.Vector3;
  position?: THREE.Vector3;
  isAnimating: boolean;
}

const CameraViewController: React.FC<{
  transitionTarget: CameraTransitionTarget;
  onTransitionComplete: () => void;
  controlsRef: React.RefObject<OrbitControlsImpl>;
}> = ({ transitionTarget, onTransitionComplete, controlsRef }) => {
  const { camera } = useThree();

  useFrame((_, delta) => {
    if (!transitionTarget.isAnimating || !controlsRef.current) return;

    const controls = controlsRef.current;
    const factor = Math.min(1, delta * 5.5);

    controls.target.lerp(transitionTarget.target, factor);
    if (transitionTarget.position) {
      camera.position.lerp(transitionTarget.position, factor);
    }
    controls.update();

    const targetDist = controls.target.distanceTo(transitionTarget.target);
    const posDist = transitionTarget.position
      ? camera.position.distanceTo(transitionTarget.position)
      : 0;

    if (targetDist < 0.02 && posDist < 0.02) {
      if (transitionTarget.position) {
        camera.position.copy(transitionTarget.position);
      }
      controls.target.copy(transitionTarget.target);
      controls.update();
      onTransitionComplete();
    }
  });
  return null;
};

export type CameraPreset = "isometric" | "front" | "side" | "top";

import { FloatingComponentInspector } from "./FloatingComponentInspector";
import { FloorSelectorShaft } from "./FloorSelectorShaft";

export interface ModelViewerProps {
  className?: string;
  onSelectComponent?: (id: string) => void;
  selectedComponent?: string;
  compactToolbar?: boolean;
  showFloorShaft?: boolean;
  showFloatingInspector?: boolean;
  showSimControls?: boolean;
  showSubsystemStrip?: boolean;
}

export const ModelViewer: React.FC<ModelViewerProps> = ({
  className = "h-full w-full",
  onSelectComponent,
  selectedComponent,
  compactToolbar = false,
  showFloorShaft = false,
  showFloatingInspector = false,
  showSimControls = true,
  showSubsystemStrip = true,
}) => {
  const { theme } = useTheme();
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const [loadStatus, setLoadStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [statusMessage, setStatusMessage] = useState<string>("Initializing 3D workspace...");
  const [report, setReport] = useState<GeometrySegmentationReport | null>(null);

  // Inspection & Display Modes
  const [isExploded, setIsExploded] = useState<boolean>(false);
  const [isIsolated, setIsIsolated] = useState<boolean>(false);
  const [hiddenComponents, setHiddenComponents] = useState<Set<ComponentId>>(new Set());
  const [hoveredComponentId, setHoveredComponentId] = useState<ComponentId | null>(null);

  // Viewport Settings
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [visualMode, setVisualMode] = useState<"shaded" | "diagnostic" | "wireframe">("shaded");
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const [showHierarchyModal, setShowHierarchyModal] = useState<boolean>(false);

  // Camera State (Framed dynamically to fit full 3.8m elevator assembly without cropping)
  const defaultTarget = useMemo(() => new THREE.Vector3(0, 0.1, 0), []);
  const defaultIsometricPos = useMemo(() => new THREE.Vector3(4.2, 1.4, 6.2), []);

  const [cameraTransition, setCameraTransition] = useState<CameraTransitionTarget>({
    target: defaultTarget.clone(),
    position: defaultIsometricPos.clone(),
    isAnimating: false,
  });

  const handleTransitionComplete = useCallback(() => {
    setCameraTransition((prev) => ({ ...prev, isAnimating: false }));
  }, []);

  const [activePreset, setActivePreset] = useState<CameraPreset>("isometric");
  const [presetDropdownOpen, setPresetDropdownOpen] = useState<boolean>(false);
  const [visualModeDropdownOpen, setVisualModeDropdownOpen] = useState<boolean>(false);

  const [retryTrigger, setRetryTrigger] = useState<number>(0);
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const pointerStartPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isDraggingRef = useRef<boolean>(false);

  // Store bindings
  const storeSelectedComponent = useElevatorStore((s) => s.selectedComponent);
  const storeSelectComponent = useElevatorStore((s) => s.selectComponent);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const motion = useElevatorStore((s) => s.motion);
  const running = useElevatorStore((s) => s.running);
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const pauseSimulation = useElevatorStore((s) => s.pauseSimulation);
  const resetSimulation = useElevatorStore((s) => s.resetSimulation);
  const simSpeed = useElevatorStore((s) => s.simSpeed);
  const setSimSpeed = useElevatorStore((s) => s.setSimSpeed);
  const emergencyStop = useElevatorStore((s) => s.emergencyStop);
  const toggleDoorCycle = useElevatorStore((s) => s.toggleDoorCycle);
  const requestFloor = useElevatorStore((s) => s.requestFloor);
  const floors = useElevatorStore((s) => s.floors);

  const effectiveSelectedId = normalizeComponentId(selectedComponent || storeSelectedComponent);
  const activeFaultId = normalizeComponentId(activeFault?.affectedComponent);

  // Fullscreen event listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => {
        console.error("Fullscreen request failed:", err);
      });
    } else {
      document.exitFullscreen().catch((err) => {
        console.error("Exit fullscreen failed:", err);
      });
    }
  };

  // Keyboard Navigation: Escape to cancel isolation / exit fullscreen / clear selection
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (isIsolated) {
          setIsIsolated(false);
        } else if (isExploded) {
          setIsExploded(false);
        } else if (effectiveSelectedId) {
          storeSelectComponent("");
          if (onSelectComponent) onSelectComponent("");
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isIsolated, isExploded, effectiveSelectedId, storeSelectComponent, onSelectComponent]);

  // Load and segment 3D asset into real physical component meshes
  useEffect(() => {
    if (cachedSegmentationReport) {
      if (cachedSegmentationReport.assetPath === MODEL_ASSET_PATH) {
        setReport(cachedSegmentationReport);
        setLoadStatus("success");
        setStatusMessage("Model loaded from memory cache");
        return;
      } else {
        cachedSegmentationReport = null;
      }
    }

    setLoadStatus("loading");
    setStatusMessage("Loading authentic Meshy elevator asset...");

    const loader = new GLTFLoader();
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath("/draco/");
    loader.setDRACOLoader(dracoLoader);

    const tryLoad = (path: string, isFallback: boolean = false) => {
      loader.load(
        path,
        (gltf) => {
          try {
            const segmentation = segmentGlbModel(gltf.scene);
            cachedSegmentationReport = segmentation;
            setReport(segmentation);
            setLoadStatus("success");
            setStatusMessage(`Segmented 18 physical component assemblies (${segmentation.rawTotalMeshes.toLocaleString()} meshes)`);
            dracoLoader.dispose();
          } catch (err: unknown) {
            const message = err instanceof Error ? err.message : String(err);
            setLoadStatus("error");
            setStatusMessage(`Error parsing 3D model geometry: ${message}`);
            dracoLoader.dispose();
          }
        },
        (progress) => {
          if (progress.total > 0) {
            const pct = Math.round((progress.loaded / progress.total) * 100);
            setStatusMessage(`Loading 3D asset (${pct}%)...`);
          }
        },
        (error) => {
          console.warn(`GLTF load failed for "${path}":`, error);
          if (!isFallback && FALLBACK_MODEL_ASSET_PATH !== MODEL_ASSET_PATH) {
            console.info(`Attempting fallback to "${FALLBACK_MODEL_ASSET_PATH}"...`);
            setStatusMessage("Primary asset loading failed, trying backup...");
            tryLoad(FALLBACK_MODEL_ASSET_PATH, true);
          } else {
            console.error("All GLTF loads failed:", error);
            setLoadStatus("error");
            setStatusMessage(
              `Unable to load 3D model asset from "${MODEL_ASSET_PATH}". Please verify public/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb exists.`
            );
            dracoLoader.dispose();
          }
        }
      );
    };

    tryLoad(MODEL_ASSET_PATH, false);
  }, [retryTrigger]);

  const handleSelect = useCallback(
    (id: ComponentId) => {
      storeSelectComponent(id);
      if (onSelectComponent) {
        onSelectComponent(id);
      }
    },
    [storeSelectComponent, onSelectComponent]
  );

  // Double-click to directly focus camera on component centroid
  const handleDoubleClickFocus = useCallback(
    (id: ComponentId) => {
      handleSelect(id);
      if (report?.components[id]) {
        const comp = report.components[id];
        const target = comp.localCenter.clone();
        if (isExploded) {
          target.add(comp.explodedOffset);
        }
        setCameraTransition({
          target,
          position: new THREE.Vector3(target.x + 2.8, target.y + 1.2, target.z + 3.8),
          isAnimating: true,
        });
      }
    },
    [handleSelect, report, isExploded]
  );

  // Restore Complete Assembly (resets explosion, isolation, hidden parts, and camera)
  const handleRestoreAssembly = () => {
    setIsExploded(false);
    setIsIsolated(false);
    setHiddenComponents(new Set());
    setActivePreset("isometric");
    setCameraTransition({
      target: new THREE.Vector3(0, 0.1, 0),
      position: defaultIsometricPos.clone(),
      isAnimating: true,
    });
  };

  // Fit Model: centers full model and zooms to fit full assembly in frame without cropping
  const handleFitModel = () => {
    setCameraTransition({
      target: new THREE.Vector3(0, 0.1, 0),
      position: defaultIsometricPos.clone(),
      isAnimating: true,
    });
  };

  // Camera presets with calibrated framing margins
  const applyPreset = (preset: CameraPreset) => {
    setActivePreset(preset);
    setPresetDropdownOpen(false);
    let target = new THREE.Vector3(0, 0.1, 0);

    if (effectiveSelectedId && report?.components[effectiveSelectedId]) {
      target = report.components[effectiveSelectedId].localCenter.clone();
      if (isExploded) {
        target.add(report.components[effectiveSelectedId].explodedOffset);
      }
    }

    let pos: THREE.Vector3;
    switch (preset) {
      case "front":
        pos = new THREE.Vector3(target.x, target.y + 0.3, target.z + 6.8);
        break;
      case "side":
        pos = new THREE.Vector3(target.x + 6.8, target.y + 0.3, target.z);
        break;
      case "top":
        pos = new THREE.Vector3(target.x + 0.01, target.y + 7.5, target.z + 0.01);
        break;
      case "isometric":
      default:
        pos = new THREE.Vector3(target.x + 4.2, target.y + 1.4, target.z + 6.2);
        break;
    }

    setCameraTransition({
      target,
      position: pos,
      isAnimating: true,
    });
  };

  // Zoom In / Zoom Out step helpers
  const handleZoom = (direction: "in" | "out") => {
    if (!controlsRef.current) return;
    const factor = direction === "in" ? 0.82 : 1.22;
    const camera = controlsRef.current.object;
    const target = controlsRef.current.target;
    const offset = camera.position.clone().sub(target);
    offset.multiplyScalar(factor);
    if (offset.length() >= 1.0 && offset.length() <= 16.0) {
      camera.position.copy(target.clone().add(offset));
      controlsRef.current.update();
    }
  };

  const toggleHideSelected = () => {
    if (!effectiveSelectedId) return;
    setHiddenComponents((prev) => {
      const next = new Set(prev);
      if (next.has(effectiveSelectedId)) {
        next.delete(effectiveSelectedId);
      } else {
        next.add(effectiveSelectedId);
      }
      return next;
    });
  };

  // Coordinated Kinematic Animation Variables
  // In centered 3D coordinates: Ground -> Y = -0.80m; Top Floor -> Y = +0.75m
  const maxTravelElev = Math.max(1, (floors.length - 1) * 3.2);
  const normalizedTravel = Math.max(0, Math.min(1, motion.position / maxTravelElev));
  const cabinVerticalOffset = normalizedTravel * 1.55 - 0.80;
  const counterweightOffset = -cabinVerticalOffset;
  const doorSlideOffset = (motion.doorProgress / 100) * 0.16;
  const vibrationJitter =
    activeFaultId === "bearing_main" || activeFaultId === "guide_rail_left"
      ? Math.sin(Date.now() * 0.05) * 0.025
      : 0;

  const isDark = theme === "dark";
  const canvasBg = isDark ? "#161815" : "#ECEAE1";
  const gridPrimary = isDark ? "#383E34" : "#D4D0C4";
  const gridSecondary = isDark ? "#222620" : "#E2DFD6";

  return (
    <div
      ref={containerRef}
      className={`relative flex flex-col rounded-xl border border-border overflow-hidden transition-colors ${className}`}
      style={{ backgroundColor: canvasBg }}
      onPointerDown={(e) => {
        setPresetDropdownOpen(false);
        setVisualModeDropdownOpen(false);
        pointerStartPos.current = { x: e.clientX, y: e.clientY };
        isDraggingRef.current = false;
      }}
      onPointerMove={(e) => {
        const dist = Math.hypot(
          e.clientX - pointerStartPos.current.x,
          e.clientY - pointerStartPos.current.y
        );
        if (dist > 6) {
          isDraggingRef.current = true;
        }
      }}
    >
      {/* 3D Canvas Top Left: Model Status Pill & Active Selection */}
      <div className="absolute top-3 left-3 z-20 pointer-events-auto max-w-[calc(100%-180px)]">
        <div className="flex items-center gap-2 bg-card/92 backdrop-blur-md px-3 py-1.5 rounded-lg border border-border shadow-card text-xs">
          <div
            className={`w-2 h-2 rounded-full shrink-0 ${
              loadStatus === "success"
                ? "bg-sage shadow-sm shadow-sage"
                : loadStatus === "loading"
                ? "bg-amber-warm animate-pulse"
                : "bg-coral"
            }`}
          />
          <span className="font-semibold text-text-primary truncate max-w-[140px] sm:max-w-[220px]">
            {effectiveSelectedId && report?.components[effectiveSelectedId]
              ? report.components[effectiveSelectedId].label
              : "Complete Assembly"}
          </span>
          {effectiveSelectedId && report?.components[effectiveSelectedId] && (
            <span
              className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase border shrink-0 ${
                getComponentVerificationBadge(report.components[effectiveSelectedId].verificationTier).badgeClass
              }`}
              title={report.components[effectiveSelectedId].verificationNote}
            >
              {getComponentVerificationBadge(report.components[effectiveSelectedId].verificationTier).shortLabel}
            </span>
          )}
          {isExploded && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-warm/15 text-amber-warm border border-amber-warm/30 shrink-0">
              EXPLODED
            </span>
          )}
          {isIsolated && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-sage/15 text-sage border border-sage/30 shrink-0">
              ISOLATED
            </span>
          )}
        </div>
      </div>

      {/* 3D Canvas Top Right: Action Controls & Navigation Toolbar */}
      <div className="absolute top-3 right-3 z-20 flex items-center justify-end pointer-events-auto">
        <div className="flex items-center gap-1 bg-card/92 backdrop-blur-md p-1 rounded-lg border border-border shadow-card text-xs">
          {/* Camera Preset Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setPresetDropdownOpen((prev) => !prev);
                setVisualModeDropdownOpen(false);
              }}
              className="px-2 py-1 rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary transition-colors flex items-center gap-1 border border-border text-[11px]"
              title="Camera View Angle Presets"
            >
              <span className="capitalize">{activePreset}</span>
              <ChevronDown className="w-3 h-3 text-text-muted" />
            </button>

            {presetDropdownOpen && (
              <div className="absolute top-full right-0 mt-1 w-32 bg-card/95 backdrop-blur-md border border-border rounded-lg shadow-elevated p-1 z-30 flex flex-col gap-0.5">
                {(["isometric", "front", "side", "top"] as const).map((preset) => (
                  <button
                    key={preset}
                    onClick={() => applyPreset(preset)}
                    className={`px-2 py-1 text-left rounded text-xs capitalize transition-colors ${
                      activePreset === preset
                        ? "bg-sage/20 text-sage font-semibold"
                        : "text-text-secondary hover:bg-surface hover:text-text-primary"
                    }`}
                  >
                    {preset} View
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Fit Model to View */}
          <button
            onClick={handleFitModel}
            className="p-1.5 rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary transition-colors border border-border"
            title="Fit Entire Model in View"
            aria-label="Fit Model"
          >
            <Focus className="w-3.5 h-3.5 text-sage" />
          </button>

          {/* Zoom In & Out */}
          <button
            onClick={() => handleZoom("in")}
            className="p-1.5 rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary transition-colors border border-border"
            title="Zoom In"
            aria-label="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleZoom("out")}
            className="p-1.5 rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary transition-colors border border-border"
            title="Zoom Out"
            aria-label="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>

          <div className="w-[1px] h-4 bg-border mx-0.5" />

          {/* Exploded View Toggle */}
          <button
            onClick={() => setIsExploded((prev) => !prev)}
            className={`p-1.5 sm:px-2 sm:py-1 rounded-md transition-colors flex items-center gap-1 font-medium ${
              isExploded
                ? "bg-amber-warm/20 text-amber-warm border border-amber-warm/40 font-semibold"
                : "text-text-secondary hover:text-text-primary hover:bg-surface border border-transparent"
            }`}
            title="Toggle Exploded Assembly Inspection View"
          >
            {isExploded ? <Minimize2 className="w-3.5 h-3.5" /> : <Layers className="w-3.5 h-3.5" />}
            <span className="hidden xl:inline text-[11px]">{isExploded ? "Collapse" : "Explode"}</span>
          </button>

          {/* Additional Full Controls (Hidden in compactToolbar preview) */}
          {!compactToolbar && (
            <>
              {/* Isolate Component Toggle */}
              <button
                onClick={() => setIsIsolated((prev) => !prev)}
                className={`p-1.5 sm:px-2 sm:py-1 rounded-md transition-colors flex items-center gap-1 font-medium ${
                  isIsolated
                    ? "bg-sage/20 text-sage border border-sage/40 font-semibold"
                    : "text-text-secondary hover:text-text-primary hover:bg-surface border border-transparent"
                }`}
                title="Isolate currently selected component"
              >
                <Compass className="w-3.5 h-3.5" />
                <span className="hidden xl:inline text-[11px]">{isIsolated ? "Assembly" : "Isolate"}</span>
              </button>

              {/* Hide/Show Component Toggle */}
              {effectiveSelectedId && (
                <button
                  onClick={toggleHideSelected}
                  className="p-1.5 rounded-md text-text-secondary hover:text-text-primary hover:bg-surface transition-colors border border-border"
                  title={hiddenComponents.has(effectiveSelectedId) ? "Show Component" : "Hide Component"}
                  aria-label="Toggle Component Visibility"
                >
                  {hiddenComponents.has(effectiveSelectedId) ? (
                    <Eye className="w-3.5 h-3.5 text-sage" />
                  ) : (
                    <EyeOff className="w-3.5 h-3.5 text-text-muted" />
                  )}
                </button>
              )}

              <div className="w-[1px] h-4 bg-border mx-0.5" />

              {/* Grid Helper Toggle */}
              <button
                onClick={() => setShowGrid((prev) => !prev)}
                className={`p-1.5 rounded-md transition-colors border hidden sm:inline-flex ${
                  showGrid
                    ? "bg-sage/15 text-sage border-sage/30"
                    : "bg-surface hover:bg-surface-hover text-text-muted hover:text-text-primary border-border"
                }`}
                title={showGrid ? "Hide Grid Floor" : "Show Grid Floor"}
                aria-label="Toggle Grid"
              >
                <Grid className="w-3.5 h-3.5" />
              </button>

              {/* Shading Mode Selector Dropdown */}
              <div className="relative">
                <button
                  onClick={() => {
                    setVisualModeDropdownOpen((prev) => !prev);
                    setPresetDropdownOpen(false);
                  }}
                  className={`px-2 py-1 rounded-md border flex items-center gap-1 text-[11px] transition-colors ${
                    visualMode === "shaded"
                      ? "bg-surface text-text-primary border-border"
                      : visualMode === "diagnostic"
                      ? "bg-sage/20 text-sage border-sage/40 font-semibold"
                      : "bg-amber-warm/20 text-amber-warm border-amber-warm/40 font-semibold"
                  }`}
                  title="Shading Mode"
                >
                  {visualMode === "diagnostic" && <Activity className="w-3 h-3 text-sage" />}
                  <span className="capitalize">{visualMode}</span>
                  <ChevronDown className="w-3 h-3 text-text-muted" />
                </button>

                {visualModeDropdownOpen && (
                  <div className="absolute top-full right-0 mt-1 w-32 bg-card/95 backdrop-blur-md border border-border rounded-lg shadow-elevated p-1 z-30 flex flex-col gap-0.5">
                    <button
                      onClick={() => {
                        setVisualMode("shaded");
                        setVisualModeDropdownOpen(false);
                      }}
                      className={`px-2 py-1 text-left rounded text-xs transition-colors ${
                        visualMode === "shaded"
                          ? "bg-sage/20 text-sage font-semibold"
                          : "text-text-secondary hover:bg-surface hover:text-text-primary"
                      }`}
                    >
                      Shaded
                    </button>
                    <button
                      onClick={() => {
                        setVisualMode("diagnostic");
                        setVisualModeDropdownOpen(false);
                      }}
                      className={`px-2 py-1 text-left rounded text-xs transition-colors flex items-center gap-1 ${
                        visualMode === "diagnostic"
                          ? "bg-sage/20 text-sage font-semibold"
                          : "text-text-secondary hover:bg-surface hover:text-text-primary"
                      }`}
                    >
                      <Activity className="w-3 h-3" />
                      <span>Diagnostic</span>
                    </button>
                    <button
                      onClick={() => {
                        setVisualMode("wireframe");
                        setVisualModeDropdownOpen(false);
                      }}
                      className={`px-2 py-1 text-left rounded text-xs transition-colors ${
                        visualMode === "wireframe"
                          ? "bg-amber-warm/20 text-amber-warm font-semibold"
                          : "text-text-secondary hover:bg-surface hover:text-text-primary"
                      }`}
                    >
                      Wireframe
                    </button>
                  </div>
                )}
              </div>

              {/* Auto-rotate Toggle */}
              <button
                onClick={() => setAutoRotate((prev) => !prev)}
                className={`p-1.5 rounded-md transition-colors border hidden md:inline-flex ${
                  autoRotate
                    ? "bg-sage/20 text-sage border-sage/40"
                    : "bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary border-border"
                }`}
                title={autoRotate ? "Pause Turntable Auto-Rotation" : "Enable Turntable Auto-Rotation"}
                aria-label="Toggle Auto-Rotation"
              >
                <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? "animate-spin" : ""}`} />
              </button>

              {/* Developer Hierarchy Inspector */}
              <button
                onClick={() => setShowHierarchyModal(true)}
                className="p-1.5 rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-sage transition-colors border border-border hidden lg:inline-flex"
                title="Open Developer Hierarchy & Mesh Inspector"
                aria-label="Open Hierarchy Inspector"
              >
                <Terminal className="w-3.5 h-3.5 text-sage" />
              </button>

              <div className="w-[1px] h-4 bg-border mx-0.5" />

              {/* Restore Complete Assembly */}
              <button
                onClick={handleRestoreAssembly}
                className="p-1.5 rounded-md bg-surface hover:bg-surface-hover text-text-primary transition-colors border border-border"
                title="Restore Complete Assembly to default transforms and camera"
                aria-label="Restore Assembly"
              >
                <RotateCcw className="w-3.5 h-3.5 text-sage" />
              </button>
            </>
          )}

          {/* Fullscreen Toggle */}
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-md bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary transition-colors border border-border"
            title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
            aria-label="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize className="w-3.5 h-3.5 text-sage" /> : <Maximize className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Three.js Canvas with ACESFilmic Tone Mapping and Enhanced Illumination */}
      <div className="flex-1 w-full min-h-[420px] relative">
        <Canvas
          camera={{ position: [3.8, 1.2, 5.8], fov: 38, near: 0.1, far: 100 }}
          className="h-full w-full cursor-grab active:cursor-grabbing"
          shadows
          gl={{
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: isDark ? 1.18 : 1.05,
            antialias: true,
          }}
        >
          {/* Studio Balanced 5-Point Illumination Rig (Sharp Industrial Contrast & Zero Blue) */}
          <ambientLight intensity={isDark ? 0.85 : 0.75} />
          
          {/* Key Light: High front-right neutral industrial spotlight */}
          <directionalLight
            position={[4.5, 6.5, 5.5]}
            intensity={isDark ? 1.7 : 1.4}
            color="#FFFDF8"
            castShadow
            shadow-mapSize={[2048, 2048]}
            shadow-bias={-0.00005}
          />

          {/* Fill Light: Soft neutral fill light from low front-left */}
          <directionalLight
            position={[-4.5, 3.0, 3.5]}
            intensity={isDark ? 0.9 : 0.75}
            color="#F5F0E6"
          />

          {/* Rim / Silhouette Light: Crisp edge definition separating dark steel frame from background */}
          <directionalLight
            position={[-3.0, 4.5, -4.5]}
            intensity={isDark ? 1.2 : 0.95}
            color="#EDE8DC"
          />

          {/* Machine Room Dedicated Overhead Illuminator (Calibrated distance & soft falloff) */}
          <pointLight
            position={[0, 2.4, 0.5]}
            intensity={isDark ? 0.85 : 0.65}
            color="#F5ECE0"
            distance={4.5}
          />

          {/* Pit / Buffer Low-Level Uplight Fill */}
          <pointLight
            position={[0, -2.2, 0.6]}
            intensity={isDark ? 0.65 : 0.45}
            color="#EAEFEA"
            distance={4.0}
          />

          {/* Neutral Industrial Hemisphere Illumination */}
          <hemisphereLight
            args={["#F8F6F0", isDark ? "#1C201A" : "#ECE9DF", isDark ? 0.6 : 0.5]}
          />

          {/* Camera Orbit Controls with Damping & Free Smooth Rotation */}
          <OrbitControls
            ref={controlsRef}
            enablePan={true}
            enableZoom={true}
            enableRotate={true}
            enableDamping={true}
            dampingFactor={0.08}
            rotateSpeed={0.85}
            zoomSpeed={1.0}
            panSpeed={0.8}
            minDistance={1.8}
            maxDistance={25.0}
            minPolarAngle={0.05}
            maxPolarAngle={Math.PI - 0.05}
            autoRotate={autoRotate}
            autoRotateSpeed={1.0}
            onStart={() => {
              // Immediately yield 100% control to user orbit/pan/zoom
              setCameraTransition((prev) => (prev.isAnimating ? { ...prev, isAnimating: false } : prev));
            }}
          />

          <CameraViewController
            transitionTarget={cameraTransition}
            onTransitionComplete={handleTransitionComplete}
            controlsRef={controlsRef}
          />

          {/* Industrial Precision Grid Floor */}
          {showGrid && (
            <gridHelper args={[8, 16, gridPrimary, gridSecondary]} position={[0, -2.1, 0]} />
          )}

          {/* Render Actual Decomposed Components (Direct Raycasting & Exploded Positions) */}
          {report && (
            <group>
              {/* 18 Canonical Physical Components */}
              {(Object.keys(report.components) as ComponentId[]).map((id) => {
                const compData = report.components[id];
                const isSelected = effectiveSelectedId === id;
                const isHovered = hoveredComponentId === id;
                const isFaulted = activeFaultId === id;
                const isVisible = !hiddenComponents.has(id);

                return (
                  <InteractiveComponentMesh
                    key={id}
                    data={compData}
                    isSelected={isSelected}
                    isHovered={isHovered}
                    isFaulted={isFaulted}
                    isExploded={isExploded || (isSelected && isIsolated)}
                    isIsolated={isIsolated && !isSelected}
                    isVisible={isVisible}
                    isAnySelected={!!effectiveSelectedId}
                    isDark={isDark}
                    visualMode={visualMode}
                    isDraggingRef={isDraggingRef}
                    onSelect={handleSelect}
                    onHover={setHoveredComponentId}
                    onDoubleClick={handleDoubleClickFocus}
                    cabinVerticalOffset={cabinVerticalOffset}
                    counterweightOffset={counterweightOffset}
                    vibrationJitter={vibrationJitter}
                    doorSlideOffset={doorSlideOffset}
                    motionDirection={motion.direction}
                    speed={motion.speed}
                  />
                );
              })}
            </group>
          )}
        </Canvas>

        {/* Loading Overlay */}
        {loadStatus === "loading" && (
          <div className="absolute inset-0 bg-app/75 backdrop-blur-sm flex flex-col items-center justify-center pointer-events-none z-20">
            <div className="w-8 h-8 border-2 border-sage border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-sm font-medium text-text-primary">{statusMessage}</p>
          </div>
        )}

        {/* Error / Missing Banner */}
        {loadStatus === "error" && (
          <div className="absolute inset-0 bg-app/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="max-w-md bg-card border border-coral/40 p-5 rounded-xl shadow-card space-y-3">
              <div className="flex items-center justify-center text-coral gap-2">
                <AlertCircle className="w-5 h-5" />
                <span className="font-bold text-sm">3D Model Load Error</span>
              </div>
              <p className="text-xs text-text-secondary leading-relaxed">{statusMessage}</p>
              <button
                onClick={() => setRetryTrigger((prev) => prev + 1)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface hover:bg-surface-hover text-xs font-semibold text-text-primary border border-border transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5 text-sage" />
                Retry Loading Asset
              </button>
            </div>
          </div>
        )}

        {/* Feature 1: Floor Selector Shaft LOP */}
        {showFloorShaft && <FloorSelectorShaft />}

        {/* Feature 2: Compact Floating Component Inspector */}
        {showFloatingInspector && effectiveSelectedId && (
          <FloatingComponentInspector
            componentId={effectiveSelectedId}
            onClose={() => {
              storeSelectComponent("");
              if (onSelectComponent) onSelectComponent("");
            }}
            onToggleExploded={() => setIsExploded((prev) => !prev)}
            onToggleIsolated={() => setIsIsolated((prev) => !prev)}
            isExploded={isExploded}
            isIsolated={isIsolated}
          />
        )}
      </div>

      {/* Bottom Section (OUTSIDE CANVAS: zero interference with 3D dragging) */}
      {(showSimControls || (!compactToolbar && showSubsystemStrip)) && (
        <div className="border-t border-border bg-card/95 backdrop-blur-md select-none shrink-0">
          {/* Live Simulation Engine Bar */}
          {showSimControls && (
            <div className="px-3 py-2 flex flex-wrap items-center justify-between gap-2 border-b border-border/50 text-xs">
              {/* Left: Sim Status & Primary Engine Controls */}
              <div className="flex items-center gap-2 flex-wrap">
                {/* Simulation Only badge */}
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-warm/15 text-amber-warm border border-amber-warm/30">
                  SIMULATION ONLY
                </span>

                {/* Service State Badge */}
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider border ${
                    motion.serviceState === "IN_SERVICE"
                      ? "bg-sage/15 text-sage border-sage/30"
                      : "bg-coral/20 text-coral border-coral/40 animate-pulse"
                  }`}
                >
                  {motion.serviceState === "IN_SERVICE" ? "IN SERVICE" : "OUT OF SERVICE"}
                </span>

                <div className="w-[1px] h-4 bg-border mx-0.5" />

                {/* Live Run / Pause */}
                <button
                  onClick={() => (running ? pauseSimulation() : startSimulation())}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-surface hover:bg-surface-hover text-text-primary font-semibold border border-border transition-colors"
                  title={running ? "Pause Telemetry Simulation" : "Start Live Telemetry Simulation"}
                >
                  {running ? <Pause className="w-3.5 h-3.5 text-amber-warm" /> : <Play className="w-3.5 h-3.5 text-sage" />}
                  <span>{running ? "Pause" : "Live Run"}</span>
                </button>

                {/* Emergency Stop Button */}
                <button
                  onClick={emergencyStop}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-coral/20 hover:bg-coral/30 text-coral font-bold border border-coral/40 transition-colors"
                  title="Emergency Stop: Halt motion and trip safety circuit"
                >
                  <AlertOctagon className="w-3.5 h-3.5" />
                  <span>E-STOP</span>
                </button>

                {/* Reset Simulation */}
                <button
                  onClick={resetSimulation}
                  className="p-1 rounded bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary border border-border"
                  title="Reset Simulation State to Ground Floor Normal"
                  aria-label="Reset Simulation"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>

                {/* Sim Speed Selector */}
                <div className="flex items-center border border-border rounded overflow-hidden">
                  {([1, 2, 5] as const).map((spd) => (
                    <button
                      key={spd}
                      onClick={() => setSimSpeed(spd)}
                      className={`px-2 py-1 text-[10px] font-mono transition-colors ${
                        simSpeed === spd
                          ? "bg-sage/20 text-sage font-bold"
                          : "bg-surface text-text-muted hover:text-text-primary"
                      }`}
                      title={`Simulation Clock Speed: ${spd}x`}
                    >
                      {spd}x
                    </button>
                  ))}
                </div>

                {/* Door Cycle Test Button */}
                <button
                  onClick={toggleDoorCycle}
                  className="flex items-center gap-1 px-2 py-1 rounded bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary border border-border transition-colors text-[11px]"
                  title="Test Door Open / Close cycle"
                >
                  <DoorOpen className="w-3.5 h-3.5 text-sage" />
                  <span>Door Test</span>
                </button>

                {/* Floor Target Selector */}
                <div className="flex items-center gap-1">
                  <span className="text-[11px] text-text-muted font-mono">Go to:</span>
                  <select
                    value={motion.targetFloor}
                    onChange={(e) => requestFloor(Number(e.target.value))}
                    className="bg-surface text-text-primary border border-border rounded px-2 py-1 text-[11px] font-mono focus:outline-none focus:border-sage"
                    title="Dispatch cabin to specified floor"
                  >
                    {floors.map((f) => (
                      <option key={f.index} value={f.index}>
                        {f.label} ({f.elevation.toFixed(1)}m)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Right: Live Telemetry Metrics & Operating State */}
              <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono text-text-secondary border-t sm:border-t-0 sm:border-l border-border pt-1 sm:pt-0 sm:pl-3">
                <span className="flex items-center gap-1">
                  State:{" "}
                  <strong
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      motion.operatingState === "SIMULATED_SAFETY_STOP"
                        ? "bg-coral/20 text-coral border border-coral/40"
                        : motion.operatingState.includes("DOORS")
                        ? "bg-amber-warm/20 text-amber-warm border border-amber-warm/40"
                        : motion.operatingState === "MOVING" || motion.operatingState === "ACCELERATING"
                        ? "bg-sage/20 text-sage border border-sage/40"
                        : "bg-surface text-text-primary border border-border"
                    }`}
                  >
                    {motion.operatingState}
                  </strong>
                </span>
                <span>
                  Floor: <strong className="text-text-primary font-bold">{floors[motion.currentFloor]?.label ?? motion.currentFloor}</strong>
                  <span className="text-text-muted text-[10px]"> (Target: {floors[motion.targetFloor]?.label ?? motion.targetFloor})</span>
                </span>
                <span>
                  Speed: <strong className="text-text-primary font-bold">{motion.speed.toFixed(2)} m/s</strong>
                </span>
                <span>
                  Dir: <strong className={motion.direction === "IDLE" ? "text-text-muted" : "text-sage"}>{motion.direction}</strong>
                </span>
                <span>
                  Doors: <strong className={motion.doorState === "CLOSED" ? "text-text-muted" : "text-amber-warm font-bold"}>{motion.doorState}</strong>
                </span>
              </div>
            </div>
          )}

          {/* Subsystem Direct-Selection Strip along Bottom */}
          {!compactToolbar && showSubsystemStrip && (
            <div className="px-3 py-2 flex items-center gap-1.5 overflow-x-auto text-xs">
              <span className="text-[11px] font-mono text-text-secondary whitespace-nowrap mr-1">
                Direct Select:
              </span>
              {report &&
                (Object.keys(report.components) as ComponentId[]).map((id) => {
                  const comp = report.components[id];
                  const isSelected = effectiveSelectedId === id;
                  const isFault = activeFaultId === id;

                  return (
                    <button
                      key={id}
                      onClick={() => handleSelect(id)}
                      onDoubleClick={() => handleDoubleClickFocus(id)}
                      className={`px-2.5 py-1 rounded-md text-[11px] whitespace-nowrap transition-all border ${
                        isFault
                          ? "bg-coral/20 border-coral text-coral font-bold"
                          : isSelected
                          ? "bg-sage/20 border-sage text-sage font-bold"
                          : "bg-surface border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover"
                      }`}
                      title={`${comp.label} (Double-click to focus)`}
                    >
                      {comp.label}
                    </button>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* Developer Hierarchy & Mesh Inspector Modal */}
      <HierarchyInspectorModal
        isOpen={showHierarchyModal}
        onClose={() => setShowHierarchyModal(false)}
        report={report}
        selectedComponentId={effectiveSelectedId}
        onSelectComponent={handleSelect}
      />
    </div>
  );
};

export default ModelViewer;
