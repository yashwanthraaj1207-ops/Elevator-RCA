// src/components/digitalTwin/FloorSelectorShaft.tsx
/**
 * Visual Floor Indicator & Request Strip beside 3D Shaft (Feature 1).
 *
 * Displays:
 * - 12 Configurable floors (G, 1, 2, ... 11)
 * - Current car position indicator
 * - Target floor beacon and call queue status
 * - Interactive floor-call buttons
 * - Quick Return-to-Ground button
 * - Service availability state (disabled with clear explanation during critical faults)
 *
 * Designed to align smoothly with the 3D canvas viewport without blocking orbit controls.
 */

import React from "react";
import { useElevatorStore } from "../../simulation/store";
import { PRESET_FLOORS } from "../../simulation/floors";
import { ArrowDown, ArrowUp, Circle, ShieldAlert, Home } from "lucide-react";

export const FloorSelectorShaft: React.FC = () => {
  const motion = useElevatorStore((s) => s.motion);
  const requestFloor = useElevatorStore((s) => s.requestFloor);
  const returnToGround = useElevatorStore((s) => s.returnToGround);

  const isOutOfService = motion.serviceState === "OUT_OF_SERVICE";
  const currentFloorIdx = motion.currentFloor;
  const targetFloorIdx = motion.targetFloor;
  const queue = motion.callQueue;

  // Render top-to-bottom: Floor 11 down to Ground (Floor 0)
  const reversedFloors = [...PRESET_FLOORS].reverse();

  return (
    <div
      className="absolute top-[50px] left-3 z-10 flex flex-col bg-card/92 backdrop-blur-md border border-border rounded-xl shadow-elevated p-2 w-28 text-xs select-none pointer-events-auto"
      role="region"
      aria-label="Shaft Floor Call Controller"
    >
      {/* Shaft Header */}
      <div className="pb-1.5 border-b border-border flex items-center justify-between">
        <span className="text-[10px] font-mono font-bold text-text-secondary uppercase">
          Shaft LOP
        </span>
        <div className="flex items-center gap-1 font-mono text-[10px]">
          {motion.direction === "UP" && <ArrowUp className="w-3 h-3 text-sage animate-bounce" />}
          {motion.direction === "DOWN" && <ArrowDown className="w-3 h-3 text-amber-warm animate-bounce" />}
          {motion.direction === "IDLE" && <Circle className="w-2 h-2 text-text-muted fill-current" />}
          <span className="font-bold text-text-primary">
            {PRESET_FLOORS[currentFloorIdx]?.label ?? currentFloorIdx}
          </span>
        </div>
      </div>

      {/* Out of Service Warning Banner */}
      {isOutOfService && (
        <div className="my-1.5 p-1 rounded bg-coral/15 border border-coral/30 text-[9px] font-mono text-coral flex items-center gap-1">
          <ShieldAlert className="w-3 h-3 shrink-0" />
          <span className="font-bold leading-tight">OUT OF SERVICE</span>
        </div>
      )}

      {/* Floor Selection Grid (Scrollable vertical stack) */}
      <div className="py-1 flex flex-col gap-1 max-h-[300px] overflow-y-auto pr-0.5">
        {reversedFloors.map((fl) => {
          const isCurrent = currentFloorIdx === fl.index;
          const isTarget = targetFloorIdx === fl.index && motion.direction !== "IDLE";
          const isQueued = queue.includes(fl.index);

          return (
            <button
              key={fl.index}
              disabled={isOutOfService}
              onClick={() => requestFloor(fl.index)}
              className={`w-full py-1 px-1.5 rounded text-[11px] font-mono flex items-center justify-between transition-all border ${
                isCurrent
                  ? "bg-sage/25 border-sage text-sage font-bold shadow-sm"
                  : isTarget
                  ? "bg-amber-warm/20 border-amber-warm text-amber-warm font-semibold animate-pulse"
                  : isQueued
                  ? "bg-surface-hover border-border text-amber-warm"
                  : isOutOfService
                  ? "bg-surface/50 border-transparent text-text-muted cursor-not-allowed opacity-60"
                  : "bg-surface hover:bg-surface-hover border-border text-text-secondary hover:text-text-primary"
              }`}
              title={`Call Elevator to ${fl.displayName}${isOutOfService ? " (Disabled: Critical Fault)" : ""}`}
            >
              <span className="font-semibold">{fl.label}</span>
              <span className="text-[9px] text-text-muted">
                {fl.elevation.toFixed(0)}m
              </span>
            </button>
          );
        })}
      </div>

      {/* Return to Ground Action */}
      <div className="pt-1.5 border-t border-border mt-1">
        <button
          disabled={currentFloorIdx === 0 || (isOutOfService && !motion.recoveryPermitted)}
          onClick={returnToGround}
          className={`w-full py-1 px-1.5 rounded text-[10px] font-medium flex items-center justify-center gap-1 border transition-colors ${
            currentFloorIdx === 0
              ? "bg-surface/40 border-border text-text-muted cursor-default"
              : isOutOfService && !motion.recoveryPermitted
              ? "bg-surface/40 border-border text-text-muted cursor-not-allowed opacity-60"
              : "bg-surface hover:bg-surface-hover border-border text-text-primary hover:text-sage"
          }`}
          title="Return Car to Ground Floor Lobby"
        >
          <Home className="w-3 h-3 text-sage" />
          <span>Ground Return</span>
        </button>
      </div>
    </div>
  );
};

