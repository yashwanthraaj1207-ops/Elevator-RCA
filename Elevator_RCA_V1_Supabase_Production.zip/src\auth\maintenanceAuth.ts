// src/auth/maintenanceAuth.ts
/**
 * Maintenance Authentication Adapter for ELEVATOR-RCA Research Prototype.
 *
 * Provides centralized authentication behind an interface for authorized technician sessions:
 * - Elevator Asset ID matching
 * - Username / Technician credential verification
 * - Role-based authorization: "lead_pe" | "field_technician" | "apprentice"
 * - Clear failure modes: invalid asset, unknown technician, invalid password
 * - Session expiry tracking (default 30 minutes)
 * - Safe simulated test credentials stored separately from production secrets
 *
 * IMPORTANT NOTE:
 * Clearly labeled as DEMO AUTHENTICATION for prototype simulation only.
 * In a real production deployment, authentication must be verified by a certified
 * server-side backend with bcrypt/argon2 hashing, signed JWT/OAuth2 tokens,
 * and hardware safety interlocks.
 */

export interface MaintenanceUser {
  id: string;
  username: string;
  fullName: string;
  role: "admin" | "lead_pe" | "field_technician" | "apprentice";
  badgeNumber: string;
  authorizedAssets: string[]; // List of elevator IDs allowed to service, e.g. ["ELEV-001", "ELEV-002", "*"]
}

export interface MaintenanceSession {
  user: MaintenanceUser;
  assetId: string;
  token: string;
  loginTime: string;
  expiresAt: number; // epoch ms
}

export interface AuthResult {
  success: boolean;
  session?: MaintenanceSession;
  error?: string;
}

/**
 * Non-production demo test credentials.
 * Kept in memory for testing/demonstration only.
 */
const DEMO_TECHNICIANS: Record<
  string,
  { password: string; user: MaintenanceUser }
> = {
  tech_vance: {
    password: "elevator!tech4812",
    user: {
      id: "TECH-4812",
      username: "tech_vance",
      fullName: "M. Vance",
      role: "field_technician",
      badgeNumber: "BT-4812",
      authorizedAssets: ["ELEV-001", "ELEV-002"],
    },
  },
  pe_topson: {
    password: "lead!engineer2026",
    user: {
      id: "PE-1001",
      username: "pe_topson",
      fullName: "N. Topson (Lead PE)",
      role: "lead_pe",
      badgeNumber: "PE-1001",
      authorizedAssets: ["*"], // Authorized for all assets
    },
  },
  admin_sys: {
    password: "admin!safety2026",
    user: {
      id: "ADM-001",
      username: "admin_sys",
      fullName: "System Administrator",
      role: "admin",
      badgeNumber: "ADM-001",
      authorizedAssets: ["*"],
    },
  },
  apprentice_chen: {
    password: "apprentice!chen",
    user: {
      id: "APP-902",
      username: "apprentice_chen",
      fullName: "K. Chen",
      role: "apprentice",
      badgeNumber: "APP-902",
      authorizedAssets: ["ELEV-001"],
    },
  },
};

export const DEMO_CREDENTIALS_HINT = [
  { username: "tech_vance", role: "Field Technician", pass: "elevator!tech4812" },
  { username: "pe_topson", role: "Lead PE Engineer", pass: "lead!engineer2026" },
  { username: "admin_sys", role: "System Admin", pass: "admin!safety2026" },
  { username: "apprentice_chen", role: "Apprentice Tech", pass: "apprentice!chen" },
];

export interface IAuthAdapter {
  login(assetId: string, username: string, pass: string): Promise<AuthResult>;
  validateSession(session: MaintenanceSession | null, currentAssetId: string): boolean;
}

class DemoAuthAdapter implements IAuthAdapter {
  private readonly sessionDurationMs = 30 * 60 * 1000; // 30 minutes demo timeout

  async login(assetId: string, username: string, pass: string): Promise<AuthResult> {
    // Artificial slight latency to simulate network auth handshake
    await new Promise((resolve) => setTimeout(resolve, 350));

    const cleanAsset = assetId.trim().toUpperCase();
    const cleanUser = username.trim().toLowerCase();

    if (!cleanAsset) {
      return { success: false, error: "Elevator Asset Identifier is required." };
    }
    if (!cleanUser) {
      return { success: false, error: "Technician username is required." };
    }
    if (!pass) {
      return { success: false, error: "Password is required." };
    }

    const record = DEMO_TECHNICIANS[cleanUser];
    if (!record) {
      return {
        success: false,
        error: "Authentication failed. Technician username or password is invalid.",
      };
    }

    if (record.password !== pass) {
      return {
        success: false,
        error: "Authentication failed. Technician username or password is invalid.",
      };
    }

    // Asset authorization check: technician must have access rights to the specific elevator
    const isAuthorizedForAsset =
      record.user.authorizedAssets.includes("*") ||
      record.user.authorizedAssets.includes(cleanAsset);

    if (!isAuthorizedForAsset) {
      return {
        success: false,
        error: `Access Denied: Technician ${record.user.fullName} is not authorized to service Asset "${cleanAsset}".`,
      };
    }

    const session: MaintenanceSession = {
      user: record.user,
      assetId: cleanAsset,
      token: `demo-token-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      loginTime: new Date().toISOString(),
      expiresAt: Date.now() + this.sessionDurationMs,
    };

    return {
      success: true,
      session,
    };
  }

  validateSession(session: MaintenanceSession | null, currentAssetId: string): boolean {
    if (!session) return false;
    if (Date.now() > session.expiresAt) return false;
    if (session.user.authorizedAssets.includes("*")) return true;
    return session.assetId === currentAssetId.toUpperCase();
  }
}

export const maintenanceAuthAdapter: IAuthAdapter = new DemoAuthAdapter();

