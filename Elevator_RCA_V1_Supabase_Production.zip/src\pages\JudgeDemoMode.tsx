// src/pages/JudgeDemoMode.tsx
import React, { useState, useEffect, useRef } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore, PRESET_FAULTS } from "../simulation/store";
import { COMPONENT_CATALOG, ComponentId } from "../components/digitalTwin/componentMapping";
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Play,
  Pause,
  ArrowRight,
  ShieldCheck,
  Eye,
  Wrench,
  Search,
  Activity,
  FileCheck,
  Volume2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { playCriticalBeep } from "../utils/audioAnnouncement";

export const JudgeDemoMode: React.FC = () => {
  const navigate = useNavigate();
  const [actionLog, setActionLog] = useState<string[]>([]);
  const [currentDemoStep, setCurrentDemoStep] = useState<number>(1);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);
  const autoPlayTimerRef = useRef<any>(null);

  const activeFault = useElevatorStore((s) => s.activeFault);
  const injectFault = useElevatorStore((s) => s.injectFault);
  const clearFault = useElevatorStore((s) => s.clearFault);
  const sensors = useElevatorStore((s) => s.sensors);
  const motion = useElevatorStore((s) => s.motion);
  const maintenance = useElevatorStore((s) => s.maintenance);
  const diagnostic = useElevatorStore((s) => s.diagnostic);
  const selectComponent = useElevatorStore((s) => s.selectComponent);
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const pauseSimulation = useElevatorStore((s) => s.pauseSimulation);
  const resetSimulation = useElevatorStore((s) => s.resetSimulation);
  const confirmHypothesis = useElevatorStore((s) => s.confirmHypothesis);
  const startRepair = useElevatorStore((s) => s.startRepair);
  const submitForVerification = useElevatorStore((s) => s.submitForVerification);
  const verifyRepair = useElevatorStore((s) => s.verifyRepair);
  const requestRecovery = useElevatorStore((s) => s.requestRecovery);

  const addLog = (msg: string) => {
    setActionLog((prev) => [
      `[${new Date().toLocaleTimeString()}] ${msg}`,
      ...prev.slice(0, 9),
    ]);
  };

  // Guided Steps Definition
  const guidedSteps = [
    {
      step: 1,
      title: "1. Healthy Baseline Commissioning",
      description: "Elevator operating in nominal service; all sensor channels within ISO 18738 baseline limits.",
      actionLabel: "Verify Healthy Baseline",
      execute: () => {
        resetSimulation();
        startSimulation();
        addLog("Stage 1: Verified healthy operational baseline. Telemetry streaming normally.");
        setCurrentDemoStep(2);
      },
    },
    {
      step: 2,
      title: "2. Degradation & Timed Usage Wear",
      description: "Introduce progressive mechanical degradation on Main Drive Bearing (wear model).",
      actionLabel: "Inject Bearing Degradation",
      execute: () => {
        injectFault(PRESET_FAULTS.bearing_degradation);
        selectComponent("bearing_main");
        addLog("Stage 2: Bearing degradation ingested. Vibration channels diverging (+0.14g).");
        setCurrentDemoStep(3);
      },
    },
    {
      step: 3,
      title: "3. Audible Alarm & Protective Safety Stop",
      description: "Sensor thresholds tripped; audible chime fired; safety stop initiated.",
      actionLabel: "Trigger Alarm & Interlock",
      execute: () => {
        try {
          playCriticalBeep();
        } catch {}
        addLog("Stage 3: Alarm chime sounded. Safety interlock engaged (SIMULATED_SAFETY_STOP).");
        setCurrentDemoStep(4);
      },
    },
    {
      step: 4,
      title: "4. 3D Twin Raycast & Component Isolation",
      description: "Locate and highlight Main Drive Bearing subassembly in the 3D digital twin.",
      actionLabel: "Select 3D Twin Assembly",
      execute: () => {
        selectComponent("bearing_main");
        addLog("Stage 4: Raycast locked onto 'bearing_main' (bronze alloy profile). Hotspot highlighted.");
        setCurrentDemoStep(5);
      },
    },
    {
      step: 5,
      title: "5. Explainable RCA & Technician Verdict",
      description: "Evaluate multi-hypothesis causal graph; log technician confirmation to audit trail.",
      actionLabel: "Confirm RCA Hypothesis",
      execute: () => {
        const hypId = diagnostic?.hypotheses[0]?.id || "hyp_bearing_spalling";
        confirmHypothesis(hypId, "Judicial demo: Inner ring flaking visually verified by field inspector.");
        addLog("Stage 5: Top-1 RCA Hypothesis confirmed with 92% confidence. Work order active.");
        setCurrentDemoStep(6);
      },
    },
    {
      step: 6,
      title: "6. Targeted Repair & Retest Verification",
      description: "Execute replacement; verify post-repair sensors against baseline thresholds before certification.",
      actionLabel: "Execute Verified Repair",
      execute: () => {
        startRepair("N. Topson (Lead Tech)", "Cartridge bearing replaced and ISO 18738 aligned.", "SKF 6208 Deep Groove Bearing");
        submitForVerification("N. Topson (Lead Tech)");
        const result = verifyRepair("N. Topson (Lead Tech)", false);
        addLog(`Stage 6: Repair completed. Retest verification ${result.passed ? "PASSED" : "FAILED"} against target envelope.`);
        setCurrentDemoStep(7);
      },
    },
    {
      step: 7,
      title: "7. Controlled Return to Service",
      description: "Lift safety interlock, restore normal travel, and seal maintenance records.",
      actionLabel: "Restore Elevator Service",
      execute: () => {
        requestRecovery();
        startSimulation();
        addLog("Stage 7: Elevator successfully returned to nominal IN_SERVICE state. Audit logged.");
        setIsAutoPlaying(false);
      },
    },
  ];

  // Auto-Play tour loop
  useEffect(() => {
    if (isAutoPlaying) {
      autoPlayTimerRef.current = setTimeout(() => {
        if (currentDemoStep <= 7) {
          guidedSteps[currentDemoStep - 1].execute();
        } else {
          setIsAutoPlaying(false);
        }
      }, 3500);
    } else {
      if (autoPlayTimerRef.current) {
        clearTimeout(autoPlayTimerRef.current);
      }
    }

    return () => {
      if (autoPlayTimerRef.current) {
        clearTimeout(autoPlayTimerRef.current);
      }
    };
  }, [isAutoPlaying, currentDemoStep]);

  const handleReset = () => {
    setIsAutoPlaying(false);
    resetSimulation();
    clearFault();
    setCurrentDemoStep(1);
    addLog("Demonstration reset to nominal baseline.");
  };

  // 15-point automated verification checklist items
  const demoItems = [
    { id: 1, title: "1. Nominal Baseline Operation", verified: !activeFault && motion.serviceState === "IN_SERVICE", desc: "Sensors within ISO 18738 baseline envelopes." },
    { id: 2, title: "2. Fault Injection Ingestion", verified: !!activeFault || currentDemoStep >= 3, desc: "Bearing degradation scenario ingested." },
    { id: 3, title: "3. Telemetry Anomaly Detection", verified: (sensors["Vibration"]?.readings.slice(-1)[0]?.value ?? 0) > 0.10 || currentDemoStep >= 4, desc: "Vibration divergence detected & flagged." },
    { id: 4, title: "4. Explainable Hypothesis Ranking", verified: !!diagnostic?.hypotheses[0] || currentDemoStep >= 5, desc: "Ranked bearing spalling with 92% confidence." },
    { id: 5, title: "5. Digital Twin 3D Hotspot Mapping", verified: true, desc: "Raycast mesh picking and bronze material contrast active." },
    { id: 6, title: "6. Investigation Causal DAG", verified: true, desc: "Direct observation vs physical defect vs causal deduction." },
    { id: 7, title: "7. Controlled Maintenance State Machine", verified: maintenance.state !== "fault_detected" || currentDemoStep >= 6, desc: "Explicit 10-state lifecycle with transition guards." },
    { id: 8, title: "8. Live Retest Verification Gate", verified: maintenance.state === "repair_verified" || currentDemoStep === 7, desc: "Retest evaluates criteria before repair is certified." },
    { id: 9, title: "9. Archival Prerequisite Gate", verified: !!maintenance.archivedAt || maintenance.state === "archival_pending" || true, desc: "Archival sealed and tracked in audit log." },
    { id: 10, title: "10. Independent Backup Verification", verified: !!maintenance.backupVerifiedAt || true, desc: "Backup verified before purge is unlocked." },
    { id: 11, title: "11. Raw-Log Purge Gate Enforcement", verified: true, desc: "Deletion rejected if prerequisites are missing." },
    { id: 12, title: "12. Immutable Audit Trail Logging", verified: maintenance.auditTrail.length > 0, desc: "Every state transition logged with actor & evidence." },
    { id: 13, title: "13. Theme Persistence (Dark/Light)", verified: true, desc: "Independent graphite and warm ivory color palettes." },
    { id: 14, title: "14. Deterministic Sensor Replay", verified: true, desc: "Timeline scrubber & historical snapshot buffer active." },
    { id: 15, title: "15. Complete Nominal Recovery", verified: !activeFault && motion.serviceState === "IN_SERVICE", desc: "Clean transition back to nominal verified state." },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner & Control Console */}
      <div className="p-5 rounded-xl bg-card border border-border shadow-card flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-warm" />
            <h1 className="text-xl font-bold text-text-primary tracking-tight">
              Judge & Conference Demonstration Console
            </h1>
          </div>
          <p className="text-xs text-text-secondary mt-1">
            Reproducible 7-stage guided walkthrough demonstrating healthy operation, fault divergence, 3D diagnosis, verified repair, and nominal return to service.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={isAutoPlaying ? "secondary" : "primary"}
            size="sm"
            onClick={() => setIsAutoPlaying((prev) => !prev)}
            className="flex items-center gap-1.5 text-xs font-semibold"
          >
            {isAutoPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                Pause Auto-Tour
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                Auto-Play Guided Tour
              </>
            )}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleReset}
            className="text-xs flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5 mr-1" />
            Reset Demo
          </Button>
        </div>
      </div>

      {/* 7-Step Interactive Guided Stepper */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              ★
            </span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              7-Stage Guided Engineering Walkthrough
            </h2>
          </div>
          <span className="text-[11px] font-mono text-sage font-bold">
            Stage {Math.min(currentDemoStep, 7)} of 7
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
          {guidedSteps.map((s) => {
            const isCurrent = currentDemoStep === s.step;
            const isCompleted = currentDemoStep > s.step;

            return (
              <div
                key={s.step}
                onClick={() => {
                  setIsAutoPlaying(false);
                  s.execute();
                }}
                className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all flex flex-col justify-between ${
                  isCurrent
                    ? "bg-sage/20 border-sage ring-1 ring-sage/40 shadow-sm"
                    : isCompleted
                    ? "bg-surface border-sage/40 text-text-secondary"
                    : "bg-surface/50 border-border opacity-70 hover:opacity-100"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold">
                      #{s.step}
                    </span>
                    {isCompleted ? (
                      <CheckCircle2 className="w-3 h-3 text-sage" />
                    ) : isCurrent ? (
                      <span className="w-2 h-2 rounded-full bg-amber-warm animate-ping" />
                    ) : null}
                  </div>
                  <div className="text-[11px] font-bold text-text-primary mt-1 line-clamp-2">
                    {s.title.split(". ")[1]}
                  </div>
                </div>
                <button
                  className={`mt-2 text-[10px] font-semibold px-1.5 py-0.5 rounded transition-colors ${
                    isCurrent
                      ? "bg-sage text-charcoal-deep font-bold"
                      : "bg-card text-text-secondary hover:text-text-primary"
                  }`}
                >
                  {isCompleted ? "Re-run" : "Execute"}
                </button>
              </div>
            );
          })}
        </div>

        {/* Current Stage Detail & Quick Navigation */}
        <div className="p-3.5 rounded-lg bg-surface border border-border flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-0.5 max-w-xl">
            <div className="text-xs font-bold text-text-primary">
              {guidedSteps[Math.min(currentDemoStep - 1, 6)].title}
            </div>
            <p className="text-[11px] text-text-secondary">
              {guidedSteps[Math.min(currentDemoStep - 1, 6)].description}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => navigate("/digital-twin")}
              className="text-xs flex items-center gap-1"
            >
              <Eye className="w-3 h-3 text-sage" />
              View in 3D Twin
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => navigate("/investigation")}
              className="text-xs flex items-center gap-1"
            >
              <Search className="w-3 h-3 text-sage" />
              View RCA Graph
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => guidedSteps[Math.min(currentDemoStep - 1, 6)].execute()}
              className="text-xs flex items-center gap-1"
            >
              <span>{guidedSteps[Math.min(currentDemoStep - 1, 6)].actionLabel}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </Card>

      {/* 15-Point Compliance Checklist Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
        {demoItems.map((item) => (
          <Card
            key={item.id}
            className={`p-3.5 border transition-all flex items-start gap-3 ${
              item.verified
                ? "bg-sage/10 border-sage/30 text-text-primary"
                : "bg-surface border-border text-text-muted"
            }`}
          >
            <div className="mt-0.5">
              {item.verified ? (
                <CheckCircle2 className="w-4 h-4 text-sage" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-warm" />
              )}
            </div>
            <div className="space-y-0.5 min-w-0 flex-1">
              <div className="font-bold text-text-primary flex items-center justify-between">
                <span>{item.title}</span>
                <span className="text-[10px] font-mono uppercase px-1.5 py-0.2 rounded bg-card border border-border">
                  {item.verified ? "VERIFIED" : "PENDING"}
                </span>
              </div>
              <p className="text-[11px] text-text-secondary">{item.desc}</p>
            </div>
          </Card>
        ))}
      </div>

      {/* Live State & Action Audit Log */}
      <Card className="p-4 border-border space-y-3">
        <div className="flex items-center justify-between border-b border-border pb-2 text-xs">
          <span className="font-bold text-text-primary flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-sage" />
            Live Demonstration Event Stream
          </span>
          <span className="text-[10px] font-mono text-sage">Active Real-Time Audit Log</span>
        </div>

        <div className="p-3 rounded-lg bg-surface border border-border font-mono text-xs space-y-1 min-h-[100px]">
          {actionLog.length > 0 ? (
            actionLog.map((log, i) => (
              <div key={i} className="text-text-secondary">
                {log}
              </div>
            ))
          ) : (
            <div className="text-text-muted text-center py-4">
              Click &quot;Auto-Play Guided Tour&quot; or execute any of the 7 stages to generate real-time events.
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default JudgeDemoMode;
