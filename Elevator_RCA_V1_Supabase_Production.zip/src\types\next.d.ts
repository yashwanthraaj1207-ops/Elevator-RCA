// Ambient type declarations for Next.js server and headers APIs
// Enables Supabase server helper modules to compile seamlessly in this project
declare module "next/headers" {
  export interface CookieObject {
    name: string;
    value: string;
    [key: string]: any;
  }
  export interface ReadonlyRequestCookies {
    getAll(): CookieObject[];
    get(name: string): CookieObject | undefined;
    set(name: string, value: string, options?: any): void;
    delete(name: string): void;
  }
  export function cookies(): Promise<ReadonlyRequestCookies>;
}

declare module "next/server" {
  export interface NextRequest {
    cookies: {
      getAll(): Array<{ name: string; value: string }>;
      get(name: string): { name: string; value: string } | undefined;
      set(name: string, value: string, options?: any): void;
    };
    headers: any;
    nextUrl?: any;
    url?: string;
  }

  export class NextResponse {
    headers: any;
    cookies: {
      set(name: string, value: string, options?: any): void;
      get(name: string): any;
      getAll(): any[];
    };
    static next(init?: { request?: { headers?: any } }): NextResponse;
    static json(body: any, init?: any): NextResponse;
    static redirect(url: string | URL, status?: number): NextResponse;
  }
}

