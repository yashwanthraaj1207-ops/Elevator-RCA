// src/simulation/store.ts
import { create } from "zustand";
import { devtools } from "zustand/middleware";
import {
  SimulationEngine,
  SensorData,
  Status,
  FaultScenario,
  MotionState,
  DegradationConfig,
  DegradationState,
  SimulationSnapshot,
  engine,
} from "./engine";
import {
  DiagnosticInvestigation,
  ALL_FAULT_SCENARIOS,
  runDiagnosticPipeline,
} from "./diagnostics";
import {
  MaintenanceStateMachine,
  MaintenanceWorkflow,
  MaintenanceWorkOrder,
  VerificationCriteria,
} from "./maintenance";
import {
  FloorDefinition,
  PRESET_FLOORS,
  generateFloors,
} from "./floors";
import {
  MaintenanceSession,
} from "../auth/maintenanceAuth";
import { syncService } from "../lib/syncService";

export type {
  SimulationEngine,
  SensorData,
  Status,
  FaultScenario,
  MotionState,
  DegradationConfig,
  DegradationState,
  SimulationSnapshot,
  DiagnosticInvestigation,
  MaintenanceWorkflow,
  MaintenanceWorkOrder,
  VerificationCriteria,
  FloorDefinition,
  MaintenanceSession,
};
export { ALL_FAULT_SCENARIOS, PRESET_FLOORS };

const maintenanceFsm = new MaintenanceStateMachine();

export interface ElevatorState {
  assetId: string;
  model: string;
  time: number;
  cumulativeMotorTime: number;
  operatingCycles: number;
  running: boolean;
  sensors: Record<string, SensorData>;
  motion: MotionState;
  floors: FloorDefinition[];
  activeFault?: FaultScenario;
  diagnostic?: DiagnosticInvestigation;
  selectedComponent?: string;
  maintenance: MaintenanceWorkflow;
  maintenanceSession: MaintenanceSession | null;
  faultAlertDismissed: boolean;

  // Operating-Time Dependent Component Degradation Model
  degradationConfig: DegradationConfig;
  degradationState: DegradationState;
  startDegradationRun(scenarioKey: string, config?: Partial<DegradationConfig>): void;
  cancelDegradation(): void;
  setDegradationConfig(config: Partial<DegradationConfig>): void;

  // Normal vs Demo Delayed-Fault Mode
  demoMode: boolean;
  demoCountdown: number | null;
  demoPendingFault: FaultScenario | null;
  setDemoMode(enabled: boolean): void;
  startDemoCountdown(fault: FaultScenario, seconds?: number): void;
  cancelDemoCountdown(): void;

  simSpeed: 1 | 2 | 5 | 10;
  setSimSpeed(speed: 1 | 2 | 5 | 10): void;

  // Simulation Controls
  startSimulation(): void;
  pauseSimulation(): void;
  resetSimulation(): void;
  tick(): void;
  injectFault(fault: FaultScenario): void;
  clearFault(): void;
  selectComponent(id: string): void;
  dismissFaultAlert(): void;
  showFaultAlert(): void;
  emergencyStop(): void;
  toggleDoorCycle(): void;
  setAutoCycle(enabled: boolean): void;

  // Floor Controls (Feature 1)
  requestFloor(floorIndex: number): boolean;
  returnToGround(): boolean;
  setTotalFloors(count: number): void;

  // Authentication (Feature 3)
  loginMaintenance(session: MaintenanceSession): void;
  logoutMaintenance(): void;

  // Maintenance & Verification Controls (Features 4, 5, 6)
  reportFaultToMaintenance(): void;
  openInvestigation(): void;
  startRepair(technician: string, action: string, partsReplaced?: string): void;
  submitForVerification(technician: string): void;
  verifyRepair(technician: string, forceFail?: boolean): { passed: boolean };
  requestRecovery(): boolean;
  confirmReturnToService(): boolean;

  // Archival & Storage Retention (Section 7)
  requestArchival(): void;
  confirmArchival(): void;
  verifyBackup(): void;
  executeRawLogCleanup(): { success: boolean; message: string };

  // Deterministic Timeline Replay & Scrubbing
  timelineHistory: SimulationSnapshot[];
  replayMode: boolean;
  replayTime: number | null;
  startReplay(targetTime?: number): void;
  seekReplay(targetTime: number): void;
  stepReplay(deltaSeconds: number): void;
  stopReplay(): void;

  // Explainable Hypothesis Technician Confirmation & Rejection
  confirmHypothesis(hypothesisId: string, notes?: string): void;
  rejectHypothesis(hypothesisId: string, notes: string): void;

  // Maintenance Work Orders & Inspection Checklists
  toggleWorkOrderStep(stepId: string, completed?: boolean): void;
  updateWorkOrder(updates: Partial<MaintenanceWorkOrder>): void;
}

export const PRESET_FAULTS = ALL_FAULT_SCENARIOS;

let globalSimInterval: any = null;

function restartSimInterval(get: () => ElevatorState) {
  if (globalSimInterval) {
    clearInterval(globalSimInterval);
    globalSimInterval = null;
  }
  const s = get();
  if (s.running) {
    globalSimInterval = setInterval(() => {
      get().tick();
    }, Math.max(80, Math.round(1000 / s.simSpeed)));
  }
}

function getInitialMaintenanceSession(): MaintenanceSession | null {
  if (typeof window === "undefined" || !window.localStorage) return null;
  try {
    const raw = localStorage.getItem("elevator_rca_maintenance_session");
    if (!raw) return null;
    const session = JSON.parse(raw) as MaintenanceSession;
    if (session && session.expiresAt && Date.now() < session.expiresAt) {
      return session;
    }
    localStorage.removeItem("elevator_rca_maintenance_session");
  } catch {
    // Ignore storage parse errors
  }
  return null;
}

export const useElevatorStore = create<ElevatorState>()(
  devtools((set, get) => ({
    assetId: "ELEV-001",
    model: "Otis Gen2 / Model-X200",
    time: 0,
    cumulativeMotorTime: 0,
    operatingCycles: 0,
    running: false,
    simSpeed: 1,
    sensors: engine.getState().sensors,
    motion: engine.getState().motion,
    floors: PRESET_FLOORS,
    activeFault: undefined,
    diagnostic: undefined,
    selectedComponent: undefined,
    maintenance: maintenanceFsm.getWorkflow(),
    maintenanceSession: getInitialMaintenanceSession(),
    faultAlertDismissed: true,

    degradationConfig: engine.getState().degradationConfig,
    degradationState: engine.getState().degradationState,

    demoMode: false,
    demoCountdown: null,
    demoPendingFault: null,

    timelineHistory: engine.getState().timelineHistory,
    replayMode: false,
    replayTime: null,

    startDegradationRun: (scenarioKey: string, config?: Partial<DegradationConfig>) => {
      const scenario = ALL_FAULT_SCENARIOS[scenarioKey] || ALL_FAULT_SCENARIOS.bearing_degradation;
      engine.startDegradationRun(scenario, config);
      const s = engine.getState();
      set({
        degradationConfig: s.degradationConfig,
        degradationState: s.degradationState,
        running: true,
      });
      restartSimInterval(get);
    },

    cancelDegradation: () => {
      engine.clearDegradation();
      const s = engine.getState();
      set({
        degradationConfig: s.degradationConfig,
        degradationState: s.degradationState,
      });
    },

    setDegradationConfig: (config: Partial<DegradationConfig>) => {
      engine.setDegradationConfig(config);
      set({ degradationConfig: engine.getState().degradationConfig });
    },

    setDemoMode: (enabled: boolean) => set({ demoMode: enabled }),

    startDemoCountdown: (fault: FaultScenario, seconds = 10) => {
      if (!get().running) {
        get().startSimulation();
      }
      set({
        demoMode: true,
        demoCountdown: seconds,
        demoPendingFault: fault,
      });
    },

    cancelDemoCountdown: () => {
      set({ demoCountdown: null, demoPendingFault: null });
    },

    setSimSpeed: (speed: 1 | 2 | 5 | 10) => {
      set({ simSpeed: speed });
      restartSimInterval(get);
    },

    startSimulation: () => {
      engine.start();
      const s = engine.getState();
      set({ running: true, time: s.time, sensors: s.sensors, motion: s.motion });
      restartSimInterval(get);
    },

    pauseSimulation: () => {
      engine.pause();
      set({ running: false });
      restartSimInterval(get);
    },

    resetSimulation: () => {
      engine.reset();
      const s = engine.getState();
      set({
        running: false,
        time: s.time,
        cumulativeMotorTime: 0,
        operatingCycles: 0,
        sensors: s.sensors,
        motion: s.motion,
        activeFault: undefined,
        diagnostic: undefined,
        selectedComponent: undefined,
        faultAlertDismissed: true,
        degradationConfig: s.degradationConfig,
        degradationState: s.degradationState,
        demoCountdown: null,
        demoPendingFault: null,
        timelineHistory: s.timelineHistory,
        replayMode: false,
        replayTime: null,
      });
      restartSimInterval(get);
    },

    tick: () => {
      // If currently replaying, do not advance live engine tick
      if (get().replayMode) {
        return;
      }

      engine.tick();
      const s = engine.getState();

      let activeFault = s.activeFault;
      let diag = get().diagnostic;
      let alertDismissed = get().faultAlertDismissed;
      let selComp = get().selectedComponent;

      // Handle confirmed critical fault from degradation or engine detection
      if (s.newFaultConfirmed && s.activeFault) {
        diag = runDiagnosticPipeline(s.sensors, s.activeFault);
        maintenanceFsm.reportFault(
          s.activeFault.affectedComponent,
          `${s.activeFault.name}: ${s.activeFault.description}`
        );
        alertDismissed = false; // Popup modal immediately
        selComp = s.activeFault.affectedComponent;
        engine.consumeNewFaultConfirmed();
      } else if (activeFault && !diag) {
        diag = runDiagnosticPipeline(s.sensors, activeFault);
      }

      const state = get();
      let nextCountdown = state.demoCountdown;
      let pendingFault = state.demoPendingFault;

      if (nextCountdown !== null && pendingFault) {
        if (nextCountdown <= 1) {
          nextCountdown = null;
          get().injectFault(pendingFault);
          pendingFault = null;
        } else {
          nextCountdown = nextCountdown - 1;
        }
      }

      set({
        time: s.time,
        cumulativeMotorTime: s.cumulativeMotorTime,
        operatingCycles: s.operatingCycles,
        sensors: s.sensors,
        running: s.running,
        activeFault: s.activeFault,
        motion: s.motion,
        diagnostic: diag,
        selectedComponent: selComp,
        faultAlertDismissed: alertDismissed,
        degradationConfig: s.degradationConfig,
        degradationState: s.degradationState,
        maintenance: maintenanceFsm.getWorkflow(),
        demoCountdown: nextCountdown,
        demoPendingFault: pendingFault,
        timelineHistory: s.timelineHistory,
      });
    },

    injectFault: (fault: FaultScenario) => {
      engine.injectFault(fault);
      const s = engine.getState();
      const diag = runDiagnosticPipeline(s.sensors, fault);

      // Trigger incident in maintenance state machine
      maintenanceFsm.reportFault(
        fault.affectedComponent,
        `${fault.name}: ${fault.description}`
      );

      set({
        activeFault: fault,
        diagnostic: diag,
        selectedComponent: fault.affectedComponent,
        maintenance: maintenanceFsm.getWorkflow(),
        motion: s.motion,
        faultAlertDismissed: false, // Pop up the alert modal
      });
    },

    clearFault: () => {
      engine.clearFault();
      const s = engine.getState();
      set({
        activeFault: undefined,
        diagnostic: undefined,
        degradationConfig: s.degradationConfig,
        degradationState: s.degradationState,
        faultAlertDismissed: false,
      });
    },

    selectComponent: (id: string) => set({ selectedComponent: id }),
    dismissFaultAlert: () => set({ faultAlertDismissed: true }),
    showFaultAlert: () => set({ faultAlertDismissed: false }),

    emergencyStop: () => {
      engine.emergencyStop();
      set({ motion: engine.getState().motion });
    },

    toggleDoorCycle: () => {
      engine.toggleDoorCycle();
      set({ motion: engine.getState().motion });
    },

    setAutoCycle: (enabled: boolean) => {
      engine.setAutoCycle(enabled);
    },

    requestFloor: (floorIndex: number) => {
      const ok = engine.requestFloor(floorIndex);
      set({ motion: engine.getState().motion });
      return ok;
    },

    returnToGround: () => {
      const ok = engine.returnToGround();
      set({ motion: engine.getState().motion });
      return ok;
    },

    setTotalFloors: (count: number) => {
      const floors = generateFloors(count);
      engine.setFloors(floors);
      set({ floors, motion: engine.getState().motion });
    },

    // Authentication (Feature 3)
    loginMaintenance: (session: MaintenanceSession) => {
      try {
        if (typeof window !== "undefined" && window.localStorage) {
          localStorage.setItem("elevator_rca_maintenance_session", JSON.stringify(session));
        }
      } catch {}
      set({ maintenanceSession: session });
    },

    logoutMaintenance: () => {
      try {
        if (typeof window !== "undefined" && window.localStorage) {
          localStorage.removeItem("elevator_rca_maintenance_session");
        }
      } catch {}
      set({ maintenanceSession: null });
    },

    // Maintenance Workflow Methods
    reportFaultToMaintenance: () => {
      const state = get();
      if (state.activeFault) {
        maintenanceFsm.reportFault(
          state.activeFault.affectedComponent,
          state.activeFault.name
        );
        engine.setOperatingState("FAULT_DETECTED");
        set({ maintenance: maintenanceFsm.getWorkflow(), motion: engine.getState().motion });
      }
    },

    openInvestigation: () => {
      maintenanceFsm.openInvestigation();
      engine.setOperatingState("UNDER_INSPECTION");
      set({ maintenance: maintenanceFsm.getWorkflow(), motion: engine.getState().motion });
    },

    startRepair: (technician: string, action: string, partsReplaced?: string) => {
      const notes = partsReplaced ? `${action} (Parts Replaced: ${partsReplaced})` : action;
      maintenanceFsm.startRepair(technician, notes);
      engine.setOperatingState("UNDER_REPAIR");
      set({ maintenance: maintenanceFsm.getWorkflow(), motion: engine.getState().motion });
    },

    submitForVerification: (technician: string) => {
      maintenanceFsm.submitForVerification(technician);
      engine.setOperatingState("REPAIR_VERIFICATION");
      set({ maintenance: maintenanceFsm.getWorkflow(), motion: engine.getState().motion });
    },

    verifyRepair: (technician: string, forceFail = false) => {
      const state = get();
      const criteria: VerificationCriteria[] = [];

      // Check post-repair sensor values against baseline criteria
      if (state.activeFault) {
        for (const key of Object.keys(state.activeFault.sensorDeltas)) {
          const s = state.sensors[key];
          if (s) {
            const measured = forceFail
              ? (s.readings.slice(-1)[0]?.value ?? s.baseline)
              : s.baseline;
            const target = s.warnThreshold;
            criteria.push({
              channelName: key,
              targetMax: target,
              measuredPostRepair: measured,
              unit: s.unit,
              passed: !forceFail && measured <= target,
            });
          }
        }
      }

      if (criteria.length === 0) {
        criteria.push({
          channelName: "Vibration",
          targetMax: 0.09,
          measuredPostRepair: state.sensors["Vibration"]?.readings.slice(-1)[0]?.value ?? 0.04,
          unit: "g",
          passed: !forceFail,
        });
      }

      const result = maintenanceFsm.verifyRepair(technician, criteria, forceFail);

      if (result.passed) {
        engine.clearFault();
        engine.clearDegradation();
        engine.setRecoveryPermitted(true);
        const s = engine.getState();
        set({
          activeFault: undefined,
          diagnostic: undefined,
          degradationState: s.degradationState,
          degradationConfig: s.degradationConfig,
          motion: s.motion,
        });
      } else {
        engine.setRecoveryPermitted(false);
        set({
          motion: engine.getState().motion,
        });
      }

      const updatedWf = maintenanceFsm.getWorkflow();
      set({ maintenance: updatedWf });

      // Background cloud sync
      const activeWo = maintenanceFsm.getActiveWorkOrder();
      if (activeWo) {
        syncService.pushWorkOrderToCloud(activeWo).catch(() => {});
      }
      const latestAudit = updatedWf.auditTrail[updatedWf.auditTrail.length - 1];
      if (latestAudit) {
        syncService.pushAuditEntryToCloud(latestAudit).catch(() => {});
      }

      return result;
    },

    requestRecovery: () => {
      const state = get();
      if (state.maintenance.state !== "repair_verified" || state.activeFault) {
        return false;
      }
      engine.setServiceState("RECOVERY_MODE");
      const ok = engine.returnToGround();
      set({ motion: engine.getState().motion });
      return ok;
    },

    confirmReturnToService: () => {
      const state = get();
      if (
        state.maintenance.state !== "repair_verified" ||
        state.activeFault ||
        state.motion.currentFloor !== 0
      ) {
        return false;
      }
      engine.setServiceState("IN_SERVICE");
      set({ motion: engine.getState().motion });
      return true;
    },

    // Archival & Storage Retention
    requestArchival: () => {
      maintenanceFsm.requestArchival();
      set({ maintenance: maintenanceFsm.getWorkflow() });
    },

    confirmArchival: () => {
      maintenanceFsm.confirmArchival();
      set({ maintenance: maintenanceFsm.getWorkflow() });
    },

    verifyBackup: () => {
      maintenanceFsm.verifyBackup();
      set({ maintenance: maintenanceFsm.getWorkflow() });
    },

    executeRawLogCleanup: () => {
      const res = maintenanceFsm.executeRawLogCleanup();
      set({ maintenance: maintenanceFsm.getWorkflow() });
      return res;
    },

    // Deterministic Timeline Replay & Scrubbing Controls
    startReplay: (targetTime?: number) => {
      const history = engine.getTimelineHistory();
      if (history.length === 0) return;
      const initialTime = targetTime !== undefined ? targetTime : history[0].time;
      get().pauseSimulation();
      get().seekReplay(initialTime);
    },

    seekReplay: (targetTime: number) => {
      const history = engine.getTimelineHistory();
      if (history.length === 0) return;
      const snap = history.find((s) => s.time === targetTime) || history[history.length - 1];
      if (!snap) return;

      const currSensors = get().sensors;
      const replayedSensors: Record<string, SensorData> = {};
      for (const [k, v] of Object.entries(currSensors)) {
        const snapSensor = snap.sensors[k];
        replayedSensors[k] = {
          ...v,
          status: snapSensor ? snapSensor.status : v.status,
          readings: [
            ...v.readings.filter((r) => r.timestamp <= targetTime * 1000),
            ...(snapSensor ? [{ timestamp: targetTime * 1000, value: snapSensor.value }] : []),
          ].slice(-60),
        };
      }

      set({
        replayMode: true,
        replayTime: snap.time,
        motion: snap.motion,
        time: snap.time,
        cumulativeMotorTime: snap.cumulativeMotorTime,
        operatingCycles: snap.operatingCycles,
        activeFault: snap.activeFault,
        sensors: replayedSensors,
      });
    },

    stepReplay: (deltaSeconds: number) => {
      const history = engine.getTimelineHistory();
      if (history.length === 0) return;
      const currReplayTime = get().replayTime ?? engine.getState().time;
      const targetTime = Math.max(
        history[0].time,
        Math.min(history[history.length - 1].time, currReplayTime + deltaSeconds)
      );
      get().seekReplay(targetTime);
    },

    stopReplay: () => {
      const s = engine.getState();
      set({
        replayMode: false,
        replayTime: null,
        time: s.time,
        motion: s.motion,
        sensors: s.sensors,
        activeFault: s.activeFault,
        cumulativeMotorTime: s.cumulativeMotorTime,
        operatingCycles: s.operatingCycles,
      });
    },

    // Explainable Hypothesis Technician Confirmation & Rejection
    confirmHypothesis: (hypothesisId: string, notes?: string) => {
      const currDiag = get().diagnostic;
      if (!currDiag) return;
      const actor = get().maintenanceSession?.user.fullName || "M. Vance (Field Tech)";
      const updated = currDiag.hypotheses.map((h) => {
        if (h.id === hypothesisId) {
          return {
            ...h,
            technicianVerdict: "confirmed" as const,
            technicianNotes: notes || "Hypothesis confirmed by physical technician inspection.",
            technicianActor: actor,
            verdictTimestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
          };
        }
        return h;
      });
      maintenanceFsm.logCustomAudit(
        actor,
        `Confirmed RCA Hypothesis [${hypothesisId}]`,
        notes || "Hypothesis verified against physical equipment condition."
      );
      set({
        diagnostic: { ...currDiag, hypotheses: updated },
        maintenance: maintenanceFsm.getWorkflow(),
      });
    },

    rejectHypothesis: (hypothesisId: string, notes: string) => {
      const currDiag = get().diagnostic;
      if (!currDiag) return;
      const actor = get().maintenanceSession?.user.fullName || "M. Vance (Field Tech)";
      const updated = currDiag.hypotheses.map((h) => {
        if (h.id === hypothesisId) {
          return {
            ...h,
            technicianVerdict: "rejected" as const,
            technicianNotes: notes,
            technicianActor: actor,
            verdictTimestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
          };
        }
        return h;
      });
      maintenanceFsm.logCustomAudit(
        actor,
        `Rejected RCA Hypothesis [${hypothesisId}]`,
        `Ruled out: ${notes}`
      );
      set({
        diagnostic: { ...currDiag, hypotheses: updated },
        maintenance: maintenanceFsm.getWorkflow(),
      });
    },

    // Maintenance Work Orders
    toggleWorkOrderStep: (stepId: string, completed?: boolean) => {
      maintenanceFsm.toggleWorkOrderStep(stepId, completed);
      const wf = maintenanceFsm.getWorkflow();
      set({ maintenance: wf });
      const activeWo = maintenanceFsm.getActiveWorkOrder();
      if (activeWo) {
        syncService.pushWorkOrderToCloud(activeWo).catch(() => {});
      }
    },

    updateWorkOrder: (updates: Partial<MaintenanceWorkOrder>) => {
      maintenanceFsm.updateActiveWorkOrder(updates);
      const wf = maintenanceFsm.getWorkflow();
      set({ maintenance: wf });
      const activeWo = maintenanceFsm.getActiveWorkOrder();
      if (activeWo) {
        syncService.pushWorkOrderToCloud(activeWo).catch(() => {});
      }
    },
  }))
);
