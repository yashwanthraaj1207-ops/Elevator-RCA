// src/pages/Settings.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useTheme } from "../context/ThemeContext";
import { useElevatorStore } from "../simulation/store";
import {
  Settings as SettingsIcon,
  Sun,
  Moon,
  Sliders,
  Bell,
  Save,
  CheckCircle2,
  Building,
} from "lucide-react";

export const Settings: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const assetId = useElevatorStore((s) => s.assetId);
  const model = useElevatorStore((s) => s.model);

  const [savedNotice, setSavedNotice] = useState(false);
  const [samplingRate, setSamplingRate] = useState("1000");
  const [vibrationThreshold, setVibrationThreshold] = useState("1.50");
  const [tempThreshold, setTempThreshold] = useState("65.0");
  const [currentLimit, setCurrentLimit] = useState("20.0");

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-sage" />
            Engineering Interface & Threshold Settings
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Configure display themes, alarm tripping envelopes, and telemetry sampling frequencies.
          </p>
        </div>

        {savedNotice && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sage/15 border border-sage/30 text-sage text-xs font-semibold animate-fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings saved successfully</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-5">
        {/* 1. Theme Configuration */}
        <Card className="p-5 border-border space-y-4">
          <div className="flex items-center gap-2 border-b border-border pb-2.5">
            <Sliders className="w-4 h-4 text-sage" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Visual Identity & Display Theme
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Dark Mode Card */}
            <div
              onClick={() => setTheme("dark")}
              className={`p-4 rounded-xl border cursor-pointer transition-all space-y-2 ${
                theme === "dark"
                  ? "bg-surface border-sage ring-1 ring-sage/30 shadow-subtle"
                  : "bg-card border-border hover:border-border-strong hover:bg-surface/30"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-text-primary flex items-center gap-2">
                  <Moon className="w-4 h-4 text-text-primary" />
                  Dark Theme (Graphite)
                </span>
                {theme === "dark" && (
                  <span className="w-2 h-2 rounded-full bg-sage" />
                )}
              </div>
              <p className="text-text-secondary text-[11px] leading-relaxed">
                Deep charcoal surfaces (#171916), warm ivory typography (#F3F0E7), and sage green accents. Calibrated for low-fatigue industrial monitoring.
              </p>
              <div className="flex items-center gap-1.5 pt-1">
                <span className="w-4 h-4 rounded bg-[#171916] border border-[#333730]" />
                <span className="w-4 h-4 rounded bg-[#1E211D]" />
                <span className="w-4 h-4 rounded bg-[#252923]" />
                <span className="w-4 h-4 rounded bg-[#91B7A0]" />
                <span className="w-4 h-4 rounded bg-[#E7AA55]" />
              </div>
            </div>

            {/* Light Mode Card */}
            <div
              onClick={() => setTheme("light")}
              className={`p-4 rounded-xl border cursor-pointer transition-all space-y-2 ${
                theme === "light"
                  ? "bg-surface border-sage ring-1 ring-sage/30 shadow-subtle"
                  : "bg-card border-border hover:border-border-strong hover:bg-surface/30"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-text-primary flex items-center gap-2">
                  <Sun className="w-4 h-4 text-amber-warm" />
                  Light Theme (Ivory)
                </span>
                {theme === "light" && (
                  <span className="w-2 h-2 rounded-full bg-sage" />
                )}
              </div>
              <p className="text-text-secondary text-[11px] leading-relaxed">
                Warm ivory background (#F5F3EC), clean white cards (#FFFFFF), dark charcoal text (#252820), and muted sage tones.
              </p>
              <div className="flex items-center gap-1.5 pt-1">
                <span className="w-4 h-4 rounded bg-[#F5F3EC] border border-[#E2DFD6]" />
                <span className="w-4 h-4 rounded bg-[#ECEAE1]" />
                <span className="w-4 h-4 rounded bg-[#FFFFFF] border border-[#E2DFD6]" />
                <span className="w-4 h-4 rounded bg-[#668D74]" />
                <span className="w-4 h-4 rounded bg-[#C88735]" />
              </div>
            </div>
          </div>
        </Card>

        {/* 2. Alarm Tripping Threshold Envelopes */}
        <Card className="p-5 border-border space-y-4">
          <div className="flex items-center gap-2 border-b border-border pb-2.5">
            <Bell className="w-4 h-4 text-amber-warm" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Alarm Tripping Thresholds (ISO 13374 / EN 81-20)
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="font-medium text-text-primary">
                Bearing Vibration Limit (mm/s)
              </label>
              <input
                type="number"
                step="0.05"
                value={vibrationThreshold}
                onChange={(e) => setVibrationThreshold(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
              />
              <span className="text-[10px] text-text-muted">ISO 10816 Zone C critical limit</span>
            </div>

            <div className="space-y-1.5">
              <label className="font-medium text-text-primary">
                Motor Temperature Trip (°C)
              </label>
              <input
                type="number"
                step="1"
                value={tempThreshold}
                onChange={(e) => setTempThreshold(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
              />
              <span className="text-[10px] text-text-muted">Stator winding insulation safety limit</span>
            </div>

            <div className="space-y-1.5">
              <label className="font-medium text-text-primary">
                Peak Motor Current Cutoff (A)
              </label>
              <input
                type="number"
                step="0.5"
                value={currentLimit}
                onChange={(e) => setCurrentLimit(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
              />
              <span className="text-[10px] text-text-muted">Drive inverter overcurrent trip</span>
            </div>
          </div>
        </Card>

        {/* 3. Asset & Telemetry Rate Configuration */}
        <Card className="p-5 border-border space-y-4">
          <div className="flex items-center gap-2 border-b border-border pb-2.5">
            <Building className="w-4 h-4 text-sage" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Asset Identity & Sampling Parameters
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="font-medium text-text-primary">Elevator Asset ID</label>
              <input
                type="text"
                defaultValue={assetId}
                disabled
                className="w-full px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-muted font-mono cursor-not-allowed"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-medium text-text-primary">Model Designation</label>
              <input
                type="text"
                defaultValue={model}
                disabled
                className="w-full px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-muted font-mono cursor-not-allowed"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-medium text-text-primary">Simulation Sampling Period</label>
              <select
                value={samplingRate}
                onChange={(e) => setSamplingRate(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary font-mono focus:outline-none focus:border-sage"
              >
                <option value="1000">1000ms (1 Hz Nominal)</option>
                <option value="500">500ms (2 Hz High-Rate)</option>
                <option value="2000">2000ms (0.5 Hz Power-Save)</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <Button type="submit" variant="primary" className="flex items-center gap-1.5 text-xs font-semibold">
            <Save className="w-3.5 h-3.5" />
            Save Configuration
          </Button>
        </div>
      </form>
    </div>
  );
};

export default Settings;
