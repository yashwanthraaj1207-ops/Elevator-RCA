import React, { useState } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { useTheme } from "../context/ThemeContext";
import { useElevatorStore } from "../simulation/store";
import {
  Sun,
  Moon,
  Search,
  Bell,
  Play,
  Pause,
  RotateCcw,
  ChevronDown,
  Building2,
  User,
  LogOut,
  ShieldCheck,
  Volume2,
  VolumeX,
  ExternalLink,
  Globe,
} from "lucide-react";
import { getAudioMuted, setAudioMuted } from "../utils/audioAnnouncement";

export const Header: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [isMuted, setIsMutedState] = useState<boolean>(getAudioMuted());

  const running = useElevatorStore((s) => s.running);
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const pauseSimulation = useElevatorStore((s) => s.pauseSimulation);
  const resetSimulation = useElevatorStore((s) => s.resetSimulation);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const assetId = useElevatorStore((s) => s.assetId);
  const session = useElevatorStore((s) => s.maintenanceSession);
  const logoutMaintenance = useElevatorStore((s) => s.logoutMaintenance);

  // Derive human-readable page name from path
  const path = location.pathname.replace(/^\//, "");
  const pageTitles: Record<string, string> = {
    "": "Overview",
    overview: "Engineering Overview",
    "digital-twin": "Digital Twin Visualization",
    "live-monitoring": "Live Sensor Telemetry",
    investigation: "Fault Analysis & RCA",
    "fault-lab": "Fault Injection Laboratory",
    maintenance: "Maintenance & Field Verification",
    records: "Diagnostic Event Records",
    report: "Investigation RCA Report",
    storage: "Data Storage & Retention",
    settings: "System & Interface Settings",
  };
  const title = pageTitles[path] || "Elevator Diagnostics";

  return (
    <header className="h-16 border-b border-border bg-card px-4 flex items-center justify-between gap-4 select-none shrink-0 transition-colors">
      {/* Left: Breadcrumbs & Page Context */}
      <div className="flex items-center gap-3 min-w-0">
        <div>
          <div className="flex items-center gap-1.5 text-[11px] font-mono text-text-muted">
            <Link to="/overview" className="hover:text-text-primary transition-colors">
              Elevator-RCA
            </Link>
            <span>/</span>
            <span className="text-text-secondary capitalize">{path || "Overview"}</span>
          </div>
          <h1 className="text-sm md:text-base font-bold text-text-primary tracking-tight truncate">
            {title}
          </h1>
        </div>

        {/* Selected Asset Selector Chip */}
        <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-surface border border-border text-xs text-text-primary">
          <Building2 className="w-3.5 h-3.5 text-sage" />
          <span className="font-mono font-semibold">{assetId}</span>
          <span className="text-text-muted">•</span>
          <span className="text-text-secondary">North Tower (Bay 4)</span>
          <ChevronDown className="w-3 h-3 text-text-muted" />
        </div>

        {/* Project Explanation Website Link */}
        <a
          href="https://rca-elevator.netlify.app/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sage/15 hover:bg-sage/25 text-sage border border-sage/40 text-xs font-semibold transition-all hover:scale-[1.02] shadow-subtle shrink-0"
          title="ELEVATOR-RCA | Explainable Causal AI for Intelligent Elevator Fault Diagnosis"
        >
          <Globe className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Project Website</span>
          <span className="md:hidden">Website</span>
          <ExternalLink className="w-3 h-3 opacity-80" />
        </a>
      </div>

      {/* Middle: Universal Search */}
      <div className="hidden md:flex items-center flex-1 max-w-xs relative">
        <Search className="w-3.5 h-3.5 text-text-muted absolute left-3 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search telemetry, faults, components..."
          className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary placeholder:text-text-muted focus:outline-none focus:border-sage transition-colors"
        />
      </div>

      {/* Right: Simulation Controls, Notifications, Theme Toggle */}
      <div className="flex items-center gap-2">
        {/* Quick Simulation Control Pill */}
        <div className="flex items-center bg-surface border border-border rounded-lg p-0.5">
          {running ? (
            <button
              onClick={pauseSimulation}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md text-amber-warm hover:bg-surface-hover transition-colors"
              title="Pause Simulation"
            >
              <Pause className="w-3 h-3" />
              <span className="hidden lg:inline">Pause</span>
            </button>
          ) : (
            <button
              onClick={startSimulation}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md text-sage hover:bg-surface-hover transition-colors"
              title="Start Simulation"
            >
              <Play className="w-3 h-3" />
              <span className="hidden lg:inline">Resume</span>
            </button>
          )}

          <button
            onClick={resetSimulation}
            className="p-1 rounded-md text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors"
            title="Reset Simulation"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>

        {/* Notifications Icon with Badge */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-lg bg-surface border border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors relative"
            title="System Notifications"
          >
            <Bell className="w-4 h-4" />
            {activeFault && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-coral animate-ping" />
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-72 bg-card border border-border rounded-xl shadow-elevated p-3 z-50 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-border">
                <span className="font-semibold text-text-primary">System Notifications</span>
                <span className="text-[10px] font-mono text-text-muted">Live</span>
              </div>
              <div className="py-2 space-y-2">
                {activeFault ? (
                  <div className="p-2 rounded-lg bg-coral/10 border border-coral/30 text-coral">
                    <div className="font-semibold">{activeFault.name}</div>
                    <div className="text-[11px] text-text-secondary mt-0.5">
                      Target: {activeFault.affectedComponent}
                    </div>
                  </div>
                ) : (
                  <div className="text-text-secondary text-center py-2">
                    No active fault alerts.
                  </div>
                )}
                <div className="p-2 rounded-lg bg-surface border border-border text-text-secondary">
                  <div className="font-medium text-text-primary">3D Asset Connected</div>
                  <div className="text-[11px]">Local GLB model loaded (12.6 MB)</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Audible Alarm Beep & Voice Mute Toggle */}
        <button
          onClick={() => {
            const next = !isMuted;
            setAudioMuted(next);
            setIsMutedState(next);
          }}
          className={`p-2 rounded-lg border transition-colors flex items-center justify-center ${
            isMuted
              ? "bg-surface border-border text-text-muted hover:text-text-primary"
              : "bg-sage/15 border-sage/30 text-sage hover:bg-sage/25"
          }`}
          title={isMuted ? "Audio Alarms Muted (Click to Unmute)" : "Audio Alarms Active (Click to Mute)"}
          aria-label={isMuted ? "Unmute Audio" : "Mute Audio"}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Theme Toggle Button */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg bg-surface border border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors flex items-center justify-center"
          title={`Switch to ${theme === "dark" ? "Light (Ivory)" : "Dark (Graphite)"} Mode`}
          aria-label="Toggle theme"
        >
          {theme === "dark" ? (
            <Sun className="w-4 h-4 text-amber-warm transition-transform duration-200 rotate-0 hover:rotate-45" />
          ) : (
            <Moon className="w-4 h-4 text-text-primary transition-transform duration-200 -rotate-12 hover:rotate-0" />
          )}
        </button>

        {/* Engineer Login / Active Session */}
        {session ? (
          <div className="flex items-center gap-1.5 pl-2 border-l border-border">
            <Link
              to="/login"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-surface hover:bg-surface-hover border border-border text-xs text-text-primary transition-colors"
              title="Engineer Session Settings"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-sage" />
              <span className="font-semibold">{session.user.fullName.split(" ")[0]}</span>
              <span className="text-[10px] font-mono text-sage uppercase font-bold px-1 rounded bg-sage/15 border border-sage/30">
                {session.user.role}
              </span>
            </Link>
            <button
              onClick={() => {
                logoutMaintenance();
                navigate("/login");
              }}
              className="p-1.5 rounded-lg text-text-muted hover:text-coral hover:bg-surface transition-colors"
              title="Log Out Session"
              aria-label="Log out"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="flex items-center pl-2 border-l border-border">
            <Link
              to="/login"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sage/15 hover:bg-sage/25 text-sage border border-sage/30 text-xs font-semibold transition-colors"
              title="Engineer Access & Login"
            >
              <User className="w-3.5 h-3.5" />
              <span>Login</span>
            </Link>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
