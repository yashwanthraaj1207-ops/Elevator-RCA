// src/pages/Storage.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore } from "../simulation/store";
import {
  Database,
  HardDrive,
  Archive,
  ShieldCheck,
  FileCheck,
  CheckCircle2,
  XCircle,
  Trash2,
  Lock,
  RefreshCw,
} from "lucide-react";
import { DataQualityCentreCard } from "../components/storage/DataQualityCentreCard";

export const Storage: React.FC = () => {
  const maintenance = useElevatorStore((s) => s.maintenance);
  const requestArchival = useElevatorStore((s) => s.requestArchival);
  const confirmArchival = useElevatorStore((s) => s.confirmArchival);
  const verifyBackup = useElevatorStore((s) => s.verifyBackup);
  const executeRawLogCleanup = useElevatorStore((s) => s.executeRawLogCleanup);

  const [gateFeedback, setGateFeedback] = useState<{
    type: "success" | "error" | "info";
    message: string;
  } | null>(null);

  const isRepairVerified = [
    "repair_verified",
    "archival_pending",
    "archived",
    "cleanup_eligible",
    "cleanup_completed",
  ].includes(maintenance.state);

  const isArchived = [
    "archived",
    "cleanup_eligible",
    "cleanup_completed",
  ].includes(maintenance.state);

  const isBackupVerified = [
    "cleanup_eligible",
    "cleanup_completed",
  ].includes(maintenance.state);

  const isCleanedUp = maintenance.state === "cleanup_completed";

  const handleRequestArchival = () => {
    try {
      requestArchival();
      setGateFeedback({
        type: "success",
        message: "Archival package requested and prepared for statutory sealing.",
      });
    } catch (e: any) {
      setGateFeedback({ type: "error", message: e.message });
    }
  };

  const handleConfirmArchival = () => {
    try {
      confirmArchival();
      setGateFeedback({
        type: "success",
        message: "Archival package confirmed and sealed in immutable diagnostic vault.",
      });
    } catch (e: any) {
      setGateFeedback({ type: "error", message: e.message });
    }
  };

  const handleVerifyBackup = () => {
    try {
      verifyBackup();
      setGateFeedback({
        type: "success",
        message: "Independent offsite replica backup hash verified (SHA-256 matched).",
      });
    } catch (e: any) {
      setGateFeedback({ type: "error", message: e.message });
    }
  };

  const handleExecutePurge = () => {
    const res = executeRawLogCleanup();
    if (res.success) {
      setGateFeedback({ type: "success", message: res.message });
    } else {
      setGateFeedback({ type: "error", message: res.message });
    }
  };

  const retentionPolicies = [
    {
      partition: "Raw Telemetry Ingestion Buffer",
      description: "High-frequency 1Hz sensor readings (Current, Vibration, Temp, Speed)",
      retention: "30 Days Rolling",
      storageType: "In-Memory / Local Cache",
      size: isCleanedUp ? "0.0 MB (Purged)" : "18.4 MB (Active)",
      status: isCleanedUp ? "Compacted & Purged" : "Active Ingestion",
    },
    {
      partition: "Diagnostic Incident Snapshots",
      description: "Anomaly trigger event snapshots, multi-hypothesis reasoning graphs",
      retention: "1 Year Statutory",
      storageType: "Encrypted Immutable Vault",
      size: "4.2 MB",
      status: isArchived ? "Sealed & Verified" : "Active Staging",
    },
    {
      partition: "Compliance & Statutory Reports",
      description: "Formal EN 81-20 safety audits, signed return-to-service work orders",
      retention: "7 Years Statutory",
      storageType: "Cold Archive Replica",
      size: "1.1 MB",
      status: isArchived ? "Archived" : "Staged",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Database className="w-5 h-5 text-sage" />
            Data Storage & Lifecycle Retention Gatekeeper
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            4-phase telemetry retention pipeline, statutory archival sealing, and strict prerequisite-gated log purge.
          </p>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-secondary font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-sage" />
          <span>ISO 27001 / EN 81-20 Enforced</span>
        </div>
      </div>

      {/* Gate Feedback Banner */}
      {gateFeedback && (
        <div
          className={`p-3.5 rounded-lg border flex items-center justify-between text-xs ${
            gateFeedback.type === "success"
              ? "bg-sage/10 border-sage/30 text-sage"
              : "bg-coral/10 border-coral/30 text-coral"
          }`}
        >
          <div className="flex items-center gap-2">
            {gateFeedback.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <XCircle className="w-4 h-4 shrink-0" />
            )}
            <span className="font-mono">{gateFeedback.message}</span>
          </div>
          <button
            onClick={() => setGateFeedback(null)}
            className="underline text-[11px] hover:text-text-primary"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Storage Volume KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Active Local Telemetry</span>
            <HardDrive className="w-4 h-4 text-sage" />
          </div>
          <div className="text-xl font-bold font-mono text-text-primary">
            {isCleanedUp ? "5.3 MB" : "23.7 MB"}
          </div>
          <div className="text-[11px] text-text-muted">
            {isCleanedUp ? "Raw buffer purged, RCA retained" : "In-browser memory & buffer"}
          </div>
        </Card>

        <Card className="p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>3D Model Asset Footprint</span>
            <Database className="w-4 h-4 text-text-muted" />
          </div>
          <div className="text-xl font-bold font-mono text-text-primary">12.6 MB</div>
          <div className="text-[11px] text-sage font-mono">public/models/NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb</div>
        </Card>

        <Card className="p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Cold Archival Vault</span>
            <Archive className="w-4 h-4 text-amber-warm" />
          </div>
          <div className="text-sm font-bold text-text-primary font-mono">
            {isArchived ? "SEALED & ENCRYPTED" : "UNSEALED"}
          </div>
          <div className="text-[11px] text-sage font-mono">
            {maintenance.archivedAt ? `Timestamp: ${maintenance.archivedAt.slice(0, 10)}` : "Pending Sign-off"}
          </div>
        </Card>

        <Card className="p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Backup Parity Hash</span>
            <ShieldCheck className="w-4 h-4 text-sage" />
          </div>
          <div className="text-sm font-bold text-text-primary font-mono">
            {isBackupVerified ? "SHA-256 MATCHED" : "UNVERIFIED"}
          </div>
          <div className="text-[11px] text-sage">Offsite Replica Parity</div>
        </Card>
      </div>

      {/* Data Quality & Stream Health Centre */}
      <DataQualityCentreCard />

      {/* Section 7: Retention Prerequisite Gatekeeping Interface */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-sage" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Telemetry Deletion Prerequisite Gatekeeper
            </h3>
          </div>
          <span className="text-[10px] font-mono text-text-muted">
            State: {maintenance.state.toUpperCase()}
          </span>
        </div>

        <p className="text-xs text-text-secondary leading-relaxed">
          High-frequency 1Hz raw sensor data cannot be purged or overwritten unless all three statutory criteria are verified.
          Negative testing verifies that attempting premature purge is strictly rejected by the diagnostic core.
        </p>

        {/* 3 Prerequisite Checks */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Prerequisite 1 */}
          <div
            className={`p-3.5 rounded-lg border text-xs space-y-1.5 ${
              isRepairVerified
                ? "bg-sage/10 border-sage/30 text-text-primary"
                : "bg-surface border-border text-text-muted"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold">1. Repair Retest Verified</span>
              {isRepairVerified ? (
                <CheckCircle2 className="w-4 h-4 text-sage" />
              ) : (
                <XCircle className="w-4 h-4 text-coral" />
              )}
            </div>
            <p className="text-[11px] text-text-secondary">
              Physical repairs complete and sensor telemetry meets baseline limits.
            </p>
            <div className="text-[10px] font-mono text-sage font-semibold">
              Status: {isRepairVerified ? "MET" : "PENDING"}
            </div>
          </div>

          {/* Prerequisite 2 */}
          <div
            className={`p-3.5 rounded-lg border text-xs space-y-1.5 ${
              isArchived
                ? "bg-sage/10 border-sage/30 text-text-primary"
                : "bg-surface border-border text-text-muted"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold">2. Cold Archival Sealed</span>
              {isArchived ? (
                <CheckCircle2 className="w-4 h-4 text-sage" />
              ) : (
                <XCircle className="w-4 h-4 text-coral" />
              )}
            </div>
            <p className="text-[11px] text-text-secondary">
              Signed incident package preserved in statutory long-term storage.
            </p>
            <div className="text-[10px] font-mono text-sage font-semibold">
              Status: {isArchived ? "MET" : "PENDING"}
            </div>
          </div>

          {/* Prerequisite 3 */}
          <div
            className={`p-3.5 rounded-lg border text-xs space-y-1.5 ${
              isBackupVerified
                ? "bg-sage/10 border-sage/30 text-text-primary"
                : "bg-surface border-border text-text-muted"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold">3. Offsite Backup Verified</span>
              {isBackupVerified ? (
                <CheckCircle2 className="w-4 h-4 text-sage" />
              ) : (
                <XCircle className="w-4 h-4 text-coral" />
              )}
            </div>
            <p className="text-[11px] text-text-secondary">
              Cryptographic SHA-256 parity match confirmed with remote replica.
            </p>
            <div className="text-[10px] font-mono text-sage font-semibold">
              Status: {isBackupVerified ? "MET" : "PENDING"}
            </div>
          </div>
        </div>

        {/* Step-by-Step Gate Progression Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-border">
          {maintenance.state === "repair_verified" && (
            <Button
              variant="secondary"
              size="sm"
              onClick={handleRequestArchival}
              className="text-xs font-semibold"
            >
              <Archive className="w-3.5 h-3.5 mr-1 text-sage" />
              1. Request Archival Package
            </Button>
          )}

          {maintenance.state === "archival_pending" && (
            <Button
              variant="secondary"
              size="sm"
              onClick={handleConfirmArchival}
              className="text-xs font-semibold"
            >
              <ShieldCheck className="w-3.5 h-3.5 mr-1 text-sage" />
              2. Confirm Archival & Seal Vault
            </Button>
          )}

          {maintenance.state === "archived" && (
            <Button
              variant="secondary"
              size="sm"
              onClick={handleVerifyBackup}
              className="text-xs font-semibold"
            >
              <RefreshCw className="w-3.5 h-3.5 mr-1 text-sage" />
              3. Verify Offsite Replica Parity
            </Button>
          )}

          {/* Primary Action: Purge Raw Telemetry */}
          <Button
            variant="primary"
            size="sm"
            onClick={handleExecutePurge}
            disabled={isCleanedUp}
            className="text-xs font-semibold"
          >
            <Trash2 className="w-3.5 h-3.5 mr-1" />
            {isCleanedUp ? "Raw Telemetry Already Purged" : "Execute Raw Telemetry Purge"}
          </Button>

          {/* Negative Testing Button */}
          {!isBackupVerified && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExecutePurge}
              className="text-xs font-semibold text-coral border border-coral/40 hover:bg-coral/10"
              title="Test Gatekeeper: will fail because prerequisites are unfulfilled"
            >
              Negative Test: Attempt Premature Purge
            </Button>
          )}
        </div>
      </Card>

      {/* Partitions & Retention Policy Table */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-sage" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Diagnostic Telemetry Partitions & Lifecycle Envelopes
            </h3>
          </div>
          <span className="text-[10px] font-mono text-text-muted">Live Partition Status</span>
        </div>

        <div className="overflow-x-auto border border-border rounded-lg">
          <table className="w-full text-left text-xs">
            <thead className="bg-surface text-text-secondary border-b border-border font-mono">
              <tr>
                <th className="py-2.5 px-3 font-semibold">Storage Partition</th>
                <th className="py-2.5 px-3 font-semibold">Description & Content Scope</th>
                <th className="py-2.5 px-3 font-semibold">Retention Policy</th>
                <th className="py-2.5 px-3 font-semibold">Storage Tier</th>
                <th className="py-2.5 px-3 font-semibold">Volume</th>
                <th className="py-2.5 px-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {retentionPolicies.map((p, i) => (
                <tr key={i} className="hover:bg-surface/40 transition-colors">
                  <td className="py-3 px-3 font-bold text-text-primary font-mono">{p.partition}</td>
                  <td className="py-3 px-3 text-text-secondary max-w-xs">{p.description}</td>
                  <td className="py-3 px-3 font-mono font-bold text-sage">{p.retention}</td>
                  <td className="py-3 px-3 text-text-muted">{p.storageType}</td>
                  <td className="py-3 px-3 font-mono text-text-primary">{p.size}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold bg-sage/15 text-sage border border-sage/30">
                      {p.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Audit History Log */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-sage" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Storage Engine & Archival Audit Log ({maintenance.auditTrail.length} Records)
            </h3>
          </div>
          <span className="text-[10px] font-mono text-text-muted">Immutable Ledger</span>
        </div>

        <div className="space-y-2 max-h-72 overflow-y-auto">
          {maintenance.auditTrail.map((item) => (
            <div
              key={item.id}
              className="p-3 rounded-lg bg-surface border border-border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-text-muted text-[11px]">{item.timestamp}</span>
                  <span className="font-semibold text-text-primary">• {item.actor}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-card border border-border text-sage font-medium">
                    {item.fromState} → {item.toState}
                  </span>
                </div>
                <div className="text-text-primary font-medium text-[11px]">{item.action}</div>
                <div className="text-text-secondary text-[11px] font-mono">{item.evidence}</div>
              </div>

              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-card border border-border text-sage font-bold self-start sm:self-center">
                {item.id}
              </span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Storage;
