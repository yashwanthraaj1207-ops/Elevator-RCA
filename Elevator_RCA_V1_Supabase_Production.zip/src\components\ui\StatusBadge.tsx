// src/components/ui/StatusBadge.tsx
import React from "react";

export interface StatusBadgeProps {
  status: "normal" | "warning" | "fault" | "info";
  label?: string;
  size?: "sm" | "md";
  showDot?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  label,
  size = "sm",
  showDot = true,
}) => {
  const displayLabel = label || status.toUpperCase();

  const config = {
    normal: {
      bg: "bg-sage/15 border-sage/30 text-sage",
      dot: "bg-sage",
    },
    warning: {
      bg: "bg-amber-warm/15 border-amber-warm/30 text-amber-warm",
      dot: "bg-amber-warm",
    },
    fault: {
      bg: "bg-coral/15 border-coral/30 text-coral",
      dot: "bg-coral animate-pulse",
    },
    info: {
      bg: "bg-surface border-border text-text-secondary",
      dot: "bg-text-muted",
    },
  }[status];

  const sizeClasses = size === "sm" ? "px-2 py-0.5 text-[10px]" : "px-2.5 py-1 text-xs";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-mono font-medium tracking-wide uppercase transition-colors ${config.bg} ${sizeClasses}`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />}
      <span>{displayLabel}</span>
    </span>
  );
};

export default StatusBadge;
