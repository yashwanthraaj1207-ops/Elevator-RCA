// src/pages/Maintenance.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore } from "../simulation/store";
import { MaintenanceState } from "../simulation/maintenance";
import { MaintenanceLoginModal } from "../components/maintenance/MaintenanceLoginModal";
import { BeforeAfterVerificationCard } from "../components/maintenance/BeforeAfterVerificationCard";
import {
  Wrench,
  CheckCircle2,
  UserCheck,
  ClipboardList,
  FileCheck2,
  Check,
  AlertTriangle,
  ShieldCheck,
  Play,
  ArrowRight,
  XCircle,
  FileText,
  Lock,
  RotateCcw,
  Home,
  CheckCircle,
} from "lucide-react";
import { generateRcaPdf } from "../utils/reportExport";

const LIFECYCLE_STEPS: { state: MaintenanceState; label: string }[] = [
  { state: "fault_detected", label: "Fault Detected" },
  { state: "investigation_open", label: "Investigation Open" },
  { state: "repair_in_progress", label: "Repair In Progress" },
  { state: "awaiting_verification", label: "Awaiting Retest" },
  { state: "repair_verified", label: "Repair Verified" },
  { state: "archival_pending", label: "Archival Pending" },
  { state: "archived", label: "Archived" },
  { state: "cleanup_eligible", label: "Cleanup Eligible" },
  { state: "cleanup_completed", label: "Purged & Closed" },
];

interface MaintenanceTask {
  id: string;
  subsystem: string;
  title: string;
  status: "completed" | "in_progress" | "pending";
  assignedTo: string;
  beforeVal: string;
  targetVal: string;
  afterVal?: string;
}

export const Maintenance: React.FC = () => {
  const activeFault = useElevatorStore((s) => s.activeFault);
  const assetId = useElevatorStore((s) => s.assetId);
  const maintenance = useElevatorStore((s) => s.maintenance);
  const session = useElevatorStore((s) => s.maintenanceSession);
  const motion = useElevatorStore((s) => s.motion);

  const openInvestigation = useElevatorStore((s) => s.openInvestigation);
  const startRepair = useElevatorStore((s) => s.startRepair);
  const submitForVerification = useElevatorStore((s) => s.submitForVerification);
  const verifyRepair = useElevatorStore((s) => s.verifyRepair);
  const requestRecovery = useElevatorStore((s) => s.requestRecovery);
  const confirmReturnToService = useElevatorStore((s) => s.confirmReturnToService);
  const toggleWorkOrderStep = useElevatorStore((s) => s.toggleWorkOrderStep);
  const updateWorkOrder = useElevatorStore((s) => s.updateWorkOrder);

  const [techName, setTechName] = useState(
    session?.user.fullName ? `${session.user.fullName} (${session.user.id})` : "M. Vance (Field Tech #4812)"
  );
  const [partsReplaced, setPartsReplaced] = useState("Seals & Rolling Elements (OEM Pack #SKF-2214)");
  const [repairNotes, setRepairNotes] = useState(
    "Inspected assembly, flushed contaminated lubricant, renewed seals, and torqued fasteners to OEM specs."
  );
  const [dialogOpen, setDialogOpen] = useState(false);
  const [signedOff, setSignedOff] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Synchronize technician name when logged-in session changes
  React.useEffect(() => {
    if (session) {
      setTechName(`${session.user.fullName} (${session.user.id})`);
    }
  }, [session]);

  const [tasks, setTasks] = useState<MaintenanceTask[]>([
    {
      id: "WO-401",
      subsystem: "Main Drive Bearing",
      title: "Clean bearing housing, flush old lubricant, and replenish with NLGI 2 synthetic grease.",
      status: activeFault?.affectedComponent === "bearing_main" ? "in_progress" : "completed",
      assignedTo: "M. Vance (Field Tech)",
      beforeVal: "0.18 g (Peak)",
      targetVal: "< 0.08 g",
      afterVal: "0.04 g",
    },
    {
      id: "WO-402",
      subsystem: "Door Operator System",
      title: "Inspect car door sill guide shoes, clear foreign debris from tracks, calibrate optical curtain.",
      status: activeFault?.affectedComponent === "door_system" ? "in_progress" : "completed",
      assignedTo: "K. Chen (Electrical)",
      beforeVal: "8.2s Cycle Time",
      targetVal: "3.5s Nominal",
      afterVal: "3.4s",
    },
    {
      id: "WO-403",
      subsystem: "Electromechanical Brake",
      title: "Verify brake shoe lining thickness (> 4.0mm), measure solenoid air-gap clearance, static torque test.",
      status: activeFault?.affectedComponent === "brake_assembly" ? "in_progress" : "completed",
      assignedTo: "M. Vance (Field Tech)",
      beforeVal: "0.45m Slip Drift",
      targetVal: "0.00m Zero Slip",
      afterVal: "0.00m",
    },
    {
      id: "WO-404",
      subsystem: "Guide Rails & Shoes",
      title: "Check guide rail lubricating wicks, measure bracket clip torque to 85 Nm specifications.",
      status: "completed",
      assignedTo: "J. Doe (Apprentice)",
      beforeVal: "78 Nm",
      targetVal: "85 Nm",
      afterVal: "85 Nm",
    },
  ]);

  const toggleTaskStatus = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextStatus = t.status === "completed" ? "pending" : "completed";
          return { ...t, status: nextStatus };
        }
        return t;
      })
    );
  };

  // Privileged guard helper: Requires valid technician session
  const requireSession = () => {
    if (!session) {
      setActionError("Privileged Maintenance Action Blocked: You must authenticate with technician credentials before performing maintenance or repair actions.");
      return false;
    }
    return true;
  };

  const handleOpenInvestigation = () => {
    try {
      setActionError(null);
      if (!requireSession()) return;
      openInvestigation();
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  const handleStartRepair = () => {
    try {
      setActionError(null);
      if (!requireSession()) return;
      startRepair(techName, repairNotes, partsReplaced);
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  const handleSubmitForVerification = () => {
    try {
      setActionError(null);
      if (!requireSession()) return;
      submitForVerification(techName);
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  const handleVerifyRepair = (forceFail: boolean) => {
    try {
      setActionError(null);
      if (!requireSession()) return;
      verifyRepair(techName, forceFail);
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  const handleRequestRecovery = () => {
    try {
      setActionError(null);
      if (!requireSession()) return;
      const ok = requestRecovery();
      if (!ok) {
        setActionError("Recovery not permitted: System must be verified and safe for cabin movement.");
      }
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  const handleFinalReturnToService = () => {
    try {
      setActionError(null);
      if (!requireSession()) return;
      const ok = confirmReturnToService();
      if (ok) {
        setSignedOff(true);
        setDialogOpen(false);
      } else {
        setActionError("Service restoration denied: Elevator cabin must first complete ground-floor return travel (Floor 0).");
      }
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  // State styling helper
  const getStateBadge = (st: MaintenanceState) => {
    switch (st) {
      case "fault_detected":
      case "verification_failed":
        return "bg-coral/15 text-coral border-coral/30";
      case "investigation_open":
      case "repair_in_progress":
      case "awaiting_verification":
      case "archival_pending":
        return "bg-amber-warm/15 text-amber-warm border-amber-warm/30";
      case "repair_verified":
      case "archived":
      case "cleanup_eligible":
      case "cleanup_completed":
        return "bg-sage/15 text-sage border-sage/30";
      default:
        return "bg-surface text-text-muted border-border";
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Wrench className="w-5 h-5 text-sage" />
            Maintenance & Field Verification FSM
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Role-authenticated engineering work orders, 10-state lifecycle verification, and staged return-to-service recovery.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {session ? (
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-sage flex items-center gap-1.5 px-2.5 py-1 rounded bg-sage/15 border border-sage/30">
                <ShieldCheck className="w-3.5 h-3.5" />
                Auth: {session.user.fullName}
              </span>
              <Button
                variant="primary"
                onClick={() => setDialogOpen(true)}
                className="flex items-center gap-1.5 text-xs font-semibold"
              >
                <FileCheck2 className="w-4 h-4" />
                Authorize Return to Service
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-amber-warm flex items-center gap-1 px-2.5 py-1 rounded bg-amber-warm/15 border border-amber-warm/30">
                <Lock className="w-3.5 h-3.5" />
                Unauthenticated (Read-Only)
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Feature 3: Maintenance Authentication Section */}
      <MaintenanceLoginModal />

      {/* 10-State Lifecycle Stepper */}
      <Card className="p-4 border-border space-y-3">
        <div className="flex items-center justify-between border-b border-border pb-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-sage" />
            <span className="text-xs font-bold uppercase tracking-wider text-text-primary">
              10-State Maintenance & Verification Pipeline
            </span>
          </div>
          <span className={`text-[11px] font-mono px-2 py-0.5 rounded border uppercase font-bold ${getStateBadge(maintenance.state)}`}>
            Current: {maintenance.state.replace("_", " ")}
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2 pt-1">
          {LIFECYCLE_STEPS.map((step, idx) => {
            const isActive = maintenance.state === step.state;
            const isFailed = maintenance.state === "verification_failed" && step.state === "awaiting_verification";
            return (
              <div
                key={step.state}
                className={`p-2 rounded-lg border text-center transition-all ${
                  isActive
                    ? "bg-sage/15 border-sage text-sage font-bold shadow-sm"
                    : isFailed
                    ? "bg-coral/15 border-coral text-coral font-bold"
                    : "bg-surface/50 border-border text-text-muted opacity-80"
                }`}
              >
                <div className="text-[10px] font-mono mb-0.5">0{idx + 1}</div>
                <div className="text-[11px] leading-tight truncate" title={step.label}>
                  {step.label}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Action Error Banner */}
      {actionError && (
        <div className="p-3.5 rounded-lg bg-coral/10 border border-coral/30 text-coral flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <XCircle className="w-4 h-4 shrink-0" />
            <span>{actionError}</span>
          </div>
          <button onClick={() => setActionError(null)} className="underline text-[11px] hover:text-text-primary">
            Dismiss
          </button>
        </div>
      )}

      {/* Active Incident & Controlled FSM Action Panel */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3">
          <div>
            <div className="text-xs font-mono text-text-muted">Active Work Order & Incident ID</div>
            <div className="text-base font-bold text-text-primary flex items-center gap-2">
              <span>{maintenance.incidentId}</span>
              <span className="text-xs font-normal text-text-secondary">({maintenance.subsystem})</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-text-muted">Assigned:</span>
            <span className="text-xs font-mono font-medium text-text-primary bg-surface px-2.5 py-1 rounded border border-border">
              {maintenance.assignedTechnician}
            </span>
          </div>
        </div>

        <div className="text-xs text-text-secondary bg-surface/60 p-3 rounded-lg border border-border">
          <div className="font-semibold text-text-primary mb-1">Issue Description / Alarm Trigger:</div>
          <div>{maintenance.issueDescription}</div>
        </div>

        {/* Dynamic Transition Action Controls */}
        <div className="p-4 rounded-lg bg-surface border border-border space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-text-primary flex items-center gap-2">
            <Play className="w-3.5 h-3.5 text-sage" />
            <span>Workflow State Action Controls</span>
          </div>

          {/* State: fault_detected */}
          {maintenance.state === "fault_detected" && (
            <div className="space-y-3">
              <p className="text-xs text-text-secondary">
                An anomaly threshold has tripped. To begin troubleshooting, formally open an engineering root-cause investigation.
              </p>
              <Button
                variant="primary"
                onClick={handleOpenInvestigation}
                className="flex items-center gap-1.5 text-xs font-semibold"
              >
                <FileText className="w-4 h-4" />
                Open Formal Root-Cause Investigation
              </Button>
            </div>
          )}

          {/* State: investigation_open or verification_failed */}
          {(maintenance.state === "investigation_open" || maintenance.state === "verification_failed") && (
            <div className="space-y-3">
              {maintenance.state === "verification_failed" && (
                <div className="p-2.5 rounded bg-coral/10 border border-coral/30 text-coral text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Previous retest failed! Re-inspect physical component before re-testing.</span>
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-text-muted font-mono mb-1">Technician Session</label>
                  <input
                    type="text"
                    value={techName}
                    onChange={(e) => setTechName(e.target.value)}
                    className="w-full px-3 py-1.5 rounded bg-card border border-border text-text-primary font-mono text-xs focus:outline-none focus:border-sage"
                  />
                </div>
                <div>
                  <label className="block text-text-muted font-mono mb-1">Parts Replaced / Inspected</label>
                  <input
                    type="text"
                    value={partsReplaced}
                    onChange={(e) => setPartsReplaced(e.target.value)}
                    placeholder="e.g. Rolling elements, brake pads"
                    className="w-full px-3 py-1.5 rounded bg-card border border-border text-text-primary text-xs focus:outline-none focus:border-sage"
                  />
                </div>
                <div>
                  <label className="block text-text-muted font-mono mb-1">Work Scope & Action Taken</label>
                  <input
                    type="text"
                    value={repairNotes}
                    onChange={(e) => setRepairNotes(e.target.value)}
                    className="w-full px-3 py-1.5 rounded bg-card border border-border text-text-primary text-xs focus:outline-none focus:border-sage"
                  />
                </div>
              </div>
              <Button
                variant="primary"
                onClick={handleStartRepair}
                className="flex items-center gap-1.5 text-xs font-semibold"
              >
                <Wrench className="w-4 h-4" />
                Commence Field Work (Transition to Repair In Progress)
              </Button>
            </div>
          )}

          {/* State: repair_in_progress */}
          {maintenance.state === "repair_in_progress" && (
            <div className="space-y-3">
              <p className="text-xs text-text-secondary">
                Physical maintenance in progress. Once hardware replacements and adjustments are complete, submit assembly for telemetry retest verification.
              </p>
              <Button
                variant="primary"
                onClick={handleSubmitForVerification}
                className="flex items-center gap-1.5 text-xs font-semibold"
              >
                <ArrowRight className="w-4 h-4" />
                Complete Work & Submit for Retest Verification
              </Button>
            </div>
          )}

          {/* State: awaiting_verification */}
          {maintenance.state === "awaiting_verification" && (
            <div className="space-y-3">
              <p className="text-xs text-text-secondary">
                Component is awaiting synthetic telemetry retest. The system will evaluate live sensor readings against OEM baseline limits before certifying return to service.
              </p>
              <div className="flex flex-wrap items-center gap-3">
                <Button
                  variant="primary"
                  onClick={() => handleVerifyRepair(false)}
                  className="flex items-center gap-1.5 text-xs font-semibold"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Execute Sensor Retest Verification (Positive Test)
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => handleVerifyRepair(true)}
                  className="flex items-center gap-1.5 text-xs font-semibold text-coral border-coral/40 hover:bg-coral/10"
                >
                  <XCircle className="w-4 h-4" />
                  Simulate Retest Failure (Demonstrate Negative Guard)
                </Button>
              </div>
            </div>
          )}

          {/* State: repair_verified or beyond */}
          {["repair_verified", "archival_pending", "archived", "cleanup_eligible", "cleanup_completed"].includes(
            maintenance.state
          ) && (
            <div className="space-y-3">
              <div className="p-3 rounded bg-sage/10 border border-sage/30 text-sage text-xs flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>
                    Repair retest successfully passed and certified! Incident is ready for Controlled Return to Service and Archival.
                  </span>
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    const s = useElevatorStore.getState();
                    generateRcaPdf({
                      assetId: s.assetId,
                      model: s.model,
                      activeFault: s.activeFault,
                      diagnostic: s.diagnostic,
                      motion: s.motion,
                      sensors: s.sensors,
                      maintenance: s.maintenance,
                      session: s.maintenanceSession,
                    });
                  }}
                  className="text-xs flex items-center gap-1.5 bg-surface text-text-primary hover:text-sage"
                >
                  <FileText className="w-3.5 h-3.5 text-sage" />
                  Download Verified RCA Report (PDF)
                </Button>
              </div>

              {/* Feature 6: Controlled Staged Recovery Strip */}
              <div className="p-3 rounded-lg bg-card border border-border space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-text-primary flex items-center gap-1.5">
                    <Home className="w-3.5 h-3.5 text-sage" />
                    Staged Recovery Sequence:
                  </span>
                  <span className="font-mono text-[11px] text-text-secondary">
                    Service: <strong className={motion.serviceState === "IN_SERVICE" ? "text-sage" : "text-amber-warm"}>{motion.serviceState}</strong> • Cabin Floor: <strong className="text-text-primary">{motion.currentFloor}</strong>
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {motion.currentFloor !== 0 && (
                    <Button
                      variant="amber"
                      size="sm"
                      onClick={handleRequestRecovery}
                      className="text-xs flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Step 1: Move Cabin to Ground Floor (Lobby)
                    </Button>
                  )}

                  <Button
                    variant="primary"
                    size="sm"
                    disabled={motion.currentFloor !== 0}
                    onClick={() => setDialogOpen(true)}
                    className="text-xs flex items-center gap-1"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    Step 2: Sign-Off & Restore Passenger Service
                  </Button>
                </div>
              </div>

              {maintenance.verificationEvidence && (
                <div className="pt-2">
                  <div className="text-[11px] font-mono text-text-muted mb-1">Retest Verification Criteria:</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {maintenance.verificationEvidence.map((c, i) => (
                      <div key={i} className="p-2 rounded bg-card border border-border text-xs flex justify-between items-center">
                        <span className="font-medium text-text-primary">{c.channelName}</span>
                        <span className="font-mono text-sage font-bold">
                          {c.measuredPostRepair} {c.unit} (Limit: ≤{c.targetMax}{c.unit}) ✓
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* Confirmation Dialog Overlay */}
      {dialogOpen && (
        <div className="fixed inset-0 bg-app/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl shadow-elevated p-6 max-w-md w-full space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-sage/15 text-sage flex items-center justify-center">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-text-primary">
                  Confirm Return to Service Sign-Off
                </h3>
                <p className="text-xs text-text-secondary">Asset {assetId} • North Tower</p>
              </div>
            </div>

            <p className="text-xs text-text-secondary leading-relaxed">
              Authorizing return-to-service clears active simulation fault flags, records a verified calibration timestamp in the audit log, and restores normal operational status.
            </p>

            <div className="p-3 rounded-lg bg-surface border border-border space-y-1 text-xs">
              <div className="flex justify-between font-mono">
                <span className="text-text-muted">Technician:</span>
                <span className="text-text-primary font-bold">{session?.user.fullName || techName}</span>
              </div>
              <div className="flex justify-between font-mono">
                <span className="text-text-muted">Cabin Position:</span>
                <span className="text-sage font-bold">Ground Floor (Floor 0) Verified</span>
              </div>
              <div className="flex justify-between font-mono">
                <span className="text-text-muted">Door Safety State:</span>
                <span className="text-sage font-bold">Closed & Interlocked</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-border">
              <Button variant="secondary" size="sm" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="sm" onClick={handleFinalReturnToService}>
                Confirm & Restore Service
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Sign-Off Success Banner */}
      {signedOff && (
        <div className="p-4 rounded-xl bg-sage/10 border border-sage/30 text-sage flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-semibold">
              Return-to-service successfully certified. Elevator is now IN SERVICE and passenger calls are enabled.
            </span>
          </div>
          <button
            onClick={() => setSignedOff(false)}
            className="text-[11px] underline text-text-secondary hover:text-text-primary"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Feature 6: Before-and-After Verification Comparison Card */}
      <BeforeAfterVerificationCard />

      {/* Feature 4: Incident-Linked Maintenance Work Order & Inspection Steps */}
      {maintenance.workOrders && maintenance.workOrders.length > 0 && (
        <Card className="p-5 border-border space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3">
            <div className="flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-sage" />
              <div>
                <h3 className="text-sm font-bold text-text-primary">
                  Active Corrective Work Order: {maintenance.workOrders[0].id}
                </h3>
                <p className="text-xs text-text-secondary mt-0.5">
                  Linked to Incident {maintenance.workOrders[0].incidentId} • Subsystem: {maintenance.workOrders[0].subsystem}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-coral/15 text-coral border border-coral/30 font-bold uppercase">
                Priority: {maintenance.workOrders[0].priority}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface border border-border text-text-primary uppercase font-bold">
                Status: {maintenance.workOrders[0].status.replace("_", " ")}
              </span>
            </div>
          </div>

          {/* Work Order Inspection Checklist Steps */}
          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase font-mono text-text-muted">
              Step-by-Step Mechanical & Electrical Verification Checklist:
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {maintenance.workOrders[0].inspectionSteps.map((step) => (
                <div
                  key={step.id}
                  onClick={() => toggleWorkOrderStep(step.id)}
                  className={`p-3 rounded-lg border text-xs cursor-pointer transition-all flex items-start gap-2.5 ${
                    step.completed
                      ? "bg-sage/10 border-sage/40 text-text-primary"
                      : "bg-surface border-border hover:border-text-secondary text-text-secondary"
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded border mt-0.5 shrink-0 flex items-center justify-center ${
                      step.completed ? "bg-sage border-sage text-[#171916]" : "border-border"
                    }`}
                  >
                    {step.completed && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div className="min-w-0">
                    <span className={step.completed ? "line-through text-text-muted font-normal" : "font-medium"}>
                      {step.step}
                    </span>
                    {step.completedAt && (
                      <div className="text-[10px] font-mono text-sage mt-0.5">
                        Completed at {step.completedAt.split(" ")[1] || step.completedAt}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Technician Scope & Parts Replaced */}
          <div className="p-3 rounded-lg bg-surface border border-border text-xs grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <span className="text-[10px] font-mono uppercase text-text-muted">Assigned Lead Technician:</span>
              <div className="font-bold text-text-primary mt-0.5">
                {maintenance.workOrders[0].assignedTechnician}
              </div>
              <div className="text-[11px] text-text-secondary mt-1">
                Notes: {maintenance.workOrders[0].technicianNotes}
              </div>
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-text-muted">Replacement Parts Installed:</span>
              <div className="font-mono text-text-primary mt-0.5">
                {partsReplaced || "OEM Pack #SKF-2214"}
              </div>
              <div className="text-[11px] text-text-muted mt-1 font-mono">
                Verification: {maintenance.workOrders[0].verificationPassed ? "Passed (Certified)" : "Awaiting Retest"}
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Routine Work Order Tasks Checklist */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-sage" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Standard Maintenance Checklist & Inspection Tasks
            </h3>
          </div>
          <span className="text-xs text-text-secondary">4 Engineering Tasks</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-border text-[11px] font-mono text-text-muted">
                <th className="py-2 px-3 w-8">Verify</th>
                <th className="py-2 px-3">WO ID</th>
                <th className="py-2 px-3">Subsystem</th>
                <th className="py-2 px-3">Task Scope</th>
                <th className="py-2 px-3">Pre-Repair</th>
                <th className="py-2 px-3">Target OEM</th>
                <th className="py-2 px-3">Post-Verification</th>
                <th className="py-2 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {tasks.map((task) => {
                const isDone = task.status === "completed";
                const isInProgress = task.status === "in_progress";

                return (
                  <tr key={task.id} className="hover:bg-surface/40 transition-colors">
                    <td className="py-2.5 px-3">
                      <button
                        onClick={() => toggleTaskStatus(task.id)}
                        className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                          isDone
                            ? "bg-sage border-sage text-[#171916]"
                            : "border-border hover:border-text-secondary"
                        }`}
                        title="Toggle verification status"
                      >
                        {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                      </button>
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-text-primary">{task.id}</td>
                    <td className="py-2.5 px-3 font-medium text-text-primary">{task.subsystem}</td>
                    <td className="py-2.5 px-3 text-text-secondary max-w-xs">{task.title}</td>
                    <td className="py-2.5 px-3 font-mono text-coral font-semibold">
                      {task.beforeVal}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-text-muted">{task.targetVal}</td>
                    <td className="py-2.5 px-3 font-mono text-sage font-bold">
                      {task.afterVal || "Pending Run"}
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                          isDone
                            ? "bg-sage/15 text-sage"
                            : isInProgress
                            ? "bg-amber-warm/15 text-amber-warm"
                            : "bg-surface text-text-muted"
                        }`}
                      >
                        {task.status.replace("_", " ")}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Immutable Maintenance Audit Trail */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-sage" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Immutable Maintenance FSM Audit Trail ({maintenance.auditTrail.length} Events)
            </h3>
          </div>
          <span className="text-[10px] font-mono text-text-muted">ISO 13374 Enforced</span>
        </div>

        <div className="space-y-2 max-h-72 overflow-y-auto">
          {maintenance.auditTrail.map((entry) => (
            <div
              key={entry.id}
              className="p-3 rounded-lg bg-surface border border-border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-text-muted text-[11px]">{entry.timestamp}</span>
                  <span className="font-mono font-bold text-text-primary">{entry.actor}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-card border border-border text-sage font-semibold">
                    {entry.fromState} → {entry.toState}
                  </span>
                </div>
                <div className="text-text-primary font-medium text-[11px]">{entry.action}</div>
                <div className="text-text-secondary text-[11px] font-mono">{entry.evidence}</div>
              </div>

              <span className="text-[10px] font-mono text-text-muted shrink-0 self-start sm:self-center">
                {entry.id}
              </span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Maintenance;
