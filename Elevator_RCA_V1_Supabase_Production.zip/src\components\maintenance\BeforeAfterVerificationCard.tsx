// src/components/maintenance/BeforeAfterVerificationCard.tsx
import React, { useState } from "react";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { useElevatorStore } from "../../simulation/store";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Check,
  RotateCcw,
  Sliders,
  TrendingDown,
  Info,
} from "lucide-react";

interface BeforeAfterVerificationCardProps {
  onRetestSuccess?: () => void;
  className?: string;
}

export const BeforeAfterVerificationCard: React.FC<BeforeAfterVerificationCardProps> = ({
  onRetestSuccess,
  className = "",
}) => {
  const activeFault = useElevatorStore((s) => s.activeFault);
  const maintenance = useElevatorStore((s) => s.maintenance);
  const sensors = useElevatorStore((s) => s.sensors);
  const session = useElevatorStore((s) => s.maintenanceSession);
  const motion = useElevatorStore((s) => s.motion);

  const startRepair = useElevatorStore((s) => s.startRepair);
  const submitForVerification = useElevatorStore((s) => s.submitForVerification);
  const verifyRepair = useElevatorStore((s) => s.verifyRepair);
  const requestRecovery = useElevatorStore((s) => s.requestRecovery);
  const confirmReturnToService = useElevatorStore((s) => s.confirmReturnToService);

  const [feedback, setFeedback] = useState<string | null>(null);

  const activeWo = maintenance.workOrders?.find((w) => w.id === maintenance.activeWorkOrderId) ||
    maintenance.workOrders?.[0];

  const technicianName = session?.user.fullName || "M. Vance (Field Tech #4812)";

  // Configured baseline verification targets per channel
  const verificationChannels = [
    {
      name: "Vibration",
      unit: "g",
      nominalTarget: 0.08,
      critLimit: 0.15,
      preValue: activeFault?.affectedComponent === "bearing_main" || activeFault?.affectedComponent === "guide_rail_left"
        ? 0.18
        : 0.04,
      postValue: sensors["Vibration"]?.readings.slice(-1)[0]?.value ?? 0.04,
    },
    {
      name: "Motor Temperature",
      unit: "°C",
      nominalTarget: 55.0,
      critLimit: 70.0,
      preValue: activeFault?.affectedComponent === "traction_motor" ? 78.5 : 42.0,
      postValue: sensors["Motor Temperature"]?.readings.slice(-1)[0]?.value ?? 42.0,
    },
    {
      name: "Motor Current",
      unit: "A",
      nominalTarget: 18.0,
      critLimit: 24.0,
      preValue: activeFault?.affectedComponent === "traction_motor" ? 26.5 : 12.5,
      postValue: sensors["Motor Current"]?.readings.slice(-1)[0]?.value ?? 12.5,
    },
    {
      name: "Door State",
      unit: "%",
      nominalTarget: 0,
      critLimit: 110,
      preValue: activeFault?.affectedComponent === "door_system" ? 45 : 0,
      postValue: sensors["Door State"]?.readings.slice(-1)[0]?.value ?? 0,
    },
    {
      name: "Brake State",
      unit: "%",
      nominalTarget: 100,
      critLimit: 110,
      preValue: activeFault?.affectedComponent === "brake_assembly" ? 60 : 100,
      postValue: sensors["Brake State"]?.readings.slice(-1)[0]?.value ?? 100,
    },
  ];

  const isVerified = maintenance.state === "repair_verified" ||
    maintenance.state === "archival_pending" ||
    maintenance.state === "archived" ||
    maintenance.state === "cleanup_eligible" ||
    maintenance.state === "cleanup_completed";

  const isFailed = maintenance.state === "verification_failed";

  const handleRunVerification = (simulateFailure: boolean) => {
    try {
      if (maintenance.state === "fault_detected") {
        useElevatorStore.getState().openInvestigation();
      }
      if (maintenance.state === "fault_detected" || maintenance.state === "investigation_open" || maintenance.state === "verification_failed") {
        startRepair(
          technicianName,
          simulateFailure
            ? "Preliminary check (incomplete torque)"
            : "Replaced degraded component, renewed seals and synthetic lubricant to OEM tolerances."
        );
        submitForVerification(technicianName);
      } else if (maintenance.state === "repair_in_progress") {
        submitForVerification(technicianName);
      }

      const res = verifyRepair(technicianName, simulateFailure);
      if (res.passed) {
        setFeedback("Retest PASSED: All sensor channels verified within standard baseline criteria.");
        if (onRetestSuccess) onRetestSuccess();
      } else {
        setFeedback("Retest FAILED: Simulated verification criteria rejected. Elevator return-to-service is strictly locked.");
      }
    } catch (err: any) {
      setFeedback(`Error: ${err.message}`);
    }
  };

  return (
    <Card className={`p-5 border-border space-y-4 ${className}`}>
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-sage" />
          <div>
            <h3 className="text-sm font-bold text-text-primary">
              Before-and-After Repair Verification Gate
            </h3>
            <p className="text-xs text-text-secondary mt-0.5">
              Empirical side-by-side sensor comparison certifying equipment recovery prior to return to service.
            </p>
          </div>
        </div>

        <span
          className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold uppercase border ${
            isVerified
              ? "bg-sage/15 text-sage border-sage/40"
              : isFailed
              ? "bg-coral/15 text-coral border-coral/40"
              : "bg-amber-warm/15 text-amber-warm border-amber-warm/40"
          }`}
        >
          {isVerified ? "VERIFICATION PASSED" : isFailed ? "VERIFICATION FAILED" : "AWAITING RETEST"}
        </span>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div
          className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
            feedback.includes("PASSED")
              ? "bg-sage/10 border-sage/30 text-sage"
              : "bg-coral/10 border-coral/30 text-coral"
          }`}
        >
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="underline text-[10px] ml-2">
            Dismiss
          </button>
        </div>
      )}

      {/* Comparison Grid Table */}
      <div className="overflow-x-auto border border-border rounded-lg">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-surface text-text-secondary border-b border-border">
            <tr>
              <th className="py-2.5 px-3 font-semibold">Sensor Channel</th>
              <th className="py-2.5 px-3 font-semibold">Pre-Repair (Anomaly)</th>
              <th className="py-2.5 px-3 font-semibold">Configured Target Limit</th>
              <th className="py-2.5 px-3 font-semibold">Post-Repair (Measured)</th>
              <th className="py-2.5 px-3 font-semibold">Outcome</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {verificationChannels.map((ch) => {
              const passed = isVerified || ch.postValue <= ch.nominalTarget || (ch.name === "Brake State" && ch.postValue >= 90);
              const delta = ch.preValue !== 0
                ? (((ch.postValue - ch.preValue) / ch.preValue) * 100).toFixed(0)
                : "0";

              return (
                <tr key={ch.name} className="hover:bg-surface/50 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-medium text-text-primary">
                    {ch.name}
                  </td>
                  <td className="py-2.5 px-3 text-coral font-bold">
                    {ch.preValue} {ch.unit}
                  </td>
                  <td className="py-2.5 px-3 text-text-muted">
                    {ch.name === "Brake State" ? "≥ 100 %" : `≤ ${ch.nominalTarget} ${ch.unit}`}
                  </td>
                  <td className={`py-2.5 px-3 font-bold ${passed ? "text-sage" : "text-coral"}`}>
                    {ch.postValue.toFixed(2)} {ch.unit}
                    {Number(delta) < 0 && (
                      <span className="text-[10px] text-sage font-normal ml-1">({delta}%)</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        passed ? "bg-sage/15 text-sage" : "bg-coral/15 text-coral"
                      }`}
                    >
                      {passed ? "PASS" : "FAIL"}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Return-to-Service Gate Status Banner */}
      <div
        className={`p-3.5 rounded-lg border flex flex-wrap items-center justify-between gap-3 text-xs ${
          isVerified
            ? "bg-sage/10 border-sage/30 text-text-primary"
            : "bg-surface border-border text-text-muted"
        }`}
      >
        <div className="flex items-center gap-2">
          {isVerified ? (
            <CheckCircle2 className="w-5 h-5 text-sage shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-amber-warm shrink-0" />
          )}
          <div>
            <span className="font-bold">
              {isVerified
                ? "SAFETY INTERLOCK CLEARED: Return-to-Service Permitted"
                : "SAFETY INTERLOCK ENGAGED: Return-to-Service Inhibited"}
            </span>
            <p className="text-[11px] text-text-secondary mt-0.5">
              {isVerified
                ? "Controlled recovery to Ground floor is authorized. Elevator can resume normal passenger travel."
                : "Retest must pass all nominal threshold criteria before the elevator can return to service."}
            </p>
          </div>
        </div>

        {/* Retest & Recovery Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {!isVerified && (
            <>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleRunVerification(true)}
                className="text-xs text-coral border-coral/30 hover:bg-coral/10"
                title="Test safety interlock with a failing re-test"
              >
                Simulate Negative Retest
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => handleRunVerification(false)}
                className="text-xs"
              >
                Execute Certified Retest
              </Button>
            </>
          )}

          {isVerified && motion.serviceState !== "IN_SERVICE" && (
            <>
              {motion.currentFloor !== 0 ? (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => requestRecovery()}
                  className="text-xs flex items-center gap-1"
                >
                  Return Cabin to Ground Floor
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              ) : (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => confirmReturnToService()}
                  className="text-xs flex items-center gap-1 bg-sage hover:bg-sage/90 text-charcoal-deep font-bold"
                >
                  <Check className="w-3.5 h-3.5" />
                  Certify & Return to Service
                </Button>
              )}
            </>
          )}

          {isVerified && motion.serviceState === "IN_SERVICE" && (
            <span className="text-xs font-mono font-bold text-sage px-3 py-1 rounded bg-sage/20 border border-sage/40 flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              ELEVATOR IN SERVICE
            </span>
          )}
        </div>
      </div>
    </Card>
  );
};

