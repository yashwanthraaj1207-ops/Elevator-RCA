// src/simulation/diagnostics.ts
/**
 * Explainable Diagnostic Reasoning Pipeline for ELEVATOR-RCA.
 *
 * Implements rule-based hypothesis generation, evidence correlation,
 * causal chain explanation, and hypothesis ranking with supporting & contradicting evidence.
 */

import { SensorData, FaultScenario } from "./engine";

export interface DiagnosticHypothesis {
  id: string;
  rank: number;
  componentId: string;
  title: string;
  description: string;
  // Prototype confidence score (0.0 to 1.0) calculated via weighted evidence
  confidence: number;
  confidenceCalculationNote: string;
  supportingEvidence: string[];
  contradictingEvidence: string[];
  evidence?: string[];
  expectedVsObserved: Array<{
    sensor: string;
    expected: string;
    observed: string;
    threshold: string;
  }>;
  relevantRule: string;
  rankingRationale: string;
  causalChain: string[];
  alternativeCauses: string[];
  limitations: string[];
  recommendedAction: string;
  severity: "warning" | "fault";
  technicianVerdict?: "confirmed" | "rejected" | "under_review";
  technicianNotes?: string;
  technicianActor?: string;
  verdictTimestamp?: string;
  evidenceLinks?: Array<{
    sensor: string;
    observedValue: number;
    baselineValue: number;
    threshold: number;
    unit: string;
    indicatesAnomaly: boolean;
    strength: number;
  }>;
}

export interface DiagnosticInvestigation {
  id: string;
  timestamp: string;
  isInconclusive: boolean;
  activeScenarioName: string;
  detectedAnomalies: string[];
  hypotheses: DiagnosticHypothesis[];
  summary: string;
}

/**
 * All 8 Canonical Fault Scenarios required by specification
 */
export const ALL_FAULT_SCENARIOS: Record<string, FaultScenario> = {
  normal: {
    id: "scenario_normal",
    name: "Normal Operation",
    description: "Standard elevator travel cycle with passengers. All sensors within normal baseline tolerance.",
    affectedComponent: "cabin_body",
    severity: "warning",
    sensorDeltas: {},
    expectedSymptoms: ["Stable nominal velocity", "ISO 18738 baseline vibration < 0.05g"],
  },
  motor_overheating: {
    id: "scenario_motor_overheating",
    name: "Motor Overheating",
    description: "Stator winding thermal breakdown from excessive run cycles and ventilation duct clogging.",
    affectedComponent: "traction_motor",
    severity: "fault",
    sensorDeltas: {
      "Motor Temperature": 32.5,
      "Motor Current": 4.5,
    },
    expectedSymptoms: ["Motor housing temp > 70°C", "Thermal gradient divergence", "Current draw increase"],
  },
  excessive_load: {
    id: "scenario_excessive_load",
    name: "Excessive Load (Overweight)",
    description: "Car load exceeds rated duty capacity (1600kg limit tripped).",
    affectedComponent: "cabin_body",
    severity: "fault",
    sensorDeltas: {
      "Payload Mass": 1350, // Pushes total to ~1800kg
      "Motor Current": 8.0,
      "Elevator Speed": -0.3,
    },
    expectedSymptoms: ["Payload > 1600kg trip limit", "Current spike > 20A", "Velocity droop on upward run"],
  },
  mechanical_vibration: {
    id: "scenario_mechanical_vibration",
    name: "Mechanical Rail Vibration",
    description: "T-section guide rail misalignment and worn guide shoe roller dampers.",
    affectedComponent: "guide_rail_left",
    severity: "warning",
    sensorDeltas: {
      "Vibration": 0.12, // Exceeds 0.15g critical
    },
    expectedSymptoms: ["High structural vibration > 0.15g", "Acoustic rumble in hoistway"],
  },
  traction_motor_fault: {
    id: "scenario_traction_motor_fault",
    name: "Traction Motor Winding Asymmetry",
    description: "Phase imbalance in permanent magnet synchronous motor winding causing torque ripple.",
    affectedComponent: "traction_motor",
    severity: "fault",
    sensorDeltas: {
      "Motor Current": 11.5,
      "Motor Temperature": 18.0,
      "Vibration": 0.06,
    },
    expectedSymptoms: ["Motor current surge > 24A", "Moderate thermal elevation", "Rotational harmonic ripple"],
  },
  bearing_degradation: {
    id: "scenario_bearing_degradation",
    name: "Main Drive Bearing Degradation",
    description: "Spherical roller bearing inner race fatigue spalling and cage wear.",
    affectedComponent: "bearing_main",
    severity: "fault",
    sensorDeltas: {
      "Vibration": 0.14,
      "Motor Temperature": 16.5,
      "Motor Current": 3.0,
    },
    expectedSymptoms: ["Bearing vibration spike > 0.15g", "Localized housing heat", "Current modulation"],
  },
  door_mechanism_fault: {
    id: "scenario_door_mechanism_fault",
    name: "Door Mechanism Obstruction",
    description: "Mechanical obstruction or interlock microswitch misalignment in car door sill track.",
    affectedComponent: "door_system",
    severity: "warning",
    inhibitsMovement: true,
    sensorDeltas: {
      "Door State": 45,
    },
    expectedSymptoms: ["Door position stalled at 45%", "Travel cycle timeout > 4.5s", "Safety edge torque trip"],
  },
  brake_related_fault: {
    id: "scenario_brake_related_fault",
    name: "Electromechanical Brake Slip / Lining Wear",
    description: "Brake friction lining degradation causing holding torque slippage and response delay.",
    affectedComponent: "brake_assembly",
    severity: "fault",
    sensorDeltas: {
      "Brake State": -40,
      "Cabin Position": 0.45,
    },
    expectedSymptoms: ["Holding drift at floor rest", "Brake drop-out response delay > 300ms"],
  },
  encoder_fault: {
    id: "scenario_encoder_fault",
    name: "Position Encoder Feedback Disagreement",
    description: "Optical pulse encoder channel mismatch resulting in discrepancy between counted pulses and physical shaft sensor switches.",
    affectedComponent: "position_encoder",
    severity: "fault",
    sensorDeltas: {
      "Cabin Position": 1.45,
      "Elevator Speed": -0.6,
    },
    expectedSymptoms: [
      "Encoder pulse divergence > 1.0m",
      "Velocity feedback mismatch",
      "Position sensor disagreement",
    ],
    inhibitsMovement: true,
  },
};

/**
 * Diagnostic Pipeline Evaluation Function:
 * Inspects live telemetry, detects anomalies, correlates signals, and produces explainable hypotheses.
 */
export function runDiagnosticPipeline(
  sensors: Record<string, SensorData>,
  activeScenario?: FaultScenario
): DiagnosticInvestigation {
  const now = new Date().toISOString().replace("T", " ").substring(0, 19);

  // 1. Detect anomalous sensors
  const anomalies: string[] = [];
  for (const [name, s] of Object.entries(sensors)) {
    const val = s.readings[s.readings.length - 1]?.value ?? 0;
    if (val >= s.critThreshold) {
      anomalies.push(`${name} exceeded critical threshold (${val.toFixed(2)} ${s.unit} ≥ ${s.critThreshold} ${s.unit})`);
    } else if (val >= s.warnThreshold) {
      anomalies.push(`${name} exceeded warning threshold (${val.toFixed(2)} ${s.unit} ≥ ${s.warnThreshold} ${s.unit})`);
    }
  }

  // 2. If no anomalies exist, return Normal Baseline Report
  if (anomalies.length === 0 && (!activeScenario || activeScenario.id === "scenario_normal")) {
    return {
      id: `INV-${Date.now().toString().slice(-6)}`,
      timestamp: now,
      isInconclusive: false,
      activeScenarioName: "Normal Operation",
      detectedAnomalies: [],
      hypotheses: [],
      summary: "All 8 telemetry channels are functioning within standard OEM baseline envelopes. System nominal.",
    };
  }

  // 3. Rule-based hypothesis generation matching active scenario / anomalies
  const hypotheses: DiagnosticHypothesis[] = [];
  const tempVal = sensors["Motor Temperature"]?.readings.slice(-1)[0]?.value ?? 42;
  const currVal = sensors["Motor Current"]?.readings.slice(-1)[0]?.value ?? 12.5;
  const vibVal = sensors["Vibration"]?.readings.slice(-1)[0]?.value ?? 0.04;
  const massVal = sensors["Payload Mass"]?.readings.slice(-1)[0]?.value ?? 450;
  const doorVal = sensors["Door State"]?.readings.slice(-1)[0]?.value ?? 0;
  const brakeVal = sensors["Brake State"]?.readings.slice(-1)[0]?.value ?? 100;

  // RULE A: Bearing Degradation Check (High Vibration + Moderate Temp Elevation)
  if (vibVal > 0.12 && tempVal > 50 && massVal <= 1600) {
    hypotheses.push({
      id: "HYP-BRG-01",
      rank: 1,
      componentId: "bearing_main",
      title: "Main Drive Bearing Inner Race Spalling",
      description: "Surface fatigue spalling on spherical roller bearing inner raceway causing elevated high-frequency vibrations.",
      confidence: 0.92,
      confidenceCalculationNote: "Calculated via ISO 13374 correlation: vibration (+250% baseline) + thermal elevation (+16°C). Prototype heuristic score.",
      supportingEvidence: [
        `Vibration velocity measured at ${vibVal.toFixed(3)}g (Critical limit: 0.15g).`,
        `Bearing housing temperature elevated to ${tempVal.toFixed(1)}°C (Baseline: 42°C).`,
        "Harmonic rotational frequency peaks detected in synthetic telemetry.",
      ],
      contradictingEvidence: [
        "Motor current draw (+3A) is only slightly elevated, ruling out primary winding short.",
      ],
      expectedVsObserved: [
        { sensor: "Vibration", expected: "0.04 g", observed: `${vibVal.toFixed(3)} g`, threshold: "0.15 g" },
        { sensor: "Motor Temperature", expected: "42.0 °C", observed: `${tempVal.toFixed(1)} °C`, threshold: "70.0 °C" },
      ],
      relevantRule: "RULE_BRG_01: IF Vibration > 0.12g AND Temp > 50°C THEN Suspect Bearing Fatigue (Weight: 0.92)",
      rankingRationale: "Direct correlation between high mechanical vibration and localized bearing thermal rise; guide rail sensors remain symmetric.",
      causalChain: [
        "1. Bearing raceway micro-fatigue initiation",
        "2. Spalling surface debris causing cyclical impact impulses",
        "3. High-frequency structural vibration propagation",
        "4. Friction thermal dissipation through bearing housing",
      ],
      alternativeCauses: [
        "Drive sheave groove wear",
        "Machine bedplate mounting bolt looseness",
      ],
      limitations: [
        "Vibration resolution in prototype is limited to 1Hz envelope analysis; full spectral FFT requires physical accelerometer.",
      ],
      recommendedAction: "Inspect spherical roller bearing lubrication cleanliness; schedule bearing cartridge replacement within 48h.",
      severity: "fault",
    });

    hypotheses.push({
      id: "HYP-MTR-02",
      rank: 2,
      componentId: "traction_motor",
      title: "Secondary Motor Rotor Misalignment",
      description: "Shaft eccentricity induced by radial play in degraded bearing assembly.",
      confidence: 0.45,
      confidenceCalculationNote: "Secondary hypothesis with partial evidence correlation (current surge moderate).",
      supportingEvidence: [
        `Motor current slightly elevated at ${currVal.toFixed(1)}A.`,
      ],
      contradictingEvidence: [
        "No significant stator phase imbalance detected.",
        "Temperature gradient centers at bearing end-bell, not stator core.",
      ],
      expectedVsObserved: [
        { sensor: "Motor Current", expected: "12.5 A", observed: `${currVal.toFixed(1)} A`, threshold: "24.0 A" },
      ],
      relevantRule: "RULE_MTR_03: IF Bearing Fault Active THEN Check Secondary Coupling Misalignment",
      rankingRationale: "Ranked below primary bearing spalling because motor current is not in critical trip envelope.",
      causalChain: ["Bearing radial play -> Shaft runout -> Air-gap dynamic variation"],
      alternativeCauses: ["Flexible coupling bushing degradation"],
      limitations: ["Rotor runout measurement is inferred from motor current delta."],
      recommendedAction: "Verify laser shaft alignment after bearing cartridge replacement.",
      severity: "warning",
    });
  }

  // RULE B: Motor Overheating Check
  if (tempVal >= 65.0 && vibVal < 0.12) {
    hypotheses.push({
      id: "HYP-MTR-01",
      rank: 1,
      componentId: "traction_motor",
      title: "Traction Motor Thermal Overload",
      description: "Stator core thermal saturation exceeding insulation Class F limits due to restricted air cooling.",
      confidence: 0.94,
      confidenceCalculationNote: "Evaluated by pure thermal rise (>70°C) with nominal vibration signatures.",
      supportingEvidence: [
        `Motor temperature reached ${tempVal.toFixed(1)}°C (Critical: 70.0°C).`,
        `Operating current elevated to ${currVal.toFixed(1)}A.`,
      ],
      contradictingEvidence: [
        `Vibration remains low at ${vibVal.toFixed(3)}g, ruling out mechanical bearing failure.`,
      ],
      expectedVsObserved: [
        { sensor: "Motor Temperature", expected: "42.0 °C", observed: `${tempVal.toFixed(1)} °C`, threshold: "70.0 °C" },
      ],
      relevantRule: "RULE_THM_01: IF Motor Temp > 65°C AND Vibration < 0.10g THEN Suspect Stator Overheat",
      rankingRationale: "Thermal channel strictly drives fault signature without mechanical vibration contribution.",
      causalChain: ["Air filter blockage -> Inadequate convection cooling -> Winding thermal accumulation"],
      alternativeCauses: ["Continuous duty cycle overload", "Drive inverter carrier frequency mismatch"],
      limitations: ["Thermal sensor measures external stator casing; internal hotspot may be 10°C higher."],
      recommendedAction: "Inspect forced cooling fan ducts and verify motor thermal protection relay calibration.",
      severity: "fault",
    });
  }

  // RULE C: Excessive Load Overweight Check
  if (massVal > 1500) {
    hypotheses.push({
      id: "HYP-LOAD-01",
      rank: 1,
      componentId: "cabin_body",
      title: "Cabin Payload Duty Capacity Exceeded",
      description: "Passenger load cell sensors confirm total cabin load exceeds 1600kg safety limit.",
      confidence: 0.96,
      confidenceCalculationNote: "Direct load cell calibration corroboration.",
      supportingEvidence: [
        `Payload mass measured at ${massVal.toFixed(0)}kg (Limit: 1600kg).`,
        `Motor current increased to ${currVal.toFixed(1)}A to compensate for counterweight imbalance.`,
      ],
      contradictingEvidence: ["No mechanical component faults detected; purely an operational load event."],
      expectedVsObserved: [
        { sensor: "Payload Mass", expected: "450 kg", observed: `${massVal.toFixed(0)} kg`, threshold: "1600 kg" },
      ],
      relevantRule: "RULE_LOAD_01: IF Payload > 1600kg THEN Trip Overload Buzzer & Inhibit Run",
      rankingRationale: "Deterministic threshold trip on primary load transducer.",
      causalChain: ["Passenger loading > capacity -> Load-weighing switch engages -> Drive hold active"],
      alternativeCauses: ["Load cell amplifier calibration drift"],
      limitations: ["Single-sum cabin load weighing; individual passenger distribution not tracked."],
      recommendedAction: "Sound cabin overload buzzer and prevent door close until passengers disembark.",
      severity: "fault",
    });
  }

  // RULE D: Mechanical Rail Vibration
  if (vibVal >= 0.10 && tempVal < 50 && activeScenario?.affectedComponent.includes("rail")) {
    hypotheses.push({
      id: "HYP-RAIL-01",
      rank: 1,
      componentId: "guide_rail_left",
      title: "Vertical Guide Rail Misalignment / Guide Shoe Wear",
      description: "Structural vibration during cabin travel caused by guide rail joint misalignment or worn sliding shoes.",
      confidence: 0.88,
      confidenceCalculationNote: "Tripped vibration channel with completely normal motor temperature and current.",
      supportingEvidence: [
        `Vibration sensor registered ${vibVal.toFixed(3)}g during hoistway travel.`,
      ],
      contradictingEvidence: [
        `Motor current (${currVal.toFixed(1)}A) and temperature (${tempVal.toFixed(1)}°C) remain nominal.`,
      ],
      expectedVsObserved: [
        { sensor: "Vibration", expected: "0.04 g", observed: `${vibVal.toFixed(3)} g`, threshold: "0.15 g" },
      ],
      relevantRule: "RULE_RAIL_02: IF Vibration > 0.10g AND Motor Temp < 50°C THEN Guide System Anomaly",
      rankingRationale: "Anomaly is strictly kinematic to car travel along shaft columns.",
      causalChain: ["Rail bracket thermal expansion / settlement -> Misalignment step -> Roller shoe impact"],
      alternativeCauses: ["Hoist rope flutter", "Safety gear drag"],
      limitations: ["Sensor is mounted on car frame; exact floor height of rail defect requires travel index log."],
      recommendedAction: "Execute electronic rail straightness survey and measure guide shoe lining thickness.",
      severity: "warning",
    });
  }

  // RULE E: Door Mechanism Fault
  if (doorVal > 10 && doorVal < 90 && activeScenario?.affectedComponent === "door_system") {
    hypotheses.push({
      id: "HYP-DOOR-01",
      rank: 1,
      componentId: "door_system",
      title: "Car Door Operator Sill Track Obstruction",
      description: "Car door interlock stalled mid-stroke; cycle timer exceeded allowable 4.0s envelope.",
      confidence: 0.91,
      confidenceCalculationNote: "Door position encoder freeze corroborated by interlock timeout.",
      supportingEvidence: [
        `Door state cycle stalled at ${doorVal.toFixed(0)}% travel.`,
        "Safety edge obstruction torque cut-off initiated.",
      ],
      contradictingEvidence: ["Drive machine room systems are fully nominal."],
      expectedVsObserved: [
        { sensor: "Door State", expected: "0% (Closed) / 100% (Open)", observed: `${doorVal.toFixed(0)}% Stalled`, threshold: "Complete Cycle" },
      ],
      relevantRule: "RULE_DOOR_01: IF Door Progress Stalls Between 10-90% for > 4s THEN Door Obstruction",
      rankingRationale: "Exact match with door cycle failure envelope.",
      causalChain: ["Foreign object in sill groove -> Roller shoe stall -> Operator torque limit trip"],
      alternativeCauses: ["Optical light curtain misalignment", "Drive belt tension loss"],
      limitations: ["Prototype does not differentiate between front and rear door sill tracks."],
      recommendedAction: "Inspect passenger car door sill for debris; test safety edge microswitch sensitivity.",
      severity: "warning",
    });
  }

  // RULE F: Brake Degradation Check
  if (brakeVal < 80 && activeScenario?.affectedComponent === "brake_assembly") {
    hypotheses.push({
      id: "HYP-BRK-01",
      rank: 1,
      componentId: "brake_assembly",
      title: "Electromechanical Brake Holding Torque Slippage",
      description: "Brake shoe lining friction decay and solenoid release response delay during floor stop.",
      confidence: 0.89,
      confidenceCalculationNote: "Brake microswitch feedback out of tolerance combined with cabin drift.",
      supportingEvidence: [
        `Brake state feedback dropped to ${brakeVal.toFixed(0)}% holding capacity.`,
        "Cabin position drift recorded during zero-speed holding phase.",
      ],
      contradictingEvidence: ["Traction motor electrical insulation is nominal."],
      expectedVsObserved: [
        { sensor: "Brake State", expected: "100% (Engaged)", observed: `${brakeVal.toFixed(0)}% Holding`, threshold: "100%" },
      ],
      relevantRule: "RULE_BRK_01: IF Brake State < 80% During Floor Hold THEN Brake Slippage Fault",
      rankingRationale: "Direct feedback from dual brake monitoring microswitches.",
      causalChain: ["Brake pad lining thinning -> Solenoid air gap expansion -> Holding torque reduction"],
      alternativeCauses: ["Brake spring mechanical fatigue", "Drive hold torque timing mismatch"],
      limitations: ["Static holding test required to verify mechanical breakaway torque in Nm."],
      recommendedAction: "Measure brake pad wear; verify air-gap clearance; execute static load hold test.",
      severity: "fault",
    });
  }

  // RULE G: Position Encoder Signal Disagreement
  if (activeScenario?.affectedComponent === "position_encoder" || (activeScenario?.id === "scenario_encoder_fault")) {
    hypotheses.push({
      id: "HYP-ENC-01",
      rank: 1,
      componentId: "position_encoder",
      title: "Position Encoder Pulse Feedback Disagreement",
      description: "Discrepancy detected between rotary pulse encoder count and shaft physical landing position sensors.",
      confidence: 0.93,
      confidenceCalculationNote: "Direct verification of optical pulse feedback divergence exceeding position tolerance.",
      supportingEvidence: [
        "Position feedback drift recorded between encoder pulses and shaft leveling vanes.",
        "Velocity feedback divergence during acceleration phase.",
      ],
      contradictingEvidence: ["Drive motor electrical winding current and temperature remain nominal."],
      expectedVsObserved: [
        { sensor: "Cabin Position", expected: "Nominal floor alignment", observed: "Pulse divergence > 1.0m", threshold: "0.25 m" },
      ],
      relevantRule: "RULE_ENC_01: IF Encoder Feedback Disagrees With Shaft Vane THEN Trip Safety Interlock",
      rankingRationale: "Disagreement directly triggers EN 81-20 position safety monitoring interlock.",
      causalChain: ["Optical disc contamination / pulse channel slip -> Position disagreement -> Safety stop"],
      alternativeCauses: ["Magnetic tape sensor head misalignment", "Shielded signal cable EMI noise"],
      limitations: ["Physical inspection required to verify optical disc cleanliness and reader head gap."],
      recommendedAction: "Clean optical reader lens, verify reader air-gap (1.5mm), and run shaft position recalibration trip.",
      severity: "fault",
    });
  }

  // Fallback: Generic or Inconclusive Diagnostic
  if (hypotheses.length === 0) {
    hypotheses.push({
      id: "HYP-GEN-01",
      rank: 1,
      componentId: activeScenario?.affectedComponent || "cabin_body",
      title: `Operational Anomaly in ${activeScenario?.name || "Subsystem"}`,
      description: "Telemetry signal divergence detected across monitored channels.",
      confidence: 0.65,
      confidenceCalculationNote: "Preliminary baseline divergence detection; insufficient specific rule correlation.",
      supportingEvidence: anomalies,
      contradictingEvidence: [],
      expectedVsObserved: [],
      relevantRule: "RULE_GEN_01: Heuristic baseline threshold trip",
      rankingRationale: "General heuristic anomaly categorization.",
      causalChain: ["Signal divergence -> Threshold boundary trip"],
      alternativeCauses: ["Transducer calibration drift", "Transient electrical noise"],
      limitations: ["Insufficient multi-channel correlation to confirm discrete failure mode."],
      recommendedAction: "Initiate manual sensor self-calibration and review continuous trend log.",
      severity: "warning",
    });
  }

  hypotheses.forEach((h) => {
    h.evidence = h.supportingEvidence;
    if (!h.evidenceLinks || h.evidenceLinks.length === 0) {
      h.evidenceLinks = Object.entries(sensors)
        .filter(
          ([sName, sData]) =>
            sData.status !== "normal" ||
            h.expectedVsObserved.some((eo) => eo.sensor.toLowerCase().includes(sName.toLowerCase()))
        )
        .map(([name, sData]) => {
          const latest = sData.readings[sData.readings.length - 1]?.value ?? sData.baseline;
          return {
            sensor: name,
            observedValue: Number(latest.toFixed(2)),
            baselineValue: sData.baseline,
            threshold: sData.critThreshold,
            unit: sData.unit,
            indicatesAnomaly: sData.status !== "normal",
            strength: sData.status === "fault" ? 0.95 : sData.status === "warning" ? 0.75 : 0.2,
          };
        });
    }
  });

  return {
    id: `INV-${Date.now().toString().slice(-6)}`,
    timestamp: now,
    isInconclusive: hypotheses[0]?.confidence < 0.70,
    activeScenarioName: activeScenario?.name || "Detected Telemetry Anomaly",
    detectedAnomalies: anomalies,
    hypotheses,
    summary: `${hypotheses[0].title} identified as primary root-cause suspect (${Math.round(hypotheses[0].confidence * 100)}% confidence).`,
  };
}
