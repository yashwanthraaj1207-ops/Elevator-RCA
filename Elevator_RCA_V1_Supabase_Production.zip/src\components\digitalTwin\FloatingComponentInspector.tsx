// src/components/digitalTwin/FloatingComponentInspector.tsx
/**
 * Compact Floating Component Inspector for ELEVATOR-RCA (Feature 2).
 *
 * Anchored to the edge (top-right) of the 3D viewer without blocking the central
 * elevator model or interfering with camera rotation controls.
 *
 * Provides:
 * - Direct mesh component identification & category
 * - Condition badge (NORMAL, WARNING, FAULT)
 * - Health score index & RUL estimate with uncertainty band (±hrs)
 * - Telemetry readings relevant to the subsystem
 * - Detected anomaly summary & diagnostic evidence
 * - Quick actions: Isolate, Explode, Inspect Details, Close
 * - Keyboard operable and collapsible to a mini header
 */

import React, { useState } from "react";
import {
  ComponentId,
  normalizeComponentId,
  COMPONENT_CATALOG,
  getComponentVerificationBadge,
} from "./componentMapping";
import { useElevatorStore } from "../../simulation/store";
import { evaluateComponentHealth } from "../../simulation/componentHealth";
import {
  X,
  ChevronDown,
  ChevronUp,
  Layers,
  Compass,
  AlertTriangle,
  ShieldCheck,
  TrendingDown,
  ExternalLink,
  Download,
  Megaphone,
  Volume2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { generateRcaPdf } from "../../utils/reportExport";
import { triggerDamageAnnouncement } from "../../utils/audioAnnouncement";

interface FloatingComponentInspectorProps {
  componentId: ComponentId | null;
  onClose: () => void;
  onToggleExploded?: () => void;
  onToggleIsolated?: () => void;
  isExploded?: boolean;
  isIsolated?: boolean;
}

export const FloatingComponentInspector: React.FC<FloatingComponentInspectorProps> = ({
  componentId,
  onClose,
  onToggleExploded,
  onToggleIsolated,
  isExploded = false,
  isIsolated = false,
}) => {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const sensors = useElevatorStore((s) => s.sensors);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const simTime = useElevatorStore((s) => s.time);
  const diagnostic = useElevatorStore((s) => s.diagnostic);

  if (!componentId) return null;

  const canonicalId = normalizeComponentId(componentId) || "bearing_main";
  const health = evaluateComponentHealth(canonicalId, sensors, activeFault, simTime);
  const meta = COMPONENT_CATALOG[canonicalId];
  const verificationBadge = meta ? getComponentVerificationBadge(meta.verificationTier) : null;

  // Relevant hypothesis if this component is implicated in active RCA
  const relevantHypothesis = diagnostic?.hypotheses.find(
    (h) => normalizeComponentId(h.componentId) === canonicalId
  );

  const getStatusColor = (state: "NORMAL" | "WARNING" | "FAULT") => {
    switch (state) {
      case "NORMAL":
        return {
          bg: "bg-sage/15 text-sage border-sage/30",
          bar: "bg-sage",
          dot: "bg-sage",
        };
      case "WARNING":
        return {
          bg: "bg-amber-warm/15 text-amber-warm border-amber-warm/30",
          bar: "bg-amber-warm",
          dot: "bg-amber-warm",
        };
      case "FAULT":
        return {
          bg: "bg-coral/15 text-coral border-coral/30",
          bar: "bg-coral",
          dot: "bg-coral animate-pulse",
        };
    }
  };

  const statusStyle = getStatusColor(health.operationalState);

  return (
    <div
      className="absolute top-14 right-3 z-20 w-[350px] max-w-[calc(100vw-2rem)] max-h-[calc(100%-4.5rem)] flex flex-col bg-card/95 backdrop-blur-md border border-border rounded-xl shadow-elevated overflow-hidden transition-all duration-200 select-none pointer-events-auto"
      role="region"
      aria-label="Component Telemetry & Health Inspector"
    >
      {/* Header Bar */}
      <div className="p-3 bg-surface border-b border-border flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <div className={`w-2 h-2 rounded-full ${statusStyle.dot}`} />
          <div className="min-w-0">
            <span className="text-[9px] font-mono uppercase tracking-wider text-text-muted block truncate">
              {health.category}
            </span>
            <h4 className="text-xs font-bold text-text-primary tracking-tight truncate">
              {health.name}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {verificationBadge && (
            <span
              className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase border ${verificationBadge.badgeClass}`}
              title={meta?.verificationNote}
            >
              {verificationBadge.shortLabel}
            </span>
          )}
          <span
            className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase border ${statusStyle.bg}`}
          >
            {health.operationalState}
          </span>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1 rounded text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors"
            title={collapsed ? "Expand Inspector" : "Collapse Inspector"}
            aria-label={collapsed ? "Expand" : "Collapse"}
          >
            {collapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors"
            title="Close Inspector"
            aria-label="Close Inspector"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Active Damage Announcement Alert Strip */}
      {health.operationalState === "FAULT" && (
        <div className="px-3 py-1.5 bg-coral/15 border-b border-coral/30 flex items-center justify-between gap-2 text-[11px] font-mono text-coral shrink-0">
          <div className="flex items-center gap-1.5 font-bold">
            <Megaphone className="w-3.5 h-3.5 animate-pulse shrink-0" />
            <span className="truncate">DAMAGE ANNOUNCEMENT</span>
          </div>
          <button
            onClick={() => triggerDamageAnnouncement(health.name, activeFault?.name)}
            className="px-2 py-0.5 rounded bg-coral/20 hover:bg-coral/30 text-coral text-[10px] font-bold flex items-center gap-1 transition-colors shrink-0"
            title="Play safety chime & spoken announcement"
          >
            <Volume2 className="w-3 h-3" />
            <span>Play Audio</span>
          </button>
        </div>
      )}

      {/* Body Content */}
      {!collapsed && (
        <div className="p-3 space-y-3 overflow-y-auto text-xs flex-1">
          {/* Health Index & Estimated RUL (Simulated Prognostics) */}
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2 rounded-lg bg-surface border border-border space-y-1">
              <div className="text-[10px] font-mono text-text-muted uppercase flex items-center justify-between">
                <span>Health Index</span>
                <ShieldCheck className="w-3 h-3 text-sage" />
              </div>
              <div className="text-lg font-bold font-mono text-text-primary">
                {health.healthScore} <span className="text-[10px] text-text-muted">/100</span>
              </div>
              <div className="w-full bg-card h-1 rounded-full overflow-hidden">
                <div
                  className={`h-full ${statusStyle.bar} transition-all duration-300`}
                  style={{ width: `${health.healthScore}%` }}
                />
              </div>
            </div>

            <div className="p-2 rounded-lg bg-surface border border-border space-y-1">
              <div className="text-[10px] font-mono text-text-muted uppercase flex items-center justify-between">
                <span>Estimated RUL</span>
                <TrendingDown className="w-3 h-3 text-amber-warm" />
              </div>
              <div className="text-base font-bold font-mono text-text-primary">
                {health.rulFormatted}
              </div>
              <div className="text-[10px] font-mono text-text-muted">
                {health.uncertaintyRange} ({health.confidencePercent}% conf)
              </div>
            </div>
          </div>

          {/* Physical Geometry Verification Tier & Manifest Status */}
          {verificationBadge && (
            <div className="p-2 rounded-lg bg-surface border border-border space-y-1 text-[11px]">
              <div className="flex items-center justify-between text-[10px] font-mono text-text-muted uppercase">
                <span>3D Geometry Tier</span>
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold border ${verificationBadge.badgeClass}`}>
                  {verificationBadge.shortLabel}
                </span>
              </div>
              <p className="text-text-secondary leading-snug text-[11px]">
                {meta?.verificationNote}
              </p>
            </div>
          )}

          {/* Subsystem Telemetry Metrics (Explicitly Labeled as Simulated) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-text-muted uppercase tracking-wider block">
                Subsystem Telemetry
              </span>
              <span className="text-[9px] font-mono text-amber-warm/80">
                (Simulated Measurements)
              </span>
            </div>
            <div className="space-y-1">
              {health.sensors.map((sensor) => {
                const sData = sensors[sensor.name];
                const latestVal = sData?.readings.slice(-1)[0]?.value ?? sensor.currentValue;
                const isOverCrit = latestVal >= sensor.critThreshold;

                return (
                  <div
                    key={sensor.name}
                    className="flex items-center justify-between p-1.5 rounded bg-surface border border-border text-[11px]"
                  >
                    <span className="text-text-secondary truncate max-w-[140px]">
                      {sensor.name}
                    </span>
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className={`font-semibold ${isOverCrit ? "text-coral" : "text-text-primary"}`}>
                        {typeof latestVal === "number" ? latestVal.toFixed(2) : latestVal} {sensor.unit}
                      </span>
                      <span className="text-[9px] text-text-muted">
                        (&le;{sensor.critThreshold})
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detected Anomaly or RCA Evidence (if any) */}
          {relevantHypothesis && (
            <div className="p-2 rounded-lg bg-coral/10 border border-coral/30 space-y-1 text-[11px]">
              <div className="flex items-center gap-1 text-coral font-bold font-mono text-[10px] uppercase">
                <AlertTriangle className="w-3 h-3" />
                Active Anomaly Evidence ({Math.round(relevantHypothesis.confidence * 100)}% conf)
              </div>
              <p className="text-text-primary leading-tight text-[11px]">
                {relevantHypothesis.title}
              </p>
              <div className="text-[10px] text-text-secondary mt-1">
                {relevantHypothesis.supportingEvidence[0]}
              </div>
            </div>
          )}

          {/* Action Strip: Isolate, Explode, Full Inspection */}
          <div className="pt-2 border-t border-border flex items-center justify-between gap-1.5">
            {onToggleIsolated && (
              <button
                onClick={onToggleIsolated}
                className={`flex-1 py-1 px-2 rounded text-[11px] font-medium transition-colors flex items-center justify-center gap-1 border ${
                  isIsolated
                    ? "bg-sage/20 text-sage border-sage/40 font-semibold"
                    : "bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary border-border"
                }`}
                title="Isolate this subassembly"
              >
                <Compass className="w-3 h-3" />
                <span>{isIsolated ? "Assembly" : "Isolate"}</span>
              </button>
            )}

            {onToggleExploded && (
              <button
                onClick={onToggleExploded}
                className={`flex-1 py-1 px-2 rounded text-[11px] font-medium transition-colors flex items-center justify-center gap-1 border ${
                  isExploded
                    ? "bg-amber-warm/20 text-amber-warm border-amber-warm/40 font-semibold"
                    : "bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary border-border"
                }`}
                title="Toggle Exploded Assembly View"
              >
                <Layers className="w-3 h-3" />
                <span>{isExploded ? "Collapse" : "Explode"}</span>
              </button>
            )}

            <button
              onClick={() => {
                const s = useElevatorStore.getState();
                generateRcaPdf({
                  assetId: s.assetId,
                  model: s.model,
                  activeFault: s.activeFault,
                  diagnostic: s.diagnostic,
                  motion: s.motion,
                  sensors: s.sensors,
                  maintenance: s.maintenance,
                  session: s.maintenanceSession,
                });
              }}
              className="py-1 px-2.5 rounded text-[11px] font-medium bg-surface hover:bg-surface-hover text-sage transition-colors flex items-center gap-1 border border-border"
              title="Download RCA Engineering Report (PDF)"
            >
              <Download className="w-3 h-3" />
              <span>PDF</span>
            </button>

            <button
              onClick={() => navigate("/investigation")}
              className="py-1 px-2.5 rounded text-[11px] font-medium bg-surface hover:bg-surface-hover text-text-primary transition-colors flex items-center gap-1 border border-border"
              title="Open full Diagnostic RCA investigation"
            >
              <ExternalLink className="w-3 h-3 text-sage" />
              <span>RCA</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

