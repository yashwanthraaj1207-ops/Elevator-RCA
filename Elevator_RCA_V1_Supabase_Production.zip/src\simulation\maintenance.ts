// src/simulation/maintenance.ts
/**
 * Maintenance & Repair Verification State Machine for ELEVATOR-RCA.
 *
 * Implements the 10-state controlled maintenance workflow:
 * fault_detected -> investigation_open -> repair_in_progress -> awaiting_verification
 * -> verification_failed OR repair_verified -> archival_pending -> archived
 * -> cleanup_eligible -> cleanup_completed
 *
 * Enforces explicit transition guards, retest evaluation, and auditable logging.
 */

export type MaintenanceState =
  | "fault_detected"
  | "investigation_open"
  | "repair_in_progress"
  | "awaiting_verification"
  | "verification_failed"
  | "repair_verified"
  | "archival_pending"
  | "archived"
  | "cleanup_eligible"
  | "cleanup_completed";

export interface MaintenanceAuditEntry {
  id: string;
  timestamp: string;
  fromState: MaintenanceState;
  toState: MaintenanceState;
  actor: string;
  action: string;
  evidence: string;
}

export interface VerificationCriteria {
  channelName: string;
  targetMax: number;
  measuredPostRepair: number;
  unit: string;
  passed: boolean;
}

export interface MaintenanceWorkOrder {
  id: string;
  incidentId: string;
  createdAt: string;
  subsystem: string;
  title: string;
  description: string;
  status: "open" | "in_progress" | "awaiting_verification" | "completed" | "cancelled";
  priority: "CRITICAL" | "HIGH" | "MEDIUM" | "ROUTINE";
  assignedTechnician: string;
  inspectionSteps: Array<{ id: string; step: string; completed: boolean; completedAt?: string }>;
  partsReplaced: string[];
  technicianNotes: string;
  beforeValues: Record<string, string>;
  afterValues: Record<string, string>;
  targetThresholds: Record<string, string>;
  verificationPassed?: boolean;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface MaintenanceWorkflow {
  state: MaintenanceState;
  incidentId: string;
  subsystem: string;
  issueDescription: string;
  assignedTechnician: string;
  repairActionDescription?: string;
  verificationEvidence?: VerificationCriteria[];
  archivedAt?: string;
  backupVerifiedAt?: string;
  cleanedUpAt?: string;
  auditTrail: MaintenanceAuditEntry[];
  workOrders: MaintenanceWorkOrder[];
  activeWorkOrderId?: string;
  activeWorkOrder?: MaintenanceWorkOrder;
}

export const INITIAL_MAINTENANCE_WORKFLOW: MaintenanceWorkflow = {
  state: "repair_verified",
  incidentId: "INC-2026-INIT-00",
  subsystem: "Entire System",
  issueDescription: "Routine operational baseline inspection.",
  assignedTechnician: "N. Topson (Lead PE)",
  repairActionDescription: "Baseline calibration confirmed.",
  auditTrail: [
    {
      id: "AUD-001",
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      fromState: "awaiting_verification",
      toState: "repair_verified",
      actor: "N. Topson (Lead PE)",
      action: "Initial system commissioning verified",
      evidence: "All 8 sensor telemetry channels within OEM baseline envelope.",
    },
  ],
  workOrders: [
    {
      id: "WO-2026-001",
      incidentId: "INC-2026-INIT-00",
      createdAt: new Date().toISOString().replace("T", " ").substring(0, 19),
      subsystem: "Entire System",
      title: "Pre-Commissioning Subsystem Baseline Health Check",
      description: "Verify baseline vibration (<0.05g), motor current (12.5A), and brake holding.",
      status: "completed",
      priority: "ROUTINE",
      assignedTechnician: "N. Topson (Lead PE)",
      inspectionSteps: [
        { id: "S1", step: "Verify shaft frame structural anchors and pit buffer clearances", completed: true },
        { id: "S2", step: "Inspect main traction sheave grooves and hoist rope tension", completed: true },
        { id: "S3", step: "Verify door interlock contacts and optical safety curtain", completed: true },
        { id: "S4", step: "Execute static brake torque holding verification", completed: true },
      ],
      partsReplaced: ["Lubricant seals (OEM #SKF-2214)"],
      technicianNotes: "All subsystem components calibrated to EN 81-20 baseline limits.",
      beforeValues: { "Vibration": "0.04 g", "Motor Temp": "42.0 °C" },
      afterValues: { "Vibration": "0.04 g", "Motor Temp": "42.0 °C" },
      targetThresholds: { "Vibration": "≤ 0.09 g", "Motor Temp": "≤ 55.0 °C" },
      verificationPassed: true,
      verifiedAt: new Date().toISOString().replace("T", " ").substring(0, 19),
      verifiedBy: "N. Topson (Lead PE)",
    },
  ],
  activeWorkOrderId: "WO-2026-001",
};

/**
 * Valid state transition matrix
 */
const ALLOWED_TRANSITIONS: Record<MaintenanceState, MaintenanceState[]> = {
  fault_detected: ["investigation_open"],
  investigation_open: ["repair_in_progress"],
  repair_in_progress: ["awaiting_verification"],
  awaiting_verification: ["repair_verified", "verification_failed"],
  verification_failed: ["repair_in_progress"], // Retest loop
  repair_verified: ["archival_pending", "fault_detected"],
  archival_pending: ["archived"],
  archived: ["cleanup_eligible"],
  cleanup_eligible: ["cleanup_completed"],
  cleanup_completed: ["fault_detected", "repair_verified"],
};

export class MaintenanceStateMachine {
  private workflow: MaintenanceWorkflow;

  constructor(initial = INITIAL_MAINTENANCE_WORKFLOW) {
    this.workflow = {
      ...initial,
      auditTrail: [...initial.auditTrail],
      workOrders: initial.workOrders ? [...initial.workOrders] : [],
    };
  }

  getWorkflow(): MaintenanceWorkflow {
    return {
      ...this.workflow,
      auditTrail: [...this.workflow.auditTrail],
      workOrders: [...this.workflow.workOrders],
      activeWorkOrder: this.getActiveWorkOrder(),
    };
  }

  getWorkOrders(): MaintenanceWorkOrder[] {
    return [...this.workflow.workOrders];
  }

  getActiveWorkOrder(): MaintenanceWorkOrder | undefined {
    return (
      this.workflow.workOrders.find((w) => w.id === this.workflow.activeWorkOrderId) ||
      this.workflow.workOrders[0]
    );
  }

  toggleWorkOrderStep(stepId: string, completed?: boolean): boolean {
    const activeWo = this.getActiveWorkOrder();
    if (!activeWo) return false;
    const step = activeWo.inspectionSteps.find((s) => s.id === stepId);
    if (!step) return false;
    step.completed = completed !== undefined ? completed : !step.completed;
    if (step.completed) {
      step.completedAt = new Date().toISOString().replace("T", " ").substring(0, 19);
    }
    return true;
  }

  updateActiveWorkOrder(updates: Partial<MaintenanceWorkOrder>): void {
    const activeWo = this.getActiveWorkOrder();
    if (!activeWo) return;
    Object.assign(activeWo, updates);
  }

  logCustomAudit(actor: string, action: string, evidence: string) {
    this.recordAudit(this.workflow.state, this.workflow.state, actor, action, evidence);
  }

  /**
   * Triggers a new incident when a fault is detected
   */
  reportFault(subsystem: string, issue: string, actor = "Telemetry Ingestion Engine"): boolean {
    const fromState = this.workflow.state;
    const toState: MaintenanceState = "fault_detected";

    this.workflow.state = toState;
    this.workflow.incidentId = `INC-${Date.now().toString().slice(-6)}`;
    this.workflow.subsystem = subsystem;
    this.workflow.issueDescription = issue;
    this.workflow.verificationEvidence = undefined;

    // Automatically create a formal maintenance work order linked to this incident
    const woId = `WO-${Date.now().toString().slice(-6)}`;
    const newWo: MaintenanceWorkOrder = {
      id: woId,
      incidentId: this.workflow.incidentId,
      createdAt: new Date().toISOString().replace("T", " ").substring(0, 19),
      subsystem,
      title: `Corrective Work Order: ${subsystem} Anomaly Remediation`,
      description: issue,
      status: "open",
      priority: "CRITICAL",
      assignedTechnician: this.workflow.assignedTechnician || "Unassigned (Awaiting Dispatch)",
      inspectionSteps: this.generateDefaultChecklist(subsystem),
      partsReplaced: [],
      technicianNotes: "Awaiting physical technician inspection and preliminary lock-out tag-out.",
      beforeValues: {},
      afterValues: {},
      targetThresholds: {},
    };
    this.workflow.workOrders.unshift(newWo);
    this.workflow.activeWorkOrderId = woId;

    this.recordAudit(fromState, toState, actor, "Anomaly Tripped Alarm", issue);
    return true;
  }

  /**
   * Opens investigation
   */
  openInvestigation(actor = "Diagnostic RCA Pipeline"): boolean {
    const activeWo = this.getActiveWorkOrder();
    if (activeWo && activeWo.status === "open") {
      activeWo.status = "in_progress";
    }
    return this.transitionTo("investigation_open", actor, "Root cause analysis opened", "Hypothesis ranking generated.");
  }

  /**
   * Dispatches technician and starts repair
   */
  startRepair(technician: string, actionDescription: string): boolean {
    if (this.workflow.state !== "investigation_open" && this.workflow.state !== "verification_failed") {
      throw new Error(`Cannot start repair from state "${this.workflow.state}". Investigation must be open or verification failed.`);
    }

    this.workflow.assignedTechnician = technician;
    this.workflow.repairActionDescription = actionDescription;

    const activeWo = this.getActiveWorkOrder();
    if (activeWo) {
      activeWo.status = "in_progress";
      activeWo.assignedTechnician = technician;
      activeWo.technicianNotes = actionDescription;
    }

    return this.transitionTo("repair_in_progress", technician, "Repair work started", actionDescription);
  }

  /**
   * Completes physical work and submits for retest verification
   */
  submitForVerification(technician: string): boolean {
    const activeWo = this.getActiveWorkOrder();
    if (activeWo) {
      activeWo.status = "awaiting_verification";
    }
    return this.transitionTo("awaiting_verification", technician, "Physical repair completed", "Ready for sensor retest.");
  }

  /**
   * Executes synthetic retest verification.
   * Compares post-repair readings with target criteria.
   * Never marks successful unless criteria are genuinely met!
   */
  verifyRepair(
    technician: string,
    criteria: VerificationCriteria[],
    forceSimulateFailure = false
  ): { passed: boolean; state: MaintenanceState } {
    if (this.workflow.state !== "awaiting_verification") {
      throw new Error(`Cannot verify repair in state "${this.workflow.state}". Must be awaiting_verification.`);
    }

    const allPassed = !forceSimulateFailure && criteria.every((c) => c.passed);
    const toState: MaintenanceState = allPassed ? "repair_verified" : "verification_failed";
    const fromState = this.workflow.state;

    this.workflow.state = toState;
    this.workflow.verificationEvidence = criteria;

    const evidenceText = criteria
      .map((c) => `${c.channelName}: ${c.measuredPostRepair}${c.unit} (Target: ≤${c.targetMax}${c.unit}) -> ${c.passed ? "PASS" : "FAIL"}`)
      .join(" | ");

    const activeWo = this.getActiveWorkOrder();
    if (activeWo) {
      activeWo.verificationPassed = allPassed;
      activeWo.verifiedAt = new Date().toISOString().replace("T", " ").substring(0, 19);
      activeWo.verifiedBy = technician;
      activeWo.status = allPassed ? "completed" : "in_progress";
      for (const crit of criteria) {
        activeWo.afterValues[crit.channelName] = `${crit.measuredPostRepair} ${crit.unit}`;
        activeWo.targetThresholds[crit.channelName] = `≤ ${crit.targetMax} ${crit.unit}`;
      }
    }

    this.recordAudit(
      fromState,
      toState,
      technician,
      allPassed ? "Repair retest passed criteria" : "Repair retest failed criteria",
      forceSimulateFailure ? "Simulated verification failure for testing" : evidenceText
    );

    return { passed: allPassed, state: toState };
  }

  private generateDefaultChecklist(subsystem: string) {
    const s = subsystem.toLowerCase();
    if (s.includes("bearing")) {
      return [
        { id: "S1", step: "Lock out and tag out (LOTO) traction machine main disconnect", completed: false },
        { id: "S2", step: "Acoustically probe spherical roller bearing housing for spalling resonance", completed: false },
        { id: "S3", step: "Flush contaminated lubricant and renew with OEM synthetic grease", completed: false },
        { id: "S4", step: "Torque bearing pillow block bolts to OEM 145 Nm specification", completed: false },
      ];
    }
    if (s.includes("door")) {
      return [
        { id: "S1", step: "Disable landing calls and secure elevator at floor level", completed: false },
        { id: "S2", step: "Clean car and landing door sill guide grooves of foreign obstructions", completed: false },
        { id: "S3", step: "Inspect optical safety curtain beam alignment and sensitive edge switches", completed: false },
        { id: "S4", step: "Cycle door operator manually to test belt tension and interlock latching", completed: false },
      ];
    }
    if (s.includes("motor")) {
      return [
        { id: "S1", step: "LOTO main drive inverter power supply", completed: false },
        { id: "S2", step: "Measure three-phase stator winding insulation resistance (Megger test >100 MΩ)", completed: false },
        { id: "S3", step: "Clear ventilation duct blockage and inspect forced-air cooling fan", completed: false },
        { id: "S4", step: "Verify PT100 thermal sensor output matches actual stator temperature", completed: false },
      ];
    }
    if (s.includes("brake")) {
      return [
        { id: "S1", step: "Place car on safety gear / counterweight prop before brake service", completed: false },
        { id: "S2", step: "Inspect brake lining thickness (minimum 4.0mm wear threshold)", completed: false },
        { id: "S3", step: "Measure solenoid plunger stroke clearance and air gap with feeler gauge", completed: false },
        { id: "S4", step: "Perform dynamic and static holding torque test at 125% rated load", completed: false },
      ];
    }
    return [
      { id: "S1", step: "Execute physical visual inspection on target assembly", completed: false },
      { id: "S2", step: "Verify mechanical fastenings and alignment tolerances", completed: false },
      { id: "S3", step: "Inspect telemetry sensor wiring harness and sensor mounting rigidity", completed: false },
      { id: "S4", step: "Perform functional movement retest under maintenance speed", completed: false },
    ];
  }

  /**
   * Archival & Backup Gatekeepers (Section 7)
   */
  requestArchival(actor = "Records System"): boolean {
    if (this.workflow.state !== "repair_verified") {
      throw new Error(`Archival prerequisite violated: Incident must be "repair_verified" before archival. Current: ${this.workflow.state}`);
    }
    return this.transitionTo("archival_pending", actor, "Archival package compiled", "Awaiting immutable cold archive confirmation.");
  }

  confirmArchival(actor = "Compliance Daemon"): boolean {
    if (this.workflow.state !== "archival_pending") {
      throw new Error(`Cannot confirm archival in state: ${this.workflow.state}`);
    }
    this.workflow.archivedAt = new Date().toISOString();
    return this.transitionTo("archived", actor, "Archival package sealed", "Stored in ISO 27001 diagnostic vault.");
  }

  verifyBackup(actor = "Backup Verifier Service"): boolean {
    if (this.workflow.state !== "archived") {
      throw new Error(`Backup prerequisite violated: Must be "archived" before backup verification.`);
    }
    this.workflow.backupVerifiedAt = new Date().toISOString();
    return this.transitionTo("cleanup_eligible", actor, "Independent backup verified", "SHA-256 hash verified against offsite replica.");
  }

  /**
   * Raw Telemetry Log Cleanup:
   * STRICTLY REJECTS deletion unless:
   * 1. Repair is verified
   * 2. Archival is sealed
   * 3. Independent backup is verified
   */
  executeRawLogCleanup(actor = "Storage Purge Job"): { success: boolean; message: string } {
    if (this.workflow.state !== "cleanup_eligible") {
      const reason = `Cleanup REJECTED: Prerequisites unsatisfied. State must be "cleanup_eligible" (Current: "${this.workflow.state}"). Requirements: Repair Verified + Archival Confirmed + Backup Verified.`;
      this.recordAudit(this.workflow.state, this.workflow.state, actor, "Cleanup Request Rejected", reason);
      return { success: false, message: reason };
    }

    const fromState = this.workflow.state;
    const toState: MaintenanceState = "cleanup_completed";
    this.workflow.state = toState;
    this.workflow.cleanedUpAt = new Date().toISOString();

    const note = "Raw 1Hz telemetry purged. Compact diagnostic summary and signed RCA audit package retained.";
    this.recordAudit(fromState, toState, actor, "Raw telemetry cleanup completed", note);
    return { success: true, message: note };
  }

  private transitionTo(toState: MaintenanceState, actor: string, action: string, evidence: string): boolean {
    const fromState = this.workflow.state;
    const allowed = ALLOWED_TRANSITIONS[fromState] || [];
    if (!allowed.includes(toState)) {
      throw new Error(`Invalid state transition: Cannot transition from "${fromState}" to "${toState}". Allowed: [${allowed.join(", ")}]`);
    }

    this.workflow.state = toState;
    this.recordAudit(fromState, toState, actor, action, evidence);
    return true;
  }

  private recordAudit(from: MaintenanceState, to: MaintenanceState, actor: string, action: string, evidence: string) {
    this.workflow.auditTrail.unshift({
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      fromState: from,
      toState: to,
      actor,
      action,
      evidence,
    });
  }
}

