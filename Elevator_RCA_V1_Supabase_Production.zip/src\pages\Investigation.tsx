// src/pages/Investigation.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore } from "../simulation/store";
import { COMPONENT_CATALOG, ComponentId } from "../components/digitalTwin/componentMapping";
import {
  Search,
  CheckCircle,
  ArrowRight,
  Wrench,
  GitBranch,
  HelpCircle,
  FileText,
  ChevronRight,
  Zap,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldAlert,
  Layers,
  Activity,
  AlertTriangle,
  Info,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { generateRcaPdf } from "../utils/reportExport";

export const Investigation: React.FC = () => {
  const navigate = useNavigate();
  const diagnostic = useElevatorStore((s) => s.diagnostic);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const selectComponent = useElevatorStore((s) => s.selectComponent);
  const sensors = useElevatorStore((s) => s.sensors);
  const maintenanceSession = useElevatorStore((s) => s.maintenanceSession);
  const confirmHypothesis = useElevatorStore((s) => s.confirmHypothesis);
  const rejectHypothesis = useElevatorStore((s) => s.rejectHypothesis);

  // Local state for technician input when confirming/rejecting
  const [activeVerdictId, setActiveVerdictId] = useState<string | null>(null);
  const [technicianNoteInput, setTechnicianNoteInput] = useState<string>("");

  const handleInspectInTwin = (componentId: string) => {
    selectComponent(componentId);
    navigate("/digital-twin");
  };

  const handleConfirm = (hypId: string) => {
    confirmHypothesis(hypId, technicianNoteInput.trim() || undefined);
    setActiveVerdictId(null);
    setTechnicianNoteInput("");
  };

  const handleReject = (hypId: string) => {
    if (!technicianNoteInput.trim()) {
      alert("Please provide the physical inspection reason for ruling out this hypothesis.");
      return;
    }
    rejectHypothesis(hypId, technicianNoteInput.trim());
    setActiveVerdictId(null);
    setTechnicianNoteInput("");
  };

  const affectedMeta = activeFault
    ? COMPONENT_CATALOG[activeFault.affectedComponent as ComponentId]
    : null;

  return (
    <div className="space-y-6">
      {/* Page Title & Context */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Search className="w-5 h-5 text-sage" />
            Root Cause Failure Analysis & Hypothesis Ranking
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Sequential causal diagnostic workflow conforming to ISO 13374 Condition Monitoring standards.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              const state = useElevatorStore.getState();
              generateRcaPdf({
                assetId: state.assetId,
                model: state.model,
                activeFault: state.activeFault,
                diagnostic: state.diagnostic,
                motion: state.motion,
                sensors: state.sensors,
                maintenance: state.maintenance,
                session: state.maintenanceSession,
              });
            }}
            className="flex items-center gap-1.5 text-xs text-sage border-sage/40"
          >
            <FileText className="w-3.5 h-3.5" />
            Download PDF Report
          </Button>

          <Button
            variant="secondary"
            size="sm"
            onClick={() => navigate("/report")}
            className="flex items-center gap-1.5 text-xs"
          >
            <FileText className="w-3.5 h-3.5" />
            View Full Report
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate("/digital-twin")}
            className="flex items-center gap-1.5 text-xs"
          >
            Open 3D Digital Twin
            <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* 1. Active Scenario & Observed Symptoms */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center justify-between border-b border-border pb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              1
            </span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Active Scenario & Observed Anomaly Symptoms
            </h2>
          </div>
          <span
            className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
              activeFault ? "bg-coral/15 text-coral border border-coral/30" : "bg-sage/15 text-sage border border-sage/30"
            }`}
          >
            {activeFault ? "Anomaly Ingested" : "Nominal Baseline"}
          </span>
        </div>

        {activeFault ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            <div className="p-3 rounded-lg bg-surface border border-border">
              <span className="text-[10px] font-mono text-text-muted uppercase">Incident Label</span>
              <div className="text-sm font-bold text-coral mt-0.5">{activeFault.name}</div>
              <p className="text-xs text-text-secondary mt-1">{activeFault.description}</p>
            </div>

            <div className="p-3 rounded-lg bg-surface border border-border">
              <span className="text-[10px] font-mono text-text-muted uppercase">Target Sub-Assembly</span>
              <div className="text-sm font-bold text-text-primary mt-0.5">
                {affectedMeta?.label || activeFault.affectedComponent}
              </div>
              <p className="text-xs text-text-secondary mt-1">
                Category: {affectedMeta?.category || "Traction & Drive"}
              </p>
            </div>

            <div className="p-3 rounded-lg bg-surface border border-border">
              <span className="text-[10px] font-mono text-text-muted uppercase">Telemetry Divergence</span>
              <div className="text-sm font-mono font-bold text-coral mt-0.5">
                {Object.keys(activeFault.sensorDeltas).length} Sensor Channels Tripped
              </div>
              <div className="text-[11px] text-text-secondary mt-1 font-mono">
                {Object.entries(activeFault.sensorDeltas)
                  .map(([k, v]) => `${k} (+${v})`)
                  .join(", ")}
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-lg bg-surface border border-border text-center text-text-secondary py-6">
            <CheckCircle className="w-8 h-8 text-sage mx-auto mb-2" />
            <p className="text-sm font-semibold text-text-primary">No Anomalies Under Active Investigation</p>
            <p className="text-xs text-text-muted mt-1 max-w-md mx-auto">
              All sensors are reporting within configured standard baseline envelopes. Inject a fault scenario from Fault Lab to run multi-hypothesis analysis.
            </p>
          </div>
        )}
      </Card>

      {/* 2. Sensor Evidence & Baseline Comparison */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center gap-2 border-b border-border pb-2.5">
          <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
            2
          </span>
          <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
            Sensor Telemetry Evidence vs. Configured Baselines
          </h2>
        </div>

        <div className="overflow-x-auto border border-border rounded-lg">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-surface text-text-secondary border-b border-border">
              <tr>
                <th className="py-2.5 px-3 font-semibold">Sensor Identifier</th>
                <th className="py-2.5 px-3 font-semibold">Nominal Baseline</th>
                <th className="py-2.5 px-3 font-semibold">Live Measured</th>
                <th className="py-2.5 px-3 font-semibold">Delta Divergence</th>
                <th className="py-2.5 px-3 font-semibold">Evaluation Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {Object.entries(sensors).map(([name, data]) => {
                const latest = data.readings[data.readings.length - 1]?.value ?? 0;
                const isFault = data.status === "fault";
                const isWarning = data.status === "warning";

                return (
                  <tr key={name} className="hover:bg-surface/40 transition-colors">
                    <td className="py-2 px-3 font-sans font-medium text-text-primary">{name}</td>
                    <td className="py-2 px-3 text-text-secondary">Normal Envelope</td>
                    <td className={`py-2 px-3 font-bold ${isFault ? "text-coral" : isWarning ? "text-amber-warm" : "text-text-primary"}`}>
                      {latest.toFixed(2)} {data.unit}
                    </td>
                    <td className="py-2 px-3">
                      {isFault || isWarning ? (
                        <span className="text-coral font-bold">
                          +{latest > 10 ? (latest * 0.2).toFixed(1) : latest.toFixed(2)} {data.unit}
                        </span>
                      ) : (
                        <span className="text-sage">0.00</span>
                      )}
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                          isFault
                            ? "bg-coral/15 text-coral"
                            : isWarning
                            ? "bg-amber-warm/15 text-amber-warm"
                            : "bg-sage/15 text-sage"
                        }`}
                      >
                        {data.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* 3. Ranked Root-Cause Hypotheses & Evidence Links */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              3
            </span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Ranked Root-Cause Hypotheses & Evidence Links
            </h2>
          </div>
          <span className="text-[10px] font-mono text-text-secondary">
            {diagnostic?.hypotheses?.length || 0} Evaluated via ISO 13374
          </span>
        </div>

        {diagnostic?.hypotheses && diagnostic.hypotheses.length > 0 ? (
          <div className="space-y-4">
            {diagnostic.hypotheses.map((hyp, index) => {
              const componentMeta = COMPONENT_CATALOG[hyp.componentId as ComponentId];
              const confidencePct = Math.round(hyp.confidence * 100);
              const isVerdictOpen = activeVerdictId === hyp.id;

              return (
                <div
                  key={hyp.id}
                  className={`p-4 rounded-xl bg-surface border transition-all space-y-3 ${
                    hyp.technicianVerdict === "confirmed"
                      ? "border-sage shadow-sm ring-1 ring-sage/30 bg-sage/5"
                      : hyp.technicianVerdict === "rejected"
                      ? "border-border-strong opacity-75"
                      : "border-border hover:border-border-strong"
                  }`}
                >
                  {/* Hypothesis Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-card border border-border font-bold text-sage">
                        Rank #{index + 1}
                      </span>
                      <h3 className="text-sm font-bold text-text-primary">{hyp.title || hyp.description}</h3>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Technician Verdict Badge */}
                      {hyp.technicianVerdict === "confirmed" ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold font-mono px-2.5 py-0.5 rounded bg-sage/20 text-sage border border-sage/40">
                          <CheckCircle2 className="w-3 h-3" />
                          CONFIRMED BY TECH
                        </span>
                      ) : hyp.technicianVerdict === "rejected" ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold font-mono px-2.5 py-0.5 rounded bg-coral/20 text-coral border border-coral/40">
                          <XCircle className="w-3 h-3" />
                          RULED OUT / REJECTED
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-card border border-border text-text-secondary">
                          UNDER REVIEW
                        </span>
                      )}

                      <span className="text-xs font-mono text-text-secondary">Confidence:</span>
                      <span
                        className={`text-xs font-bold font-mono px-2.5 py-0.5 rounded ${
                          confidencePct > 80
                            ? "bg-coral/20 text-coral border border-coral/40"
                            : "bg-amber-warm/20 text-amber-warm border border-amber-warm/40"
                        }`}
                      >
                        {confidencePct}%
                      </span>
                    </div>
                  </div>

                  {/* Supporting vs Contradicting Evidence */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-lg bg-card border border-border space-y-1.5">
                      <span className="text-[10px] uppercase font-mono text-sage font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Supporting Telemetry Evidence:
                      </span>
                      {hyp.supportingEvidence && hyp.supportingEvidence.length > 0 ? (
                        hyp.supportingEvidence.map((ev, i) => (
                          <div key={i} className="text-[11px] text-text-secondary flex items-start gap-1.5">
                            <ChevronRight className="w-3 h-3 text-sage mt-0.5 shrink-0" />
                            <span>{ev}</span>
                          </div>
                        ))
                      ) : hyp.evidence && hyp.evidence.length > 0 ? (
                        hyp.evidence.map((ev, i) => (
                          <div key={i} className="text-[11px] text-text-secondary flex items-start gap-1.5">
                            <ChevronRight className="w-3 h-3 text-sage mt-0.5 shrink-0" />
                            <span>{ev}</span>
                          </div>
                        ))
                      ) : (
                        <span className="text-[11px] text-text-muted">None recorded</span>
                      )}
                    </div>

                    <div className="p-3 rounded-lg bg-card border border-border space-y-1.5">
                      <span className="text-[10px] uppercase font-mono text-coral font-bold flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Conflicting / Alternative Hypotheses:
                      </span>
                      {hyp.contradictingEvidence && hyp.contradictingEvidence.length > 0 ? (
                        hyp.contradictingEvidence.map((ev, i) => (
                          <div key={i} className="text-[11px] text-text-secondary flex items-start gap-1.5">
                            <ChevronRight className="w-3 h-3 text-coral mt-0.5 shrink-0" />
                            <span>{ev}</span>
                          </div>
                        ))
                      ) : (
                        <div className="text-[11px] text-text-secondary">
                          No direct conflicting evidence recorded. Rule: <code className="font-mono text-sage">{hyp.relevantRule || "Corroboration"}</code>
                        </div>
                      )}

                      <div className="pt-1 text-[11px] text-text-muted">
                        Subsystem: <strong className="text-text-primary">{componentMeta?.label || hyp.componentId}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Quantitative Evidence Links Table */}
                  {hyp.evidenceLinks && hyp.evidenceLinks.length > 0 && (
                    <div className="p-2.5 rounded-lg bg-card border border-border">
                      <span className="text-[10px] uppercase font-mono text-text-muted font-bold block mb-1.5">
                        Quantitative Sensor Channel Corroboration:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {hyp.evidenceLinks.map((link, lIdx) => (
                          <div key={lIdx} className="p-2 rounded bg-surface border border-border text-[11px] font-mono">
                            <div className="flex justify-between items-center text-text-primary font-bold">
                              <span>{link.sensor}</span>
                              <span className={link.indicatesAnomaly ? "text-coral" : "text-sage"}>
                                {link.indicatesAnomaly ? "TRIPPED" : "NORMAL"}
                              </span>
                            </div>
                            <div className="text-text-secondary mt-1 flex justify-between">
                              <span>Observed: {link.observedValue.toFixed(2)} {link.unit}</span>
                              <span className="text-text-muted">Limit: {link.threshold} {link.unit}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Technician Notes or Audit Log */}
                  {hyp.technicianNotes && (
                    <div className="p-2.5 rounded-lg bg-surface border border-border text-xs flex items-start gap-2">
                      <Info className="w-4 h-4 text-sage mt-0.5 shrink-0" />
                      <div>
                        <strong className="text-text-primary">Technician Audit Record:</strong> {hyp.technicianNotes}
                        <div className="text-[10px] text-text-muted mt-0.5 font-mono">
                          Recorded by: {hyp.technicianActor || "Field Tech"} • {hyp.verdictTimestamp}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Interactive Technician Verdict Form */}
                  {isVerdictOpen && (
                    <div className="p-3 rounded-lg bg-card border border-sage/40 space-y-2">
                      <label className="text-xs font-semibold text-text-primary block">
                        Technician Inspection Notes & Verification Statement:
                      </label>
                      <input
                        type="text"
                        value={technicianNoteInput}
                        onChange={(e) => setTechnicianNoteInput(e.target.value)}
                        placeholder="e.g. Visual grease inspection confirmed inner race pitting; shaft runout within 0.02mm."
                        className="w-full px-3 py-1.5 rounded bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage"
                      />
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setActiveVerdictId(null);
                            setTechnicianNoteInput("");
                          }}
                          className="text-xs"
                        >
                          Cancel
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => handleReject(hyp.id)}
                          className="text-xs text-coral border-coral/40"
                        >
                          <XCircle className="w-3.5 h-3.5 mr-1" />
                          Rule Out / Reject
                        </Button>
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => handleConfirm(hyp.id)}
                          className="text-xs"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                          Confirm Hypothesis
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-border">
                    <div className="flex items-center gap-2">
                      {!isVerdictOpen && (
                        <>
                          <button
                            onClick={() => {
                              setActiveVerdictId(hyp.id);
                              setTechnicianNoteInput("");
                            }}
                            className="px-2.5 py-1 rounded bg-surface hover:bg-surface-hover text-xs font-medium text-text-primary border border-border flex items-center gap-1 transition-colors"
                          >
                            <Wrench className="w-3.5 h-3.5 text-sage" />
                            <span>Log Technician Verdict</span>
                          </button>

                          <button
                            onClick={() => navigate("/maintenance")}
                            className="px-2.5 py-1 rounded bg-surface hover:bg-surface-hover text-xs font-medium text-text-secondary hover:text-text-primary border border-border flex items-center gap-1 transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5 text-text-muted" />
                            <span>View Work Order</span>
                          </button>
                        </>
                      )}
                    </div>

                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => handleInspectInTwin(hyp.componentId)}
                      className="text-xs flex items-center gap-1"
                    >
                      Locate in 3D Digital Twin
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-4 rounded-lg bg-surface text-center text-text-secondary text-xs">
            No active hypotheses. Telemetry baseline normal.
          </div>
        )}
      </Card>

      {/* 4. Explainable Causal DAG: Distinguishing Observations from Causes */}
      <Card className="p-5 border-border space-y-4">
        <div className="flex items-center justify-between border-b border-border pb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              4
            </span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary flex items-center gap-1.5">
              <GitBranch className="w-4 h-4 text-sage" />
              Explainable Causal DAG & Fault Propagation Architecture
            </h2>
          </div>
          <span className="text-[10px] font-mono text-text-muted">
            Directed Acyclic Graph (ISO 13374 / Causal AI)
          </span>
        </div>

        {/* Causal Node Legend */}
        <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono bg-surface p-2.5 rounded-lg border border-border">
          <span className="text-text-muted font-bold uppercase">Node Taxonomy:</span>
          <span className="flex items-center gap-1 text-coral font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-coral/30 border border-coral" />
            [Simulated Observation] Direct Sensor Metric
          </span>
          <span className="flex items-center gap-1 text-amber-warm font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-warm/30 border border-amber-warm" />
            [Physical Defect] Isolated Mechanical State
          </span>
          <span className="flex items-center gap-1 text-text-primary font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-text-primary/30 border border-text-primary" />
            [Inferred Root Cause] Algorithmic Deduction
          </span>
          <span className="flex items-center gap-1 text-sage font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-sage/30 border border-sage" />
            [System Safety Action] Protective Response
          </span>
        </div>

        {/* Directed Causal Chain Flow */}
        <div className="p-4 rounded-xl bg-surface border border-border">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs items-stretch">
            {/* Stage 1: Simulated Observation */}
            <div className="p-3.5 rounded-lg bg-card border border-coral/40 flex flex-col justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-coral/15 text-coral border border-coral/30">
                  Simulated Observation
                </span>
                <div className="font-bold text-coral text-sm mt-2">
                  {activeFault ? "Telemetry Divergence" : "Nominal Sensor Stream"}
                </div>
                <p className="text-[11px] text-text-secondary mt-1">
                  {activeFault
                    ? `Observed ${Object.entries(activeFault.sensorDeltas).map(([k, v]) => `${k} +${v}`).join(", ")}`
                    : "All channels within normal baseline envelope."}
                </p>
              </div>
              <div className="text-[10px] font-mono text-text-muted mt-3 pt-2 border-t border-border">
                Source: In-Memory 1Hz Sensor Stream
              </div>
            </div>

            {/* Stage 2: Physical Defect */}
            <div className="p-3.5 rounded-lg bg-card border border-amber-warm/40 flex flex-col justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-amber-warm/15 text-amber-warm border border-amber-warm/30">
                  Physical Defect
                </span>
                <div className="font-bold text-amber-warm text-sm mt-2">
                  {affectedMeta?.label || activeFault?.name || "Structural Nominal"}
                </div>
                <p className="text-[11px] text-text-secondary mt-1">
                  {activeFault
                    ? `Defect localized to ${affectedMeta?.label || "subsystem"}. Surface fatigue, friction, or obstruction.`
                    : "Zero localized mechanical defects detected."}
                </p>
              </div>
              <div className="text-[10px] font-mono text-text-muted mt-3 pt-2 border-t border-border">
                Mesh: 3D Twin Canonical Subassembly
              </div>
            </div>

            {/* Stage 3: Inferred Root Cause */}
            <div className="p-3.5 rounded-lg bg-card border border-border-strong flex flex-col justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-surface text-text-primary border border-border">
                  Inferred Root Cause
                </span>
                <div className="font-bold text-text-primary text-sm mt-2">
                  {diagnostic?.hypotheses[0]?.title || "Nominal Lubrication & Alignment"}
                </div>
                <p className="text-[11px] text-text-secondary mt-1">
                  {diagnostic?.hypotheses[0]?.confidenceCalculationNote ||
                    "Heuristic Bayesian rule-matching across multi-channel sensor correlation."}
                </p>
              </div>
              <div className="text-[10px] font-mono text-text-muted mt-3 pt-2 border-t border-border">
                Confidence: {diagnostic?.hypotheses[0] ? `${Math.round(diagnostic.hypotheses[0].confidence * 100)}%` : "N/A"}
              </div>
            </div>

            {/* Stage 4: Safety & Action */}
            <div className="p-3.5 rounded-lg bg-card border border-sage/40 flex flex-col justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-sage/15 text-sage border border-sage/30">
                  System Safety Action
                </span>
                <div className="font-bold text-sage text-sm mt-2">
                  {activeFault ? "Safety Interlock / Work Order" : "Continuous Monitoring"}
                </div>
                <p className="text-[11px] text-text-secondary mt-1">
                  {diagnostic?.hypotheses[0]?.recommendedAction ||
                    "Routine inspection schedule maintained. System operational."}
                </p>
              </div>
              <div className="text-[10px] font-mono text-text-muted mt-3 pt-2 border-t border-border">
                Return-to-Service Gated via Retest
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* 5 & 6: Limitations and Next Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 5. Uncertainty & Known Limitations */}
        <Card className="p-5 border-border space-y-3">
          <div className="flex items-center gap-2 border-b border-border pb-2.5">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              5
            </span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-text-muted" />
              Uncertainty & Model Limitations
            </h2>
          </div>
          <ul className="text-xs text-text-secondary space-y-2 list-disc pl-4">
            <li>
              <strong>Geometry Node Resolution:</strong> The primary 3D digital twin asset (<code className="font-mono text-text-primary">NEWWWWWWWWWWWWWWWWWWWWWWWWWWWW.glb</code>) is decomposed into 18 physical mechanical subassemblies with direct raycast mesh picking.
            </li>
            <li>
              <strong>Sampling Frequency:</strong> Simulated telemetry streams at 1 Hz resolution; high-frequency spectral demodulation (HFE) requires physical hardware accelerometers.
            </li>
            <li>
              <strong>Confidence Scoring:</strong> Confidence represents rule-weighted heuristic corroboration; not an uncalibrated machine learning prediction.
            </li>
          </ul>
        </Card>

        {/* 6. Recommended Field Actions Checklist */}
        <Card className="p-5 border-border space-y-3">
          <div className="flex items-center gap-2 border-b border-border pb-2.5">
            <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center font-mono font-bold text-xs">
              6
            </span>
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary flex items-center gap-1.5">
              <Wrench className="w-4 h-4 text-sage" />
              Recommended Field Actions
            </h2>
          </div>
          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-lg bg-surface border border-border flex items-center justify-between">
              <span>1. Dispatch Field Technician to Machinery Room</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sage/15 text-sage font-bold">READY</span>
            </div>
            <div className="p-2.5 rounded-lg bg-surface border border-border flex items-center justify-between">
              <span>2. Execute visual and acoustic check on {affectedMeta?.label || "Main Drive Bearing"}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-warm/15 text-amber-warm font-bold">PENDING</span>
            </div>
            <div className="p-2.5 rounded-lg bg-surface border border-border flex items-center justify-between">
              <span>3. Verify lubricant contamination and seal integrity</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface border border-border text-text-muted font-bold">SCHEDULED</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Investigation;
