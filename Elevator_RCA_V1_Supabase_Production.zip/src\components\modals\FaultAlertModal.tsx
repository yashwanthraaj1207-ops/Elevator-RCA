// src/components/modals/FaultAlertModal.tsx
/**
 * Prominent Fault Alert & Broadcast Announcement Floating Window.
 *
 * Implements:
 * - Public & Facility Emergency Audio-Visual Announcement for Damage Detection.
 * - Multi-tone industrial elevator chime + synthesized voice safety announcement.
 * - Replay / Mute audio controls for operators and passengers.
 * - Displays affected component, tripped telemetry evidence, and shutdown status.
 * - Direct routing to Root Cause Analysis & Maintenance Console.
 */

import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useElevatorStore } from "../../simulation/store";
import { COMPONENT_CATALOG, ComponentId } from "../digitalTwin/componentMapping";
import {
  triggerDamageAnnouncement,
  stopAnnouncement,
} from "../../utils/audioAnnouncement";
import {
  Megaphone,
  Volume2,
  VolumeX,
  ShieldAlert,
  Wrench,
  X,
  ArrowRight,
  Search,
  Radio,
  AlertTriangle,
} from "lucide-react";

export const FaultAlertModal: React.FC = () => {
  const navigate = useNavigate();
  const activeFault = useElevatorStore((s) => s.activeFault);
  const faultAlertDismissed = useElevatorStore((s) => s.faultAlertDismissed);
  const dismissFaultAlert = useElevatorStore((s) => s.dismissFaultAlert);
  const sensors = useElevatorStore((s) => s.sensors);

  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const componentLabel = activeFault
    ? COMPONENT_CATALOG[activeFault.affectedComponent as ComponentId]?.label ||
      activeFault.affectedComponent.replace(/_/g, " ")
    : "Elevator Subsystem";

  const handlePlayAnnouncement = useCallback(async () => {
    if (!activeFault) return;
    setIsSpeaking(true);
    try {
      await triggerDamageAnnouncement(componentLabel, activeFault.name);
    } finally {
      setIsSpeaking(false);
    }
  }, [activeFault, componentLabel]);

  const handleStopAnnouncement = () => {
    stopAnnouncement();
    setIsSpeaking(false);
  };

  // Play announcement once when a new fault alert opens
  useEffect(() => {
    if (activeFault && !faultAlertDismissed) {
      handlePlayAnnouncement();
    }
    return () => {
      stopAnnouncement();
    };
  }, [activeFault?.id, faultAlertDismissed, handlePlayAnnouncement]);

  // Close with Escape key
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && activeFault && !faultAlertDismissed) {
        handleStopAnnouncement();
        dismissFaultAlert();
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [activeFault, faultAlertDismissed, dismissFaultAlert]);

  if (!activeFault || faultAlertDismissed) {
    return null;
  }

  const handleProceedToMaintenance = () => {
    handleStopAnnouncement();
    dismissFaultAlert();
    navigate("/maintenance");
  };

  const handleDismiss = () => {
    handleStopAnnouncement();
    dismissFaultAlert();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="fault-modal-title"
      aria-describedby="fault-modal-desc"
    >
      <div className="bg-card border-2 border-coral/70 rounded-2xl shadow-elevated w-full max-w-xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Floating Announcement Header Banner */}
        <div className="bg-coral/20 border-b border-coral/30 p-4.5 flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-coral/30 text-coral border border-coral/50 animate-pulse">
              <Megaphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-coral font-bold flex items-center gap-1 bg-coral/20 px-2 py-0.5 rounded border border-coral/40">
                  <Radio className="w-3 h-3 animate-ping" />
                  EMERGENCY SYSTEM ANNOUNCEMENT
                </span>
                <span className="text-[10px] font-mono text-text-muted">ELEV-001</span>
              </div>
              <h2 id="fault-modal-title" className="text-base font-bold text-text-primary tracking-tight mt-1">
                Damage Detected on {componentLabel}
              </h2>
            </div>
          </div>

          <button
            onClick={handleDismiss}
            className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface transition-colors"
            title="Acknowledge announcement (Service remains strictly OUT OF SERVICE)"
            aria-label="Close Announcement"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Announcement Body */}
        <div className="p-5 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
          {/* Public PA Audio-Visual Announcement Box */}
          <div className="p-3.5 rounded-xl bg-coral/10 border border-coral/30 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase tracking-wider text-coral font-bold flex items-center gap-1.5">
                <Volume2 className={`w-4 h-4 ${isSpeaking ? "animate-bounce text-coral" : "text-text-secondary"}`} />
                <span>OFFICIAL SAFETY BROADCAST TRANSCRIPT</span>
              </span>

              <div className="flex items-center gap-1.5">
                {isSpeaking ? (
                  <button
                    onClick={handleStopAnnouncement}
                    className="px-2.5 py-1 rounded bg-surface hover:bg-surface-hover text-text-secondary hover:text-text-primary text-[11px] font-mono font-semibold flex items-center gap-1 transition-colors border border-border"
                    title="Mute spoken announcement"
                  >
                    <VolumeX className="w-3.5 h-3.5 text-coral" />
                    <span>Mute</span>
                  </button>
                ) : (
                  <button
                    onClick={handlePlayAnnouncement}
                    className="px-2.5 py-1 rounded bg-coral/20 hover:bg-coral/30 text-coral text-[11px] font-mono font-bold flex items-center gap-1 transition-colors border border-coral/30"
                    title="Replay safety chime and voice announcement"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Replay Announcement</span>
                  </button>
                )}
              </div>
            </div>

            <div className="p-3 rounded-lg bg-card/90 border border-coral/20 text-text-primary font-medium text-xs leading-relaxed italic border-l-4 border-l-coral shadow-subtle">
              &ldquo;Attention all passengers and building operations: A safety interlock announcement has been issued for Elevator Unit ELEV-001. Critical damage has been detected in the <strong>{componentLabel}</strong>. Cabin travel is immediately halted, and emergency electromechanical brakes have engaged. Please remain calm. Certified maintenance technicians have been notified.&rdquo;
            </div>
          </div>

          {/* Operational Safety Lock Status */}
          <div className="p-3 rounded-xl bg-surface border border-border flex items-start gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-coral mt-1 shrink-0 animate-ping" />
            <div className="space-y-1">
              <span className="font-semibold text-text-primary flex items-center gap-2">
                <span>Elevator Operating State:</span>
                <strong className="text-coral uppercase font-mono px-2 py-0.5 rounded bg-coral/15 border border-coral/30 text-[11px]">
                  OUT OF SERVICE (SAFETY STOP)
                </strong>
              </span>
              <p id="fault-modal-desc" className="text-text-secondary text-[11px] leading-relaxed">
                Passenger calls and cabin movement are blocked. Dismissing this announcement records an acknowledgment in the immutable audit log but does <strong>NOT</strong> clear the fault or re-enable passenger movement.
              </p>
            </div>
          </div>

          {/* Damage & Diagnostics Summary */}
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="p-2.5 rounded-lg bg-surface border border-border">
              <span className="text-[10px] font-mono text-text-muted uppercase block">
                Damaged Subsystem
              </span>
              <span className="font-bold text-text-primary">
                {componentLabel}
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-surface border border-border">
              <span className="text-[10px] font-mono text-text-muted uppercase block">
                Incident Severity
              </span>
              <span className="font-bold uppercase text-coral flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Critical Fault ({activeFault.name})
              </span>
            </div>
          </div>

          {/* Live Sensor Evidence List */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-mono text-text-muted uppercase tracking-wider block">
              Tripped Telemetry Evidence
            </span>
            <div className="space-y-1 bg-surface rounded-lg p-2.5 border border-border">
              {Object.entries(activeFault.sensorDeltas).map(([channel]) => {
                const s = sensors[channel];
                const latest = s?.readings.slice(-1)[0]?.value ?? 0;
                return (
                  <div key={channel} className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-text-secondary">{channel}:</span>
                    <span className="font-bold text-coral">
                      {latest.toFixed(2)} {s?.unit} (&gt; {s?.critThreshold} {s?.unit})
                    </span>
                  </div>
                );
              })}
              {activeFault.expectedSymptoms.map((sym, i) => (
                <div key={i} className="text-[11px] text-text-secondary flex items-start gap-1.5 pt-1">
                  <span className="text-coral">&bull;</span>
                  <span>{sym}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Recommended Maintenance Action */}
          <div className="p-3 rounded-xl bg-card border border-border space-y-1 text-[11px]">
            <span className="font-semibold text-text-primary flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5 text-sage" />
              <span>Recommended Recovery Workflow</span>
            </span>
            <p className="text-text-secondary text-[11px] leading-relaxed">
              1. Inspect causal hypotheses on the Root Cause Analysis (RCA) dashboard.<br />
              2. Log repair actions on the authorized Maintenance console.<br />
              3. Run post-repair sensor retest verification before returning cabin to service.
            </p>
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="p-4 bg-surface border-t border-border flex flex-wrap items-center justify-between gap-2.5">
          <button
            onClick={handleDismiss}
            className="px-3.5 py-2 rounded-lg bg-card hover:bg-card/80 text-text-secondary hover:text-text-primary text-xs font-medium border border-border transition-colors"
          >
            Acknowledge Announcement
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                handleStopAnnouncement();
                dismissFaultAlert();
                navigate("/investigation");
              }}
              className="px-3 py-2 rounded-lg bg-surface hover:bg-surface-hover text-text-primary text-xs font-semibold border border-border transition-colors flex items-center gap-1.5"
            >
              <Search className="w-3.5 h-3.5 text-sage" />
              <span>Analyze Root Cause</span>
            </button>

            <button
              onClick={handleProceedToMaintenance}
              className="px-3.5 py-2 rounded-lg bg-coral hover:bg-coral/90 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>Maintenance Console</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FaultAlertModal;
