// src/context/AuthContext.tsx
import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured, getSupabaseErrorMessage } from "../lib/supabase";
import { AuthContextType, CertifiedRole, UserProfile } from "../types/auth";
import { useElevatorStore } from "../simulation/store";
import { MaintenanceSession } from "../auth/maintenanceAuth";

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const loginMaintenance = useElevatorStore((s) => s.loginMaintenance);
  const logoutMaintenance = useElevatorStore((s) => s.logoutMaintenance);
  const currentAssetId = useElevatorStore((s) => s.assetId);

  // Synchronize Supabase user/profile into elevator maintenance session
  const syncMaintenanceSession = useCallback(
    (u: User | null, prof: UserProfile | null, token?: string) => {
      if (!u || !prof) return;

      const maintSession: MaintenanceSession = {
        user: {
          id: u.id,
          username: u.email?.split("@")[0] || prof.full_name.toLowerCase().replace(/\s+/g, "_"),
          fullName: prof.full_name || u.email || "Certified Technician",
          role: prof.role || "field_technician",
          badgeNumber: prof.badge_number || `TECH-${u.id.substring(0, 4).toUpperCase()}`,
          authorizedAssets: prof.authorized_assets || ["*"],
        },
        assetId: currentAssetId,
        token: token || `supabase-${u.id}`,
        loginTime: new Date().toISOString(),
        expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
      };

      loginMaintenance(maintSession);
    },
    [loginMaintenance, currentAssetId]
  );

  // Fetch or construct user profile
  const fetchProfile = useCallback(
    async (u: User): Promise<UserProfile> => {
      try {
        if (!isSupabaseConfigured) {
          throw new Error("Supabase credentials unconfigured");
        }

        const { data, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", u.id)
          .single();

        if (!error && data) {
          const loadedProfile: UserProfile = {
            id: data.id,
            email: u.email,
            full_name: data.full_name || u.user_metadata?.full_name || "Certified Technician",
            role: (data.role as CertifiedRole) || (u.user_metadata?.role as CertifiedRole) || "field_technician",
            badge_number: data.badge_number || u.user_metadata?.badge_number || `TECH-${u.id.substring(0, 4)}`,
            authorized_assets: data.authorized_assets || ["*"],
            created_at: data.created_at,
            updated_at: data.updated_at,
          };
          setProfile(loadedProfile);
          return loadedProfile;
        }
      } catch (err) {
        // Fallback to user metadata if profiles table query fails (e.g. before initial migration)
      }

      // Metadata fallback profile
      const meta = u.user_metadata || {};
      const fallbackProfile: UserProfile = {
        id: u.id,
        email: u.email,
        full_name: meta.full_name || u.email?.split("@")[0] || "Certified Technician",
        role: (meta.role as CertifiedRole) || "field_technician",
        badge_number: meta.badge_number || `TECH-${u.id.substring(0, 4).toUpperCase()}`,
        authorized_assets: meta.authorized_assets || ["*"],
      };
      setProfile(fallbackProfile);
      return fallbackProfile;
    },
    []
  );

  // Restore session on boot
  useEffect(() => {
    let isMounted = true;

    // Listen for online/offline window events
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    const initAuth = async () => {
      try {
        if (!isSupabaseConfigured) {
          // If no Supabase credentials configured, check if local maintenanceSession exists
          const existingLocal = useElevatorStore.getState().maintenanceSession;
          if (existingLocal) {
            setIsOfflineMode(true);
            setProfile({
              id: existingLocal.user.id,
              full_name: existingLocal.user.fullName,
              role: existingLocal.user.role as CertifiedRole,
              badge_number: existingLocal.user.badgeNumber,
              authorized_assets: existingLocal.user.authorizedAssets,
            });
          }
          if (isMounted) setIsLoading(false);
          return;
        }

        const { data: { session: initialSession }, error } = await supabase.auth.getSession();

        if (error) {
          console.warn("[Elevator-RCA Auth] Failed to retrieve session:", error.message);
        }

        if (isMounted && initialSession?.user) {
          setSession(initialSession);
          setUser(initialSession.user);
          const prof = await fetchProfile(initialSession.user);
          syncMaintenanceSession(initialSession.user, prof, initialSession.access_token);
        }
      } catch (err: any) {
        console.warn("[Elevator-RCA Auth] Initialization exception:", err);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    initAuth();

    // Subscribe to auth state changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, currentSession) => {
      if (!isMounted) return;

      if (event === "SIGNED_OUT" || !currentSession) {
        setUser(null);
        setSession(null);
        setProfile(null);
        setIsOfflineMode(false);
        logoutMaintenance();
      } else if (currentSession?.user) {
        setSession(currentSession);
        setUser(currentSession.user);
        setIsOfflineMode(false);
        const prof = await fetchProfile(currentSession.user);
        syncMaintenanceSession(currentSession.user, prof, currentSession.access_token);
      }
      setIsLoading(false);
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [fetchProfile, syncMaintenanceSession, logoutMaintenance]);

  // Sign in with email & password
  const signInWithEmail = async (email: string, password: string) => {
    setAuthError(null);
    try {
      if (!isSupabaseConfigured) {
        return {
          success: false,
          error: "Supabase connection is not configured in .env.local. You can use 'Offline Demo Access' to test the application.",
        };
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (error) {
        const msg = getSupabaseErrorMessage(error);
        setAuthError(msg);
        return { success: false, error: msg };
      }

      if (data.user) {
        setUser(data.user);
        setSession(data.session);
        setIsOfflineMode(false);
        const prof = await fetchProfile(data.user);
        syncMaintenanceSession(data.user, prof, data.session?.access_token);
        return { success: true };
      }

      return { success: false, error: "No user returned from authentication service." };
    } catch (err: any) {
      const msg = err?.message || "Network error connecting to authentication server.";
      setAuthError(msg);
      return { success: false, error: msg };
    }
  };

  // Sign up new user with certified role
  const signUpWithEmail = async (
    email: string,
    password: string,
    fullName: string,
    role: CertifiedRole,
    badgeNumber?: string
  ) => {
    setAuthError(null);
    try {
      if (!isSupabaseConfigured) {
        return {
          success: false,
          error: "Supabase connection is not configured in .env.local.",
        };
      }

      const cleanBadge = badgeNumber?.trim() || `TECH-${Date.now().toString().slice(-4)}`;
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            full_name: fullName.trim(),
            role,
            badge_number: cleanBadge,
            authorized_assets: ["*"],
          },
        },
      });

      if (error) {
        const msg = getSupabaseErrorMessage(error);
        setAuthError(msg);
        return { success: false, error: msg };
      }

      // Check if email confirmation is required
      const confirmationRequired = Boolean(data.user && !data.session);

      if (data.user && data.session) {
        setUser(data.user);
        setSession(data.session);
        setIsOfflineMode(false);
        const prof = await fetchProfile(data.user);
        syncMaintenanceSession(data.user, prof, data.session.access_token);
      }

      return {
        success: true,
        confirmationRequired,
      };
    } catch (err: any) {
      const msg = err?.message || "Failed to create account. Please try again.";
      setAuthError(msg);
      return { success: false, error: msg };
    }
  };

  // Password reset email recovery
  const resetPasswordForEmail = async (email: string) => {
    setAuthError(null);
    try {
      if (!isSupabaseConfigured) {
        return {
          success: false,
          error: "Supabase is not configured.",
        };
      }

      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/login?reset=true`,
      });

      if (error) {
        const msg = getSupabaseErrorMessage(error);
        setAuthError(msg);
        return { success: false, error: msg };
      }

      return { success: true };
    } catch (err: any) {
      const msg = err?.message || "Failed to send password recovery email.";
      setAuthError(msg);
      return { success: false, error: msg };
    }
  };

  // Sign out
  const signOut = async () => {
    try {
      if (isSupabaseConfigured) {
        await supabase.auth.signOut();
      }
    } catch (err) {
      console.warn("SignOut warning:", err);
    } finally {
      setUser(null);
      setSession(null);
      setProfile(null);
      setIsOfflineMode(false);
      logoutMaintenance();
    }
  };

  // Offline / Demo access for field engineers when disconnected in elevator shafts
  const loginOfflineDemo = (role: CertifiedRole = "lead_pe", customAssetId?: string) => {
    const asset = customAssetId || currentAssetId;
    const offlineProfile: UserProfile = {
      id: `OFFLINE-${role.toUpperCase()}`,
      full_name: role === "lead_pe" ? "N. Topson (Lead PE)" : role === "admin" ? "System Administrator" : "M. Vance (Field Tech)",
      role,
      badge_number: role === "lead_pe" ? "PE-1001" : role === "admin" ? "ADM-001" : "BT-4812",
      authorized_assets: ["*"],
    };

    setIsOfflineMode(true);
    setProfile(offlineProfile);

    const maintSession: MaintenanceSession = {
      user: {
        id: offlineProfile.id,
        username: role,
        fullName: offlineProfile.full_name,
        role: offlineProfile.role,
        badgeNumber: offlineProfile.badge_number,
        authorizedAssets: offlineProfile.authorized_assets,
      },
      assetId: asset,
      token: `offline-token-${Date.now()}`,
      loginTime: new Date().toISOString(),
      expiresAt: Date.now() + 8 * 60 * 60 * 1000, // 8 hours offline shift
    };

    loginMaintenance(maintSession);
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        isLoading,
        isOnline,
        isOfflineMode,
        authError,
        signInWithEmail,
        signUpWithEmail,
        resetPasswordForEmail,
        signOut,
        loginOfflineDemo,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

