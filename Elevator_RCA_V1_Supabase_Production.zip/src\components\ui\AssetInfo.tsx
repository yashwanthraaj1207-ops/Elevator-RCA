// src/components/ui/AssetInfo.tsx
import React from "react";
import { Card } from "./Card";
import { Radio, ShieldCheck, MapPin, Cpu } from "lucide-react";

export const AssetInfo: React.FC = () => {
  const asset = {
    id: "ELEV-001",
    model: "Otis Gen2 / Model-X200",
    location: "North Tower • Service Bay 4",
    connection: "Telemetry Stream Active (Simulated)",
    installDate: "2021-08-14",
    ratedLoad: "1600 kg (21 Persons)",
  };

  return (
    <Card className="p-4 bg-card border-border">
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Left: Asset Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-surface border border-border flex items-center justify-center text-sage">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold font-mono text-text-primary tracking-tight">
                {asset.id}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-surface border border-border text-text-secondary font-mono">
                {asset.model}
              </span>
            </div>
            <div className="flex items-center gap-3 text-xs text-text-secondary mt-0.5">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-text-muted" />
                {asset.location}
              </span>
              <span className="text-text-muted">•</span>
              <span>Rated: {asset.ratedLoad}</span>
            </div>
          </div>
        </div>

        {/* Right: Telemetry Connection Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-sage/10 border border-sage/25 text-sage text-xs font-mono font-medium">
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span>{asset.connection}</span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-text-secondary">
            <ShieldCheck className="w-4 h-4 text-sage" />
            <span>ISO 25745 Class A</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default AssetInfo;
