// src/components/simulation/TimelineReplayBar.tsx
import React, { useEffect, useRef, useState } from "react";
import { useElevatorStore } from "../../simulation/store";
import {
  Play,
  Pause,
  RotateCcw,
  FastForward,
  Rewind,
  Clock,
  Radio,
  AlertTriangle,
  History,
  CheckCircle2,
} from "lucide-react";
import { Button } from "../ui/Button";

interface TimelineReplayBarProps {
  className?: string;
  showCompact?: boolean;
}

export const TimelineReplayBar: React.FC<TimelineReplayBarProps> = ({
  className = "",
  showCompact = false,
}) => {
  const timelineHistory = useElevatorStore((s) => s.timelineHistory);
  const replayMode = useElevatorStore((s) => s.replayMode);
  const replayTime = useElevatorStore((s) => s.replayTime);
  const liveTime = useElevatorStore((s) => s.time);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const startReplay = useElevatorStore((s) => s.startReplay);
  const seekReplay = useElevatorStore((s) => s.seekReplay);
  const stepReplay = useElevatorStore((s) => s.stepReplay);
  const stopReplay = useElevatorStore((s) => s.stopReplay);

  const [isReplayPlaying, setIsReplayPlaying] = useState<boolean>(false);
  const [replayPlaybackSpeed, setReplayPlaybackSpeed] = useState<number>(1);
  const playbackTimerRef = useRef<any>(null);

  const minTime = timelineHistory[0]?.time ?? 0;
  const maxTime = timelineHistory[timelineHistory.length - 1]?.time ?? liveTime;
  const currentTime = replayMode ? (replayTime ?? liveTime) : liveTime;

  // Find fault event snapshot if any
  const faultSnapshot = timelineHistory.find((s) => s.activeFault !== undefined);

  // Replay playback loop
  useEffect(() => {
    if (isReplayPlaying && replayMode) {
      playbackTimerRef.current = setInterval(() => {
        const curr = useElevatorStore.getState().replayTime ?? minTime;
        const next = curr + 1;
        if (next > maxTime) {
          setIsReplayPlaying(false);
        } else {
          seekReplay(next);
        }
      }, 1000 / replayPlaybackSpeed);
    } else {
      if (playbackTimerRef.current) {
        clearInterval(playbackTimerRef.current);
        playbackTimerRef.current = null;
      }
    }

    return () => {
      if (playbackTimerRef.current) {
        clearInterval(playbackTimerRef.current);
      }
    };
  }, [isReplayPlaying, replayMode, maxTime, minTime, replayPlaybackSpeed, seekReplay]);

  const handleTogglePlay = () => {
    if (!replayMode) {
      startReplay(currentTime);
      setIsReplayPlaying(true);
    } else {
      setIsReplayPlaying((prev) => !prev);
    }
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    if (!replayMode) {
      startReplay(val);
    } else {
      seekReplay(val);
    }
  };

  const handleReturnToLive = () => {
    setIsReplayPlaying(false);
    stopReplay();
  };

  return (
    <div
      className={`p-3 rounded-xl border transition-all ${
        replayMode
          ? "bg-amber-warm/5 border-amber-warm/40 shadow-sm"
          : "bg-surface border-border"
      } ${className}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left Status & Time */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            {replayMode ? (
              <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold uppercase tracking-wider bg-amber-warm/20 text-amber-warm border border-amber-warm/40 animate-pulse">
                <History className="w-3 h-3" />
                Deterministic Replay Active
              </span>
            ) : (
              <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold uppercase tracking-wider bg-sage/15 text-sage border border-sage/30">
                <Radio className="w-3 h-3 animate-pulse" />
                Live Telemetry Stream
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-text-muted">Sim Time:</span>
            <strong className={`font-bold ${replayMode ? "text-amber-warm" : "text-text-primary"}`}>
              {currentTime.toFixed(0)}s
            </strong>
            <span className="text-text-muted text-[10px]">
              (Buffer: {timelineHistory.length} snapshots / {maxTime.toFixed(0)}s span)
            </span>
          </div>
        </div>

        {/* Center / Right Controls */}
        <div className="flex items-center gap-2">
          {faultSnapshot && (
            <button
              onClick={() => {
                startReplay(faultSnapshot.time);
                setIsReplayPlaying(false);
              }}
              className="px-2 py-1 rounded text-[11px] font-mono flex items-center gap-1 bg-coral/15 text-coral hover:bg-coral/25 border border-coral/30 transition-colors"
              title={`Jump to Fault Event at t=${faultSnapshot.time}s`}
            >
              <AlertTriangle className="w-3 h-3" />
              <span>Fault @ {faultSnapshot.time}s</span>
            </button>
          )}

          <button
            onClick={() => stepReplay(-5)}
            className="p-1.5 rounded hover:bg-surface-hover text-text-secondary hover:text-text-primary border border-border text-xs transition-colors"
            title="Rewind 5 seconds"
          >
            <Rewind className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleTogglePlay}
            className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1.5 border transition-colors ${
              replayMode && isReplayPlaying
                ? "bg-amber-warm text-background font-bold border-amber-warm"
                : "bg-surface hover:bg-surface-hover text-text-primary border-border"
            }`}
          >
            {replayMode && isReplayPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>{replayMode ? "Play" : "Replay"}</span>
              </>
            )}
          </button>

          <button
            onClick={() => stepReplay(5)}
            className="p-1.5 rounded hover:bg-surface-hover text-text-secondary hover:text-text-primary border border-border text-xs transition-colors"
            title="Fast-forward 5 seconds"
          >
            <FastForward className="w-3.5 h-3.5" />
          </button>

          {/* Speed Multiplier */}
          {replayMode && (
            <div className="flex items-center bg-surface border border-border rounded p-0.5 text-[10px] font-mono font-bold">
              {[1, 2, 5].map((spd) => (
                <button
                  key={spd}
                  onClick={() => setReplayPlaybackSpeed(spd)}
                  className={`px-1.5 py-0.5 rounded transition-colors ${
                    replayPlaybackSpeed === spd
                      ? "bg-amber-warm text-background"
                      : "text-text-secondary hover:text-text-primary"
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          )}

          {replayMode ? (
            <Button
              variant="secondary"
              size="sm"
              onClick={handleReturnToLive}
              className="text-xs text-sage border-sage/40 flex items-center gap-1 ml-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Return to Live
            </Button>
          ) : (
            <button
              onClick={() => startReplay(Math.max(minTime, maxTime - 10))}
              className="px-2.5 py-1 rounded bg-surface hover:bg-surface-hover text-text-secondary text-xs border border-border transition-colors font-medium"
              title="Scrub recorded history"
            >
              Scrub History
            </button>
          )}
        </div>
      </div>

      {/* Scrubbing Slider Bar */}
      <div className="mt-2.5 flex items-center gap-2">
        <span className="text-[10px] font-mono text-text-muted">{minTime}s</span>
        <input
          type="range"
          min={minTime}
          max={Math.max(minTime + 1, maxTime)}
          step={1}
          value={currentTime}
          onChange={handleSliderChange}
          className="flex-1 accent-amber-warm h-1.5 bg-card rounded-lg appearance-none cursor-pointer border border-border"
        />
        <span className="text-[10px] font-mono text-text-muted">{maxTime}s</span>
      </div>
    </div>
  );
};
