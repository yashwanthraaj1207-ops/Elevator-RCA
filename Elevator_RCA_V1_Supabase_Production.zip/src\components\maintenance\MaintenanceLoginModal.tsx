// src/components/maintenance/MaintenanceLoginModal.tsx
/**
 * Dedicated Maintenance Authentication Screen / Modal (Feature 3).
 *
 * Requirements:
 * - Dedicated authentication screen/modal for technician login.
 * - Fields: Elevator asset/model identifier, Technician username or ID, Password.
 * - Validation errors, loading state, show/hide password toggle.
 * - Clear demo credentials guidance card.
 * - Authorized maintenance role and asset access checks via maintenanceAuthAdapter.
 * - Session status, expiry, and logout triggers.
 * - Clearly labeled as DEMO AUTHENTICATION for prototype simulation only.
 */

import React, { useState } from "react";
import { useElevatorStore } from "../../simulation/store";
import {
  maintenanceAuthAdapter,
  DEMO_CREDENTIALS_HINT,
} from "../../auth/maintenanceAuth";
import {
  ShieldCheck,
  Lock,
  User,
  Key,
  Eye,
  EyeOff,
  AlertCircle,
  Building2,
  Info,
  LogOut,
} from "lucide-react";
import { Button } from "../ui/Button";

interface MaintenanceLoginModalProps {
  onSuccess?: () => void;
}

export const MaintenanceLoginModal: React.FC<MaintenanceLoginModalProps> = ({ onSuccess }) => {
  const assetId = useElevatorStore((s) => s.assetId);
  const session = useElevatorStore((s) => s.maintenanceSession);
  const loginMaintenance = useElevatorStore((s) => s.loginMaintenance);
  const logoutMaintenance = useElevatorStore((s) => s.logoutMaintenance);

  const [inputAssetId, setInputAssetId] = useState(assetId);
  const [username, setUsername] = useState("tech_vance");
  const [password, setPassword] = useState("elevator!tech4812");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await maintenanceAuthAdapter.login(inputAssetId, username, password);
      if (res.success && res.session) {
        loginMaintenance(res.session);
        if (onSuccess) onSuccess();
      } else {
        setError(res.error || "Authentication failed. Please verify credentials.");
      }
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred during authentication.");
    } finally {
      setLoading(false);
    }
  };

  const fillCredential = (user: string, pass: string) => {
    setUsername(user);
    setPassword(pass);
    setInputAssetId(assetId);
    setError(null);
  };

  if (session) {
    return (
      <div className="p-4 rounded-xl bg-card border border-border space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-sage/15 text-sage flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-sage font-bold uppercase block">
                Authenticated Session Active
              </span>
              <h4 className="text-xs font-bold text-text-primary">
                {session.user.fullName} ({session.user.role.toUpperCase()})
              </h4>
            </div>
          </div>

          <button
            onClick={logoutMaintenance}
            className="px-2.5 py-1 rounded-md text-xs font-medium text-coral hover:bg-coral/10 border border-coral/30 transition-colors flex items-center gap-1"
          >
            <LogOut className="w-3.5 h-3.5" />
            Logout
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono">
          <div className="p-2 rounded bg-surface border border-border">
            <span className="text-text-muted text-[10px] block">Technician ID</span>
            <span className="text-text-primary font-bold">{session.user.id}</span>
          </div>
          <div className="p-2 rounded bg-surface border border-border">
            <span className="text-text-muted text-[10px] block">Authorized Asset</span>
            <span className="text-text-primary font-bold">{session.assetId}</span>
          </div>
          <div className="p-2 rounded bg-surface border border-border col-span-2 sm:col-span-1">
            <span className="text-text-muted text-[10px] block">Badge License</span>
            <span className="text-sage font-bold">{session.user.badgeNumber}</span>
          </div>
        </div>

        <div className="p-2 rounded bg-surface/60 border border-border text-[10px] text-text-secondary flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-sage shrink-0" />
          <span>
            Session valid for 30 minutes. Privileged maintenance actions are unlocked for Asset {session.assetId}.
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-5 rounded-2xl bg-card border-2 border-border shadow-card space-y-4 max-w-lg mx-auto">
      {/* Header Banner */}
      <div className="flex items-start justify-between border-b border-border pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-warm/15 text-amber-warm flex items-center justify-center border border-amber-warm/30">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-amber-warm font-bold uppercase tracking-wider block">
              Restricted Engineering Access
            </span>
            <h3 className="text-sm font-bold text-text-primary tracking-tight">
              Maintenance Authentication
            </h3>
          </div>
        </div>

        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-surface border border-border text-text-muted">
          DEMO MODE
        </span>
      </div>

      <p className="text-xs text-text-secondary leading-relaxed">
        Privileged actions (starting repairs, logging work orders, retest verification, and return-to-service)
        require an authorized technician login.
      </p>

      {/* Error Message */}
      {error && (
        <div className="p-3 rounded-lg bg-coral/10 border border-coral/30 text-coral text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleLogin} className="space-y-3 text-xs">
        {/* Asset ID */}
        <div>
          <label className="text-[11px] font-medium text-text-secondary mb-1 flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-text-muted" />
            Target Elevator Asset Identifier
          </label>
          <input
            type="text"
            value={inputAssetId}
            onChange={(e) => setInputAssetId(e.target.value)}
            placeholder="e.g. ELEV-001"
            className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-text-primary font-mono text-xs focus:outline-none focus:border-sage transition-colors"
            required
          />
        </div>

        {/* Technician Username */}
        <div>
          <label className="text-[11px] font-medium text-text-secondary mb-1 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-text-muted" />
            Technician Username / Badge ID
          </label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="e.g. tech_vance or pe_topson"
            className="w-full px-3 py-2 rounded-lg bg-surface border border-border text-text-primary font-mono text-xs focus:outline-none focus:border-sage transition-colors"
            required
          />
        </div>

        {/* Password with Show/Hide toggle */}
        <div>
          <label className="text-[11px] font-medium text-text-secondary mb-1 flex items-center gap-1.5">
            <Key className="w-3.5 h-3.5 text-text-muted" />
            Security Credential / Password
          </label>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full pl-3 pr-10 py-2 rounded-lg bg-surface border border-border text-text-primary font-mono text-xs focus:outline-none focus:border-sage transition-colors"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary p-1"
              title={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Submit */}
        <Button
          type="submit"
          variant="primary"
          disabled={loading}
          className="w-full py-2 flex items-center justify-center gap-2 text-xs font-semibold"
        >
          {loading ? (
            <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <ShieldCheck className="w-4 h-4" />
          )}
          <span>{loading ? "Authenticating Session..." : "Authorize Technician Session"}</span>
        </Button>
      </form>

      {/* Demo Credentials Quick-Select Pillbox */}
      <div className="pt-3 border-t border-border space-y-2">
        <span className="text-[10px] font-mono text-text-muted uppercase tracking-wider block">
          Demo Prototype Technician Accounts:
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
          {DEMO_CREDENTIALS_HINT.map((c) => (
            <button
              key={c.username}
              type="button"
              onClick={() => fillCredential(c.username, c.pass)}
              className="p-1.5 rounded-lg bg-surface hover:bg-surface-hover border border-border text-left transition-colors text-[10px] group"
            >
              <div className="font-semibold text-text-primary group-hover:text-sage">
                {c.role}
              </div>
              <div className="font-mono text-text-muted text-[9px] truncate">
                {c.username}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

