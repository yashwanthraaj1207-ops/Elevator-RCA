// src/components/ui/Button.tsx
import React from "react";
import classNames from "classnames";

export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "danger" | "ghost" | "outline" | "amber";
  size?: "sm" | "md" | "lg";
  className?: string;
};

export const Button: React.FC<ButtonProps> = ({
  variant = "primary",
  size = "md",
  className,
  children,
  ...rest
}) => {
  const sizeStyles = {
    sm: "px-2.5 py-1 text-xs",
    md: "px-3.5 py-1.5 text-xs font-medium",
    lg: "px-4 py-2 text-sm font-medium",
  }[size];

  const variantClasses = {
    primary: "bg-sage text-[#171916] font-semibold hover:bg-sage-hover shadow-subtle",
    secondary: "bg-surface border border-border text-text-primary hover:bg-surface-hover hover:border-border-strong",
    danger: "bg-coral text-white hover:opacity-90 shadow-subtle",
    amber: "bg-amber-warm text-[#171916] font-semibold hover:opacity-90 shadow-subtle",
    ghost: "text-text-secondary hover:text-text-primary hover:bg-surface/60",
    outline: "border border-border text-text-primary hover:bg-surface hover:border-border-strong",
  }[variant];

  return (
    <button
      className={classNames(
        "inline-flex items-center justify-center rounded-lg transition-all focus:outline-none focus-visible:ring-1 focus-visible:ring-sage disabled:opacity-50 disabled:cursor-not-allowed",
        sizeStyles,
        variantClasses,
        className
      )}
      {...rest}
    >
      {children}
    </button>
  );
};

export default Button;
