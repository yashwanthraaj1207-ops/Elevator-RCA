// src/components/ui/Card.tsx
import React from "react";
import classNames from "classnames";

export type CardProps = React.HTMLAttributes<HTMLDivElement> & {
  className?: string;
  variant?: "default" | "elevated" | "subtle";
};

export const Card: React.FC<CardProps> = ({
  className,
  variant = "default",
  children,
  ...rest
}) => {
  const variantClass = {
    default: "bg-card border-border",
    elevated: "bg-surface border-border-strong shadow-elevated",
    subtle: "bg-surface/50 border-border/70",
  }[variant];

  return (
    <div
      className={classNames(
        "rounded-xl p-4 shadow-card border text-text-primary transition-colors",
        variantClass,
        className
      )}
      {...rest}
    >
      {children}
    </div>
  );
};

export default Card;
