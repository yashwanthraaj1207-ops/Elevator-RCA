// src/components/digitalTwin/ElevatorModel.tsx
import React from "react";
import { ModelViewer, ModelViewerProps } from "./ModelViewer";

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

export class SceneErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  override render() {
    if (this.state.hasError) {
      return (
        <div className="flex h-full w-full flex-col items-center justify-center p-6 text-center text-text-secondary bg-[#080D1A] rounded-lg border border-border">
          <p className="text-fault font-semibold">3D Digital Twin Viewer Unavailable</p>
          <p className="text-xs mt-1 text-text-secondary">WebGL context or shader failed to initialize.</p>
          <p className="text-[11px] text-text-secondary/70 mt-2">
            {this.state.error?.message || "Check GPU acceleration or WebGL permissions."}
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}

export const ElevatorModel: React.FC<ModelViewerProps> = (props) => {
  return (
    <SceneErrorBoundary>
      <ModelViewer {...props} />
    </SceneErrorBoundary>
  );
};

export default ElevatorModel;
