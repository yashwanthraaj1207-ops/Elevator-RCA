// src/pages/Methodology.tsx
import React from "react";
import { Card } from "../components/ui/Card";
import {
  BookOpen,
  Cpu,
  Layers,
  ShieldCheck,
  AlertTriangle,
} from "lucide-react";

export const Methodology: React.FC = () => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto text-xs text-text-primary">
      {/* Page Title */}
      <div>
        <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-sage" />
          Engineering Methodology & Diagnostic Rules
        </h1>
        <p className="text-xs text-text-secondary mt-0.5">
          Mathematical telemetry baseline models, ISO 13374 diagnostic rules, and prototype scope boundaries.
        </p>
      </div>

      {/* 1. Telemetry Generation & Kinematic Equations */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center gap-2 border-b border-border pb-2.5">
          <Cpu className="w-4 h-4 text-sage" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
            1.0 Telemetry Generation & Kinematics
          </h2>
        </div>
        <p className="text-text-secondary leading-relaxed">
          The shared simulation engine executes a deterministic 1 Hz tick loop. Elevator travel dynamics follow constant-velocity floor transit equations:
        </p>
        <div className="p-3 rounded-lg bg-surface border border-border font-mono text-[11px] space-y-1">
          <div>Position: <code>y(t) = y(t-1) ± v × Δt</code> (Bounded to 0.0m – 32.4m shaft envelope)</div>
          <div>Floor: <code>Floor = max(1, min(10, round(y / 3.6) + 1))</code></div>
          <div>Vibration: <code>Vib(t) = 0.035g + |sin(t/3)| × 0.015g + Δ_fault</code></div>
          <div>Motor Temp: <code>T(t) = 42°C + (t % 60) × 0.08°C + Δ_fault</code></div>
        </div>
      </Card>

      {/* 2. Diagnostic Thresholds & Standards Compliance */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center gap-2 border-b border-border pb-2.5">
          <ShieldCheck className="w-4 h-4 text-sage" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
            2.0 Operating Thresholds & Standards Envelope
          </h2>
        </div>
        <div className="overflow-x-auto border border-border rounded-lg">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-surface text-text-secondary border-b border-border">
              <tr>
                <th className="py-2.5 px-3">Sensor Channel</th>
                <th className="py-2.5 px-3">Standard Reference</th>
                <th className="py-2.5 px-3">Baseline Nominal</th>
                <th className="py-2.5 px-3">Warning Envelope</th>
                <th className="py-2.5 px-3">Critical Trip Threshold</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              <tr>
                <td className="py-2 px-3 font-medium">Vibration</td>
                <td className="py-2 px-3 text-text-secondary">ISO 18738 / ISO 10816</td>
                <td className="py-2 px-3">0.04 g</td>
                <td className="py-2 px-3 text-amber-warm">&ge; 0.09 g</td>
                <td className="py-2 px-3 text-coral font-bold">&ge; 0.15 g</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-medium">Motor Temperature</td>
                <td className="py-2 px-3 text-text-secondary">IEC 60034-1 Class F</td>
                <td className="py-2 px-3">42.0 °C</td>
                <td className="py-2 px-3 text-amber-warm">&ge; 55.0 °C</td>
                <td className="py-2 px-3 text-coral font-bold">&ge; 70.0 °C</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-medium">Motor Current</td>
                <td className="py-2 px-3 text-text-secondary">OEM Stator Rating</td>
                <td className="py-2 px-3">12.5 A</td>
                <td className="py-2 px-3 text-amber-warm">&ge; 18.0 A</td>
                <td className="py-2 px-3 text-coral font-bold">&ge; 24.0 A</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-medium">Payload Mass</td>
                <td className="py-2 px-3 text-text-secondary">EN 81-20 Duty Load</td>
                <td className="py-2 px-3">450 kg</td>
                <td className="py-2 px-3 text-amber-warm">&ge; 1350 kg</td>
                <td className="py-2 px-3 text-coral font-bold">&ge; 1600 kg</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>

      {/* 3. Diagnostic Rules & Hypothesis Ranking */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center gap-2 border-b border-border pb-2.5">
          <Layers className="w-4 h-4 text-sage" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
            3.0 Rule-Based Hypothesis Generation & Evidence Weighting
          </h2>
        </div>
        <p className="text-text-secondary leading-relaxed">
          The diagnostic engine does not use unverified deep-learning black boxes. Instead, it applies an explainable expert rule set derived from ISO 13374 Condition Monitoring and Fault Diagnosis:
        </p>
        <ul className="space-y-2 list-disc pl-4 text-text-secondary">
          <li>
            <strong className="text-text-primary">RULE_BRG_01 (Bearing Spalling):</strong> Triggered when Vibration &ge; 0.12g AND Motor Temp &ge; 50°C. Weight = 0.92.
          </li>
          <li>
            <strong className="text-text-primary">RULE_MTR_01 (Thermal Saturation):</strong> Triggered when Motor Temp &ge; 65°C AND Vibration &lt; 0.10g. Weight = 0.94.
          </li>
          <li>
            <strong className="text-text-primary">RULE_DOOR_01 (Interlock Obstruction):</strong> Triggered when Door State progress stalls between 10%–90% for &gt; 4 seconds. Weight = 0.91.
          </li>
          <li>
            <strong className="text-text-primary">RULE_BRK_01 (Holding Slip):</strong> Triggered when Brake State &lt; 80% during zero-speed floor stop. Weight = 0.89.
          </li>
        </ul>
      </Card>

      {/* 4. Prototype Boundaries & Disclosures */}
      <Card className="p-5 border-border space-y-3">
        <div className="flex items-center gap-2 border-b border-border pb-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-warm" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
            4.0 Research Prototype Scope & Safety Disclosures
          </h2>
        </div>
        <div className="p-3.5 rounded-lg bg-surface border border-border space-y-2">
          <div className="font-bold text-text-primary">Important Research Disclosure:</div>
          <p className="text-text-secondary leading-relaxed">
            ELEVATOR-RCA is a software research prototype operating entirely on synthetic telemetry. It does NOT interface with physical elevator high-voltage controllers, safety relays, or governor interlocks. Never attempt to use this prototype to bypass real elevator safety mechanisms.
          </p>
        </div>
      </Card>
    </div>
  );
};

export default Methodology;
