// src/lib/supabase.ts
/**
 * Centralized Supabase Client Singleton for ELEVATOR-RCA
 *
 * Configured with official Supabase JavaScript SDK (@supabase/supabase-js)
 * - Browser localStorage session persistence
 * - Automatic token refresh
 * - Safe fallback & clear diagnostic warnings for missing credentials
 */

import { createClient, SupabaseClient } from "@supabase/supabase-js";

// Read from Vite import.meta.env with fallback to process.env
const env = typeof import.meta !== "undefined" && import.meta.env ? import.meta.env : ({} as Record<string, string>);

const supabaseUrl =
  env.VITE_SUPABASE_URL ||
  (typeof process !== "undefined" ? process.env?.VITE_SUPABASE_URL || process.env?.NEXT_PUBLIC_SUPABASE_URL : "") ||
  "https://vfhtxpjkgkoezxeutwco.supabase.co";

const supabasePublishableKey =
  env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  env.VITE_SUPABASE_ANON_KEY ||
  (typeof process !== "undefined"
    ? process.env?.VITE_SUPABASE_PUBLISHABLE_KEY ||
      process.env?.VITE_SUPABASE_ANON_KEY ||
      process.env?.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
    : "") ||
  "sb_publishable_ANG24UI1UIbQ_PuAsa326Q_xVC0AhzO";

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabasePublishableKey &&
  supabaseUrl !== "https://your-project-id.supabase.co" &&
  !supabasePublishableKey.includes("YOUR_SUPABASE_PUBLISHABLE_KEY")
);

if (!isSupabaseConfigured && typeof window !== "undefined") {
  console.warn(
    "[Elevator-RCA Supabase] Missing or placeholder Supabase credentials in .env.local. " +
    "Authentication will operate in local offline prototype mode until valid keys are configured."
  );
}

/**
 * Reusable Supabase Client Singleton instance
 */
export const supabase: SupabaseClient = createClient(
  supabaseUrl || "https://vfhtxpjkgkoezxeutwco.supabase.co",
  supabasePublishableKey || "sb_publishable_ANG24UI1UIbQ_PuAsa326Q_xVC0AhzO",
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: typeof window !== "undefined" ? window.localStorage : undefined,
      storageKey: "elevator_rca_supabase_auth_token",
    },
  }
);

/**
 * Standardized Supabase Error Message Extractor
 */
export function getSupabaseErrorMessage(error: any): string {
  if (!error) return "Unknown authentication error occurred.";
  if (typeof error === "string") return error;
  if (error.message) {
    // Human-friendly translations for common Supabase Auth errors
    if (error.message.includes("Invalid login credentials")) {
      return "Invalid email address or password. Please re-check your credentials.";
    }
    if (error.message.includes("Email not confirmed")) {
      return "Your email address has not been confirmed yet. Please check your inbox for the confirmation email.";
    }
    if (error.message.includes("User already registered")) {
      return "An account with this email address already exists. Please log in instead.";
    }
    if (error.message.includes("Password should be at least")) {
      return "Password must be at least 6 characters long.";
    }
    return error.message;
  }
  return JSON.stringify(error);
}

