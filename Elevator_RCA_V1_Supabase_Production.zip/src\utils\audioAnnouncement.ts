// src/utils/audioAnnouncement.ts
/**
 * Synthesizes an authentic industrial elevator chime, multi-frequency fault beep alarms,
 * and voice safety announcements using HTML5 Web Audio API and Web Speech API.
 * Requires zero external audio assets.
 */

let audioCtx: AudioContext | null = null;
let isMuted: boolean = typeof window !== "undefined" && window.localStorage
  ? window.localStorage.getItem("elevator_rca_audio_muted") === "true"
  : false;

export function getAudioMuted(): boolean {
  return isMuted;
}

export function setAudioMuted(muted: boolean): void {
  isMuted = muted;
  if (typeof window !== "undefined" && window.localStorage) {
    try {
      window.localStorage.setItem("elevator_rca_audio_muted", String(muted));
    } catch {}
  }
  if (muted) {
    stopAnnouncement();
  }
}

export function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!audioCtx) {
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Plays a distinct warning beep pattern: 2 pulses at 520Hz (120ms each)
 */
export function playWarningBeep(): Promise<void> {
  if (isMuted) return Promise.resolve();
  return new Promise((resolve) => {
    try {
      const ctx = getAudioContext();
      if (!ctx) {
        resolve();
        return;
      }

      const now = ctx.currentTime;
      // Pulse 1
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(520, now);
      gain1.gain.setValueAtTime(0.2, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.12);

      // Pulse 2
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(650, now + 0.16);
      gain2.gain.setValueAtTime(0.25, now + 0.16);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.16);
      osc2.stop(now + 0.32);

      setTimeout(resolve, 350);
    } catch {
      resolve();
    }
  });
}

/**
 * Plays an urgent critical alert beep pattern: 3 rapid pulses at 880Hz
 */
export function playCriticalBeep(): Promise<void> {
  if (isMuted) return Promise.resolve();
  return new Promise((resolve) => {
    try {
      const ctx = getAudioContext();
      if (!ctx) {
        resolve();
        return;
      }

      const now = ctx.currentTime;
      for (let i = 0; i < 3; i++) {
        const offset = i * 0.12;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "square"; // Industrial buzzer timbre
        osc.frequency.setValueAtTime(880, now + offset);
        gain.gain.setValueAtTime(0.18, now + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.08);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + offset);
        osc.stop(now + offset + 0.08);
      }

      setTimeout(resolve, 400);
    } catch {
      resolve();
    }
  });
}

/**
 * Universal fault beep dispatcher
 */
export function playFaultBeep(severity: "warning" | "critical" = "critical"): Promise<void> {
  if (severity === "warning") {
    return playWarningBeep();
  }
  return playCriticalBeep();
}

/**
 * Plays a classic 2-tone elevator safety chime (587.33Hz D5 -> 880Hz A5)
 */
export function playElevatorChime(): Promise<void> {
  if (isMuted) return Promise.resolve();
  return new Promise((resolve) => {
    try {
      const ctx = getAudioContext();
      if (!ctx) {
        resolve();
        return;
      }

      const now = ctx.currentTime;

      // Note 1: 587.33 Hz (D5)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(587.33, now);
      gain1.gain.setValueAtTime(0.2, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.35);

      // Note 2: 880.00 Hz (A5)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(880.0, now + 0.22);
      gain2.gain.setValueAtTime(0.25, now + 0.22);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.22);
      osc2.stop(now + 0.7);

      setTimeout(resolve, 750);
    } catch {
      resolve();
    }
  });
}

/**
 * Synthesizes voice announcement using Web Speech API
 */
export function speakAnnouncement(text: string): Promise<void> {
  if (isMuted) return Promise.resolve();
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve();
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      const voices = window.speechSynthesis.getVoices();
      const englishVoice =
        voices.find(
          (v) =>
            v.lang.startsWith("en") &&
            (v.name.includes("Natural") ||
              v.name.includes("Google") ||
              v.name.includes("Samantha") ||
              v.name.includes("Daniel"))
        ) || voices.find((v) => v.lang.startsWith("en"));

      if (englishVoice) {
        utterance.voice = englishVoice;
      }

      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();

      window.speechSynthesis.speak(utterance);
    } catch {
      resolve();
    }
  });
}

/**
 * Plays the fault beep + safety chime first, then speaks the public safety announcement
 */
export async function triggerDamageAnnouncement(componentLabel: string, _faultName?: string) {
  if (isMuted) return;
  await playCriticalBeep();
  await playElevatorChime();
  const announcementText = `Attention: Elevator system safety announcement. Critical damage has been detected in the ${componentLabel}. Cabin travel is stopped, and emergency brakes are engaged. Please remain calm. Maintenance technicians have been dispatched.`;
  await speakAnnouncement(announcementText);
}

export function stopAnnouncement() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {}
  }
}
