// src/pages/Records.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import {
  History,
  Search,
  Filter,
  Download,
  Layers,
} from "lucide-react";
import { useElevatorStore } from "../simulation/store";

interface DiagnosticRecord {
  id: string;
  timestamp: string;
  component: string;
  severity: "normal" | "warning" | "fault";
  summary: string;
  confidence: number;
  status: "Verified" | "Investigating" | "Resolved";
  operator: string;
}

export const Records: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSeverity, setSelectedSeverity] = useState<string>("all");
  const [selectedComponent, setSelectedComponent] = useState<string>("all");

  const staticRecords: DiagnosticRecord[] = [
    {
      id: "REC-2026-0881",
      timestamp: "2026-10-17 20:14:02",
      component: "Main Drive Bearing",
      severity: "fault",
      summary: "Inner race spalling; high-frequency vibration exceeded 1.5 mm/s trip limit.",
      confidence: 0.92,
      status: "Investigating",
      operator: "N. Topson",
    },
    {
      id: "REC-2026-0880",
      timestamp: "2026-10-17 19:42:15",
      component: "Door Operator System",
      severity: "warning",
      summary: "Car door interlock travel duration stall at 45% closing cycle.",
      confidence: 0.89,
      status: "Resolved",
      operator: "K. Chen",
    },
    {
      id: "REC-2026-0879",
      timestamp: "2026-10-17 18:20:00",
      component: "Electromechanical Brake",
      severity: "fault",
      summary: "Position drift 0.45m during zero-speed holding phase; solenoid release delay.",
      confidence: 0.87,
      status: "Resolved",
      operator: "M. Vance",
    },
    {
      id: "REC-2026-0878",
      timestamp: "2026-10-17 14:05:30",
      component: "Traction Motor",
      severity: "normal",
      summary: "Harmonic stator current survey baseline check; thermal gradient stable at 45°C.",
      confidence: 0.98,
      status: "Verified",
      operator: "N. Topson",
    },
    {
      id: "REC-2026-0877",
      timestamp: "2026-10-17 11:30:12",
      component: "Guide Rail Left",
      severity: "normal",
      summary: "Optical alignment survey nominal; guide shoe clearance within 1.2mm tolerance.",
      confidence: 1.0,
      status: "Verified",
      operator: "J. Doe",
    },
    {
      id: "REC-2026-0876",
      timestamp: "2026-10-16 16:45:00",
      component: "Counterweight Assembly",
      severity: "normal",
      summary: "Balance calibration verification nominal; 45% car load compensation confirmed.",
      confidence: 0.99,
      status: "Verified",
      operator: "M. Vance",
    },
  ];

  const maintenance = useElevatorStore((s) => s.maintenance);

  // Merge live maintenance audit entries into the event records table
  const dynamicAuditRecords: DiagnosticRecord[] = maintenance.auditTrail.map((entry, _idx) => ({
    id: entry.id,
    timestamp: entry.timestamp,
    component: maintenance.subsystem || "Elevator System",
    severity: entry.toState.includes("failed") || entry.toState.includes("fault") ? "fault" : entry.toState.includes("open") || entry.toState.includes("progress") ? "warning" : "normal",
    summary: `${entry.action}: ${entry.evidence}`,
    confidence: 0.95,
    status: entry.toState === "repair_verified" || entry.toState === "cleanup_completed" ? "Resolved" : entry.toState === "repair_in_progress" ? "Investigating" : "Verified",
    operator: entry.actor,
  }));

  const allRecords = [...dynamicAuditRecords, ...staticRecords];

  const filteredRecords = allRecords.filter((r) => {
    const matchesSearch =
      r.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.component.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.summary.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSeverity =
      selectedSeverity === "all" || r.severity === selectedSeverity;

    const matchesComponent =
      selectedComponent === "all" || r.component.toLowerCase().includes(selectedComponent.toLowerCase());

    return matchesSearch && matchesSeverity && matchesComponent;
  });

  const exportCsv = () => {
    const headers = "ID,Timestamp,Component,Severity,Confidence,Status,Operator,Summary\n";
    const rows = filteredRecords
      .map(
        (r) =>
          `"${r.id}","${r.timestamp}","${r.component}","${r.severity}","${r.confidence}","${r.status}","${r.operator}","${r.summary}"`
      )
      .join("\n");
    const blob = new Blob([headers + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `diagnostic_records_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <History className="w-5 h-5 text-sage" />
            Diagnostic Event History & Records
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Immutable chronological log of telemetry anomalies, automated RCA diagnoses, and maintenance interventions.
          </p>
        </div>

        <Button
          variant="secondary"
          size="sm"
          onClick={exportCsv}
          className="flex items-center gap-1.5 text-xs font-semibold"
        >
          <Download className="w-3.5 h-3.5" />
          Export CSV Log
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <Card className="p-4 border-border space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-text-muted absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by ID, component, or keyword..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-surface border border-border text-xs text-text-primary placeholder:text-text-muted focus:outline-none focus:border-sage"
            />
          </div>

          {/* Severity Dropdown */}
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-text-muted shrink-0" />
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full py-1.5 px-2.5 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage"
            >
              <option value="all">All Severities</option>
              <option value="fault">Critical Faults Only</option>
              <option value="warning">Warnings Only</option>
              <option value="normal">Normal / Verified</option>
            </select>
          </div>

          {/* Component Filter */}
          <div className="flex items-center gap-2">
            <Layers className="w-3.5 h-3.5 text-text-muted shrink-0" />
            <select
              value={selectedComponent}
              onChange={(e) => setSelectedComponent(e.target.value)}
              className="w-full py-1.5 px-2.5 rounded-lg bg-surface border border-border text-xs text-text-primary focus:outline-none focus:border-sage"
            >
              <option value="all">All Sub-Systems</option>
              <option value="bearing">Main Drive Bearing</option>
              <option value="door">Door Operator</option>
              <option value="brake">Brake Assembly</option>
              <option value="motor">Traction Motor</option>
              <option value="rail">Guide Rails</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Records Table */}
      <Card className="p-0 overflow-hidden border-border">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-surface text-text-secondary border-b border-border font-mono">
              <tr>
                <th className="py-3 px-3.5 font-semibold">Record ID</th>
                <th className="py-3 px-3.5 font-semibold">Timestamp (UTC)</th>
                <th className="py-3 px-3.5 font-semibold">Target Sub-System</th>
                <th className="py-3 px-3.5 font-semibold">Diagnostic Anomaly Summary</th>
                <th className="py-3 px-3.5 font-semibold">Confidence</th>
                <th className="py-3 px-3.5 font-semibold">Severity</th>
                <th className="py-3 px-3.5 font-semibold">Status</th>
                <th className="py-3 px-3.5 font-semibold">Technician</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredRecords.length > 0 ? (
                filteredRecords.map((r) => {
                  const isFault = r.severity === "fault";
                  const isWarning = r.severity === "warning";

                  return (
                    <tr key={r.id} className="hover:bg-surface/40 transition-colors">
                      <td className="py-3 px-3.5 font-mono font-bold text-text-primary">
                        {r.id}
                      </td>
                      <td className="py-3 px-3.5 font-mono text-text-muted">{r.timestamp}</td>
                      <td className="py-3 px-3.5 font-medium text-text-primary">{r.component}</td>
                      <td className="py-3 px-3.5 text-text-secondary max-w-sm">{r.summary}</td>
                      <td className="py-3 px-3.5 font-mono font-bold text-text-primary">
                        {Math.round(r.confidence * 100)}%
                      </td>
                      <td className="py-3 px-3.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                            isFault
                              ? "bg-coral/15 text-coral"
                              : isWarning
                              ? "bg-amber-warm/15 text-amber-warm"
                              : "bg-sage/15 text-sage"
                          }`}
                        >
                          {r.severity}
                        </span>
                      </td>
                      <td className="py-3 px-3.5">
                        <span className="font-semibold text-text-primary">{r.status}</span>
                      </td>
                      <td className="py-3 px-3.5 font-mono text-text-muted">{r.operator}</td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-text-muted">
                    No diagnostic records match the selected search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-3 bg-surface border-t border-border flex items-center justify-between text-xs text-text-secondary font-mono">
          <span>Showing {filteredRecords.length} of {allRecords.length} records</span>
          <span>ISO 13374 Compliant Audit Trail</span>
        </div>
      </Card>
    </div>
  );
};

export default Records;
