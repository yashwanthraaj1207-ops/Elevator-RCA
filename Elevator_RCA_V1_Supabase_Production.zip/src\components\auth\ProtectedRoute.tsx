// src/components/auth/ProtectedRoute.tsx
import React from "react";
import { Navigate, useLocation, Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useElevatorStore } from "../../simulation/store";
import { CertifiedRole } from "../../types/auth";
import { ShieldAlert, ArrowLeft, UserCheck, Shield } from "lucide-react";
import { Button } from "../ui/Button";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: CertifiedRole[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredRoles,
}) => {
  const location = useLocation();
  const { user, session: supabaseSession, profile, isLoading, isOfflineMode } = useAuth();
  const storeSession = useElevatorStore((s) => s.maintenanceSession);

  // Show industrial loader while authentication state is resolving from Supabase storage
  if (isLoading) {
    return (
      <div className="min-h-screen w-full bg-app text-text-primary flex flex-col items-center justify-center p-4 select-none">
        <div className="w-12 h-12 rounded-2xl bg-surface border border-border flex items-center justify-center shadow-card mb-4">
          <div className="w-5 h-5 rounded-full border-2 border-sage border-t-transparent animate-spin" />
        </div>
        <div className="text-sm font-mono font-bold text-text-primary flex items-center gap-2">
          <Shield className="w-4 h-4 text-sage" />
          <span>Verifying Certified Session Handshake</span>
        </div>
        <p className="text-xs text-text-muted mt-1 font-mono">
          Authenticating with Supabase cryptographic session manager...
        </p>
      </div>
    );
  }

  const activeRole: CertifiedRole =
    profile?.role ||
    (storeSession?.user.role as CertifiedRole) ||
    "field_technician";

  const isAuthenticated = Boolean(user || supabaseSession || storeSession || isOfflineMode);

  if (!isAuthenticated) {
    // Redirect to login preserving the intended destination
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Check role authorization if specific roles are required
  if (requiredRoles && requiredRoles.length > 0 && !requiredRoles.includes(activeRole)) {
    const fullName = profile?.full_name || storeSession?.user.fullName || user?.email || "Technician";

    return (
      <div className="max-w-xl mx-auto py-12 px-4 space-y-6 animate-fade-in text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-amber-warm/15 border border-amber-warm/30 text-amber-warm shadow-card">
          <ShieldAlert className="w-7 h-7" />
        </div>

        <div className="space-y-2">
          <h1 className="text-xl font-bold tracking-tight text-text-primary">
            Insufficient Role Permissions
          </h1>
          <p className="text-xs text-text-secondary max-w-md mx-auto">
            This engineering workspace requires elevated credentials. Your current certified role does not have authorization to access this subsystem.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border text-xs text-left space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-text-muted">Authenticated User:</span>
            <span className="font-semibold text-text-primary font-mono">{fullName}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-text-muted">Current Role:</span>
            <span className="px-2 py-0.5 rounded bg-surface border border-border text-amber-warm font-mono font-bold uppercase">
              {activeRole}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-text-muted">Required Role(s):</span>
            <span className="font-mono text-sage font-semibold">
              {requiredRoles.map((r) => r.replace("_", " ").toUpperCase()).join(", ")}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-3 pt-2">
          <Link to="/overview">
            <Button variant="secondary" size="sm" className="flex items-center gap-1.5">
              <ArrowLeft className="w-3.5 h-3.5" />
              Return to Overview
            </Button>
          </Link>
          <Link to="/login" state={{ from: location }}>
            <Button variant="primary" size="sm" className="flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5" />
              Switch Account
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;
