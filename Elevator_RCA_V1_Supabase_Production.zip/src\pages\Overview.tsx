// src/pages/Overview.tsx
import React, { useEffect } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { AssetInfo } from "../components/ui/AssetInfo";
import { ModelViewer } from "../components/digitalTwin/ModelViewer";
import { useElevatorStore } from "../simulation/store";
import { COMPONENT_CATALOG, ComponentId } from "../components/digitalTwin/componentMapping";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  ArrowRight,
  ShieldCheck,
  Search,
  Play,
  Pause,
  RotateCcw,
  Clock,
  Sparkles,
} from "lucide-react";

export const Overview: React.FC = () => {
  const navigate = useNavigate();
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const pauseSimulation = useElevatorStore((s) => s.pauseSimulation);
  const resetSimulation = useElevatorStore((s) => s.resetSimulation);
  const running = useElevatorStore((s) => s.running);
  const time = useElevatorStore((s) => s.time);
  const sensors = useElevatorStore((s) => s.sensors);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const diagnostic = useElevatorStore((s) => s.diagnostic);
  const selectComponent = useElevatorStore((s) => s.selectComponent);

  const activeSensorsCount = Object.keys(sensors).length;
  const abnormalSensors = Object.values(sensors).filter((s) => s.status !== "normal");
  const affectedMeta = activeFault
    ? COMPONENT_CATALOG[activeFault.affectedComponent as ComponentId]
    : null;

  // Mock chronological engineering events matching active system state
  const recentEvents = [
    ...(activeFault
      ? [
          {
            id: "EV-9942",
            time: `${time}s ago`,
            component: affectedMeta?.label || activeFault.affectedComponent,
            message: `Telemetry threshold tripped: ${activeFault.name}`,
            severity: "fault" as const,
            status: "Under Investigation",
          },
        ]
      : []),
    {
      id: "EV-9940",
      time: "14m ago",
      component: "Door Operator",
      message: "Routine interlock optical sensor self-test passed",
      severity: "normal" as const,
      status: "Verified",
    },
    {
      id: "EV-9938",
      time: "1h 12m ago",
      component: "Traction Motor",
      message: "Harmonic current distortion evaluated (THD < 2.8%)",
      severity: "normal" as const,
      status: "Verified",
    },
    {
      id: "EV-9931",
      time: "3h ago",
      component: "Brake Assembly",
      message: "Electromechanical holding pad friction test recorded",
      severity: "normal" as const,
      status: "Verified",
    },
  ];

  return (
    <div className="space-y-5">
      {/* Asset Identity Banner */}
      <AssetInfo />

      {/* 5 Concise KPI Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {/* KPI 1: Operating State */}
        <Card className="p-3.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Operating State</span>
            <Activity className="w-3.5 h-3.5 text-sage" />
          </div>
          <div className="text-lg font-bold font-mono tracking-tight text-text-primary">
            {running ? "RUNNING" : "STANDBY"}
          </div>
          <div className="text-[11px] text-text-muted flex items-center gap-1 font-mono">
            <Clock className="w-3 h-3" />
            <span>Clock: {time}s</span>
          </div>
        </Card>

        {/* KPI 2: Active Faults */}
        <Card className={`p-3.5 space-y-1 ${activeFault ? "border-coral/50 bg-coral/5" : ""}`}>
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Active Anomalies</span>
            {activeFault ? (
              <AlertTriangle className="w-3.5 h-3.5 text-coral animate-pulse" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5 text-sage" />
            )}
          </div>
          <div
            className={`text-lg font-bold font-mono tracking-tight ${
              activeFault ? "text-coral" : "text-text-primary"
            }`}
          >
            {activeFault ? "1 FAULT" : "0 NOMINAL"}
          </div>
          <div className="text-[11px] text-text-muted truncate">
            {activeFault ? activeFault.name : "Within ISO baselines"}
          </div>
        </Card>

        {/* KPI 3: Sensor Fleet Status */}
        <Card className="p-3.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Sensor Fleet</span>
            <Cpu className="w-3.5 h-3.5 text-sage" />
          </div>
          <div className="text-lg font-bold font-mono tracking-tight text-text-primary">
            {activeSensorsCount - abnormalSensors.length}/{activeSensorsCount}
          </div>
          <div className="text-[11px] text-text-muted">
            {abnormalSensors.length > 0 ? (
              <span className="text-coral font-semibold">{abnormalSensors.length} out of bounds</span>
            ) : (
              <span className="text-sage font-semibold">All channels normal</span>
            )}
          </div>
        </Card>

        {/* KPI 4: Latest Diagnostic Confidence */}
        <Card className="p-3.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Diagnostic RCA</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-warm" />
          </div>
          <div className="text-lg font-bold font-mono tracking-tight text-text-primary">
            {diagnostic?.hypotheses[0]
              ? `${Math.round(diagnostic.hypotheses[0].confidence * 100)}%`
              : "100%"}
          </div>
          <div className="text-[11px] text-text-muted truncate">
            {diagnostic?.hypotheses[0] ? diagnostic.hypotheses[0].componentId : "Nominal baseline"}
          </div>
        </Card>

        {/* KPI 5: Diagnostic Reference */}
        <Card className="p-3.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Safety Framework</span>
            <ShieldCheck className="w-3.5 h-3.5 text-sage" />
          </div>
          <div className="text-lg font-bold font-mono tracking-tight text-text-primary">
            EN 81-20
          </div>
          <div className="text-[11px] text-text-secondary">Simulated Baseline Rules</div>
        </Card>
      </div>

      {/* Main Grid: 3D Twin + Diagnostic Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 Cols: Digital Twin 3D Viewport */}
        <div className="lg:col-span-7 flex flex-col space-y-4">
          <Card className="p-0 overflow-hidden border-border flex flex-col h-[460px]">
            <div className="p-3 border-b border-border flex items-center justify-between bg-card">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-sage" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
                  Elevator 3D Digital Twin Preview
                </h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/digital-twin")}
                className="text-[11px] flex items-center gap-1"
              >
                Expand Twin
                <ArrowRight className="w-3 h-3" />
              </Button>
            </div>

            <div className="flex-1 w-full relative">
              <ModelViewer
                compactToolbar={true}
                showSimControls={false}
                showSubsystemStrip={false}
              />
            </div>
          </Card>

          {/* Quick Simulation Action Bar */}
          <Card className="p-3 flex flex-wrap items-center justify-between gap-3 bg-surface border-border">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-text-secondary font-mono">Quick Actions:</span>
              {running ? (
                <Button variant="amber" size="sm" onClick={pauseSimulation} className="flex items-center gap-1">
                  <Pause className="w-3 h-3" />
                  Pause Simulation
                </Button>
              ) : (
                <Button variant="primary" size="sm" onClick={startSimulation} className="flex items-center gap-1">
                  <Play className="w-3 h-3" />
                  Start Simulation
                </Button>
              )}
              <Button variant="secondary" size="sm" onClick={resetSimulation} className="flex items-center gap-1">
                <RotateCcw className="w-3 h-3" />
                Reset
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => navigate("/fault-lab")}
                className="text-xs"
              >
                Inject Fault
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => navigate("/investigation")}
                className="text-xs flex items-center gap-1"
              >
                Open Investigation
                <ArrowRight className="w-3 h-3" />
              </Button>
            </div>
          </Card>
        </div>

        {/* Right 5 Cols: Diagnostic Insights & Live Sensors */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          {/* Diagnostic RCA Summary Card */}
          <Card className="p-4 border-border space-y-3">
            <div className="flex items-center justify-between border-b border-border pb-2.5">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-sage" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
                  Diagnostic Failure Investigation
                </h3>
              </div>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-surface border border-border text-text-secondary">
                {activeFault ? "Active Incident" : "Nominal"}
              </span>
            </div>

            {activeFault && diagnostic?.hypotheses[0] ? (
              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-coral/10 border border-coral/30 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase font-bold text-coral">
                      Rank #1 Suspect: {affectedMeta?.label || activeFault.affectedComponent}
                    </span>
                    <span className="text-xs font-mono font-bold text-coral">
                      {Math.round(diagnostic.hypotheses[0].confidence * 100)}% Conf.
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-text-primary">
                    {diagnostic.hypotheses[0].description}
                  </p>
                </div>

                {diagnostic.hypotheses[0].evidence && (
                  <div className="bg-surface p-2.5 rounded-lg border border-border space-y-1">
                    <span className="text-[10px] font-mono uppercase text-text-muted">
                      Telemetry Evidence:
                    </span>
                    {diagnostic.hypotheses[0].evidence.slice(0, 2).map((ev, i) => (
                      <div key={i} className="text-[11px] text-text-secondary flex items-start gap-1">
                        <span className="text-coral">•</span>
                        <span>{ev}</span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => {
                      selectComponent(activeFault.affectedComponent);
                      navigate("/digital-twin");
                    }}
                    className="text-xs text-sage hover:underline flex items-center gap-1 font-medium"
                  >
                    Locate in 3D Twin &rarr;
                  </button>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => navigate("/investigation")}
                    className="text-xs"
                  >
                    Full RCA Details
                  </Button>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-sage mx-auto" />
                <p className="text-xs font-semibold text-text-primary">No Anomalies Detected</p>
                <p className="text-[11px] text-text-muted max-w-xs mx-auto">
                  All sub-systems are operating within normal baseline limits. Inject a fault scenario to evaluate multi-hypothesis root cause analysis.
                </p>
                <div className="pt-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => navigate("/fault-lab")}
                    className="text-xs"
                  >
                    Open Fault Lab
                  </Button>
                </div>
              </div>
            )}
          </Card>

          {/* Recent Event Timeline */}
          <Card className="p-4 border-border space-y-3 flex-1">
            <div className="flex items-center justify-between border-b border-border pb-2.5">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-text-secondary" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-text-primary">
                  Recent Engineering Events
                </h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/records")}
                className="text-[11px] text-text-muted hover:text-text-primary p-0 h-auto"
              >
                View Log &rarr;
              </Button>
            </div>

            <div className="space-y-2.5">
              {recentEvents.map((evt) => (
                <div
                  key={evt.id}
                  className="p-2.5 rounded-lg bg-surface border border-border flex items-start justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] text-text-muted">{evt.id}</span>
                      <span className="font-semibold text-text-primary truncate">{evt.component}</span>
                    </div>
                    <p className="text-[11px] text-text-secondary line-clamp-1">{evt.message}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase font-semibold ${
                        evt.severity === "fault"
                          ? "bg-coral/15 text-coral"
                          : "bg-sage/15 text-sage"
                      }`}
                    >
                      {evt.status}
                    </span>
                    <div className="text-[10px] text-text-muted mt-1 font-mono">{evt.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Live Sensor Summary Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-sage" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-text-primary">
              Live Sensor Telemetry Channels
            </h2>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/live-monitoring")}
            className="text-xs text-sage hover:underline"
          >
            Open Live Monitoring & Time-Series Charts &rarr;
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {Object.keys(sensors).map((key) => {
            const s = sensors[key];
            const latest = s.readings[s.readings.length - 1];
            const val = latest ? latest.value.toFixed(2) : "—";
            const isFault = s.status === "fault";
            const isWarning = s.status === "warning";

            return (
              <Card
                key={key}
                className={`p-3 space-y-1 transition-all ${
                  isFault ? "border-coral/50 bg-coral/5" : isWarning ? "border-amber-warm/50" : ""
                }`}
              >
                <div className="text-[11px] text-text-secondary truncate font-medium">{s.name}</div>
                <div
                  className={`text-base font-bold font-mono ${
                    isFault ? "text-coral" : isWarning ? "text-amber-warm" : "text-text-primary"
                  }`}
                >
                  {val}{" "}
                  <span className="text-[10px] font-sans font-normal text-text-muted">{s.unit}</span>
                </div>
                <div className="text-[10px] font-mono uppercase font-semibold text-text-muted">
                  {s.status}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Overview;
