// src/pages/GuidedInvestigation.tsx
import React, { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useElevatorStore, PRESET_FAULTS } from "../simulation/store";
import { useNavigate } from "react-router-dom";
import {
  Compass,
  CheckCircle2,
  Play,
  RotateCcw,
  AlertTriangle,
} from "lucide-react";

export const GuidedInvestigation: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);

  const running = useElevatorStore((s) => s.running);
  const startSimulation = useElevatorStore((s) => s.startSimulation);
  const activeFault = useElevatorStore((s) => s.activeFault);
  const injectFault = useElevatorStore((s) => s.injectFault);
  const clearFault = useElevatorStore((s) => s.clearFault);
  const diagnostic = useElevatorStore((s) => s.diagnostic);
  const sensors = useElevatorStore((s) => s.sensors);
  const maintenance = useElevatorStore((s) => s.maintenance);
  const startRepair = useElevatorStore((s) => s.startRepair);
  const submitForVerification = useElevatorStore((s) => s.submitForVerification);
  const verifyRepair = useElevatorStore((s) => s.verifyRepair);

  const steps = [
    {
      num: 1,
      title: "Establish Nominal Baseline",
      desc: "Verify that all 8 sensor channels are operating within ISO 18738 baseline limits.",
    },
    {
      num: 2,
      title: "Simulate Mechanical Degradation",
      desc: "Inject the Main Drive Bearing Degradation scenario into the shared simulation loop.",
    },
    {
      num: 3,
      title: "Detect Telemetry Anomalies",
      desc: "Inspect live sensor divergences (vibration spike > 0.15g and localized thermal elevation).",
    },
    {
      num: 4,
      title: "Review Diagnostic Hypotheses",
      desc: "Inspect explainable root-cause ranking, supporting vs. contradicting evidence, and causal chains.",
    },
    {
      num: 5,
      title: "Locate in 3D Digital Twin",
      desc: "Correlate the hypothesis with the physical 3D asset and conceptual spatial hotspot.",
    },
    {
      num: 6,
      title: "Execute Repair & Retest Verification",
      desc: "Dispatch technician, execute repair, and retest live sensors against recovery thresholds.",
    },
    {
      num: 7,
      title: "Seal Archival & Enforce Retention Gates",
      desc: "Generate the formal RCA report, confirm archival, verify backup, and test raw log purge gates.",
    },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Compass className="w-5 h-5 text-sage" />
            Guided Diagnostic Investigation Walkthrough
          </h1>
          <p className="text-xs text-text-secondary mt-0.5">
            Step-by-step end-to-end demonstration of the complete ELEVATOR-RCA research prototype workflow.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              clearFault();
              setCurrentStep(1);
            }}
            className="flex items-center gap-1.5 text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Restart Walkthrough
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate("/judge-demo")}
            className="text-xs font-semibold"
          >
            Open Judge Demo Mode &rarr;
          </Button>
        </div>
      </div>

      {/* Step Progress Tracker */}
      <Card className="p-4 border-border">
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2 text-center text-xs">
          {steps.map((st) => {
            const isCurrent = currentStep === st.num;
            const isCompleted = currentStep > st.num;

            return (
              <button
                key={st.num}
                onClick={() => setCurrentStep(st.num)}
                className={`p-2.5 rounded-lg border transition-all text-left flex flex-col justify-between ${
                  isCurrent
                    ? "bg-surface border-sage ring-1 ring-sage/30 shadow-subtle"
                    : isCompleted
                    ? "bg-sage/10 border-sage/30 text-sage"
                    : "bg-card border-border text-text-muted hover:border-border-strong"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-[10px]">STEP 0{st.num}</span>
                  {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-sage" />}
                </div>
                <div className="font-semibold text-[11px] text-text-primary mt-1 line-clamp-1">
                  {st.title}
                </div>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Active Step Panel */}
      <Card className="p-6 border-border space-y-6">
        <div className="border-b border-border pb-4 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sage">
              Step {currentStep} of 7
            </span>
            <h2 className="text-lg font-bold text-text-primary">
              {steps[currentStep - 1].title}
            </h2>
            <p className="text-xs text-text-secondary">
              {steps[currentStep - 1].desc}
            </p>
          </div>
        </div>

        {/* STEP 1: Baseline */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              Begin by observing the elevator in nominal operation. Telemetry runs within baseline limits (Vibration: 0.04g, Motor Temp: 42°C, Current: 12.5A).
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {Object.entries(sensors).slice(0, 4).map(([name, s]) => (
                <div key={name} className="p-3 rounded-lg bg-surface border border-border">
                  <span className="text-[10px] font-mono text-text-muted">{name}</span>
                  <div className="text-base font-bold font-mono text-text-primary mt-1">
                    {s.readings.slice(-1)[0]?.value.toFixed(2)} {s.unit}
                  </div>
                  <span className="text-[9px] font-mono uppercase text-sage font-semibold">Nominal</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex items-center gap-3">
              {!running && (
                <Button variant="primary" size="sm" onClick={startSimulation} className="flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5" /> Start Telemetry Stream
                </Button>
              )}
              <Button variant="secondary" size="sm" onClick={() => setCurrentStep(2)}>
                Proceed to Fault Injection &rarr;
              </Button>
            </div>
          </div>
        )}

        {/* STEP 2: Fault Injection */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              Inject the <strong>Main Drive Bearing Degradation</strong> fault. This applies calibrated delta increases to vibration (+0.14g) and motor temperature (+16.5°C).
            </p>

            <div className="p-4 rounded-xl bg-surface border border-border flex items-center justify-between">
              <div>
                <div className="font-bold text-text-primary text-sm">Main Drive Bearing Degradation</div>
                <div className="text-xs text-text-secondary mt-0.5">Affected Component: bearing_main</div>
              </div>
              <Button
                variant={activeFault?.id === "scenario_bearing_degradation" ? "secondary" : "danger"}
                size="sm"
                onClick={() => injectFault(PRESET_FAULTS.bearing_degradation)}
              >
                {activeFault?.id === "scenario_bearing_degradation" ? "Fault Active in Engine" : "Inject Bearing Degradation"}
              </Button>
            </div>

            {activeFault && (
              <div className="p-3 rounded-lg bg-coral/15 border border-coral/30 text-coral text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Active incident reported to maintenance engine: {activeFault.name}</span>
              </div>
            )}

            <div className="pt-2 flex justify-between">
              <Button variant="ghost" size="sm" onClick={() => setCurrentStep(1)}>&larr; Back</Button>
              <Button variant="secondary" size="sm" onClick={() => setCurrentStep(3)}>Next: Observe Anomalies &rarr;</Button>
            </div>
          </div>
        )}

        {/* STEP 3: Observe Anomalies */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              Observe how the shared engine automatically updates the sensor status from Normal to Warning / Fault.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-lg bg-coral/10 border border-coral/30 text-coral space-y-1">
                <span className="text-[10px] font-mono uppercase font-bold">Vibration (g)</span>
                <div className="text-xl font-bold font-mono">
                  {sensors["Vibration"]?.readings.slice(-1)[0]?.value.toFixed(3)} g
                </div>
                <div className="text-[11px] text-coral font-medium">Critical Limit Tripped (&ge; 0.15g)</div>
              </div>

              <div className="p-3.5 rounded-lg bg-amber-warm/10 border border-amber-warm/30 text-amber-warm space-y-1">
                <span className="text-[10px] font-mono uppercase font-bold">Motor Temperature (°C)</span>
                <div className="text-xl font-bold font-mono">
                  {sensors["Motor Temperature"]?.readings.slice(-1)[0]?.value.toFixed(1)} °C
                </div>
                <div className="text-[11px] text-amber-warm font-medium">Warning Threshold Tripped (&ge; 55°C)</div>
              </div>
            </div>

            <div className="pt-2 flex justify-between">
              <Button variant="ghost" size="sm" onClick={() => setCurrentStep(2)}>&larr; Back</Button>
              <Button variant="secondary" size="sm" onClick={() => setCurrentStep(4)}>Next: Review Hypotheses &rarr;</Button>
            </div>
          </div>
        )}

        {/* STEP 4: Diagnostic Hypotheses */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              The explainable diagnostic pipeline has analyzed the correlated symptoms and ranked the candidate causes:
            </p>

            {diagnostic?.hypotheses && diagnostic.hypotheses.length > 0 ? (
              <div className="space-y-3">
                {diagnostic.hypotheses.slice(0, 2).map((hyp) => (
                  <div key={hyp.id} className="p-3.5 rounded-lg bg-surface border border-border space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-text-primary">Rank #{hyp.rank}: {hyp.title}</span>
                      <span className="text-xs font-mono font-bold text-coral">
                        {Math.round(hyp.confidence * 100)}% Conf.
                      </span>
                    </div>
                    <p className="text-xs text-text-secondary">{hyp.description}</p>
                    <div className="text-[11px] text-text-muted font-mono">{hyp.relevantRule}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded bg-surface text-xs text-text-muted">Inject fault to see hypotheses.</div>
            )}

            <div className="pt-2 flex justify-between">
              <Button variant="ghost" size="sm" onClick={() => setCurrentStep(3)}>&larr; Back</Button>
              <Button variant="secondary" size="sm" onClick={() => setCurrentStep(5)}>Next: Locate in 3D Twin &rarr;</Button>
            </div>
          </div>
        )}

        {/* STEP 5: Digital Twin */}
        {currentStep === 5 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              Inspect the physical asset mapping. The GLB model consists of a single unified mesh (<code>Mesh</code>), so the application maps the suspect component to a calibrated 3D conceptual hotspot.
            </p>

            <div className="p-4 rounded-xl bg-surface border border-border space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-text-primary">Target Hotspot: Main Drive Bearing</span>
                <span className="text-sage font-mono font-bold">[0.45, 1.85, 0.2]</span>
              </div>
              <p className="text-text-secondary text-[11px]">
                Highlighted with pulsing red/amber targeting beacon in the 3D viewport.
              </p>
            </div>

            <div className="pt-2 flex justify-between">
              <Button variant="ghost" size="sm" onClick={() => setCurrentStep(4)}>&larr; Back</Button>
              <Button variant="secondary" size="sm" onClick={() => setCurrentStep(6)}>Next: Repair & Retest &rarr;</Button>
            </div>
          </div>
        )}

        {/* STEP 6: Repair & Retest */}
        {currentStep === 6 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              Follow the 10-state maintenance workflow: dispatch technician, record repair procedure, and execute a live retest to evaluate recovery against target criteria.
            </p>

            <div className="p-4 rounded-xl bg-surface border border-border space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-text-secondary">Current Workflow State:</span>
                <span className="font-mono font-bold text-sage uppercase px-2 py-0.5 rounded bg-card border border-border">
                  {maintenance.state}
                </span>
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => startRepair("M. Vance (Lead Tech)", "Flush bearing cartridge and replenish synthetic lubricant.")}
                >
                  1. Start Repair Work
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => submitForVerification("M. Vance (Lead Tech)")}
                >
                  2. Submit for Verification
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => verifyRepair("N. Topson (Lead PE)", false)}
                >
                  3. Execute Retest & Verify
                </Button>
              </div>
            </div>

            <div className="pt-2 flex justify-between">
              <Button variant="ghost" size="sm" onClick={() => setCurrentStep(5)}>&larr; Back</Button>
              <Button variant="secondary" size="sm" onClick={() => setCurrentStep(7)}>Next: Archival & Retention Gates &rarr;</Button>
            </div>
          </div>
        )}

        {/* STEP 7: Retention Gates */}
        {currentStep === 7 && (
          <div className="space-y-4">
            <p className="text-xs text-text-secondary leading-relaxed">
              Verify the strict retention gates: raw log cleanup is rejected until repair is verified, archival is sealed, and backup is confirmed.
            </p>

            <div className="p-4 rounded-xl bg-surface border border-border space-y-3 text-xs">
              <div className="font-bold text-text-primary">Storage Gating Controls:</div>
              <div className="flex flex-wrap gap-2">
                <Button variant="secondary" size="sm" onClick={() => useElevatorStore.getState().requestArchival()}>
                  Request Archival
                </Button>
                <Button variant="secondary" size="sm" onClick={() => useElevatorStore.getState().confirmArchival()}>
                  Confirm Archival
                </Button>
                <Button variant="secondary" size="sm" onClick={() => useElevatorStore.getState().verifyBackup()}>
                  Verify Backup
                </Button>
                <Button variant="primary" size="sm" onClick={() => {
                  const res = useElevatorStore.getState().executeRawLogCleanup();
                  alert(res.message);
                }}>
                  Test Raw Log Purge Gate
                </Button>
              </div>
            </div>

            <div className="pt-4 border-t border-border flex items-center justify-between">
              <Button variant="ghost" size="sm" onClick={() => setCurrentStep(6)}>&larr; Back</Button>
              <div className="flex items-center gap-2">
                <Button variant="secondary" size="sm" onClick={() => navigate("/report")}>
                  View Full Report
                </Button>
                <Button variant="primary" size="sm" onClick={() => navigate("/overview")}>
                  Return to Dashboard
                </Button>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default GuidedInvestigation;
