-- ==============================================================================
-- ELEVATOR-RCA: Industrial Telemetry & Causal Diagnostics Supabase Schema
-- Migration: 20261019000000_create_profiles_and_rca_tables.sql
-- ==============================================================================

-- 1. PROFILES TABLE (Linked 1:1 with auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role TEXT NOT NULL DEFAULT 'field_technician' 
    CHECK (role IN ('lead_pe', 'field_technician', 'admin', 'apprentice')),
  badge_number TEXT,
  certifications JSONB NOT NULL DEFAULT '[]'::jsonb,
  authorized_assets JSONB NOT NULL DEFAULT '["ELEV-01"]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Index for RLS and role lookup
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles RLS Policies: Authenticated users can view profiles and edit their own
CREATE POLICY "Authenticated users can view profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

-- Trigger function to automatically create public.profiles on new auth.users signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    full_name,
    role,
    badge_number,
    certifications,
    authorized_assets
  )
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    COALESCE(new.raw_user_meta_data->>'role', 'field_technician'),
    COALESCE(new.raw_user_meta_data->>'badge_number', 'TECH-' || substr(new.id::text, 1, 6)),
    COALESCE(new.raw_user_meta_data->'certifications', '["ASME A17.1", "QEI-1"]'::jsonb),
    COALESCE(new.raw_user_meta_data->'authorized_assets', '["ELEV-01"]'::jsonb)
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(EXCLUDED.full_name, public.profiles.full_name),
    role = COALESCE(EXCLUDED.role, public.profiles.role),
    updated_at = timezone('utc'::text, now());
  RETURN new;
END;
$$;

-- Drop existing trigger if already present before recreation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- 2. ELEVATOR ASSETS TABLE
CREATE TABLE IF NOT EXISTS public.elevator_assets (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  model_name TEXT NOT NULL DEFAULT 'Traction MRL v2.4 (Simulated)',
  building_name TEXT NOT NULL DEFAULT 'Tech Tower 4',
  floors_served INTEGER NOT NULL DEFAULT 6,
  status TEXT NOT NULL DEFAULT 'NORMAL_OPERATION',
  rated_speed_mps NUMERIC(4,2) NOT NULL DEFAULT 2.50,
  capacity_kg INTEGER NOT NULL DEFAULT 1600,
  installed_year INTEGER NOT NULL DEFAULT 2024,
  last_inspection_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.elevator_assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view elevator assets"
  ON public.elevator_assets
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Certified personnel can update asset status"
  ON public.elevator_assets
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Pre-seed default Elevator-01 asset
INSERT INTO public.elevator_assets (id, name, model_name, building_name, floors_served, status)
VALUES (
  'ELEV-01',
  'Elevator Car 1 (Main Hoistway)',
  'Traction MRL - Dual-Door Telescopic (GLB v2)',
  'Industrial Tower Alpha',
  6,
  'NORMAL_OPERATION'
)
ON CONFLICT (id) DO NOTHING;


-- 3. MAINTENANCE WORK ORDERS TABLE
CREATE TABLE IF NOT EXISTS public.maintenance_work_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  work_order_id TEXT NOT NULL UNIQUE,
  asset_id TEXT NOT NULL REFERENCES public.elevator_assets(id) ON DELETE RESTRICT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  technician_name TEXT NOT NULL,
  technician_role TEXT NOT NULL DEFAULT 'field_technician',
  incident_id TEXT,
  subsystem TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'open'
    CHECK (status IN ('open', 'in_progress', 'awaiting_verification', 'completed', 'cancelled')),
  priority TEXT NOT NULL DEFAULT 'MEDIUM'
    CHECK (priority IN ('CRITICAL', 'HIGH', 'MEDIUM', 'ROUTINE')),
  inspection_steps JSONB NOT NULL DEFAULT '[]'::jsonb,
  parts_replaced JSONB NOT NULL DEFAULT '[]'::jsonb,
  technician_notes TEXT,
  before_values JSONB NOT NULL DEFAULT '{}'::jsonb,
  after_values JSONB NOT NULL DEFAULT '{}'::jsonb,
  target_thresholds JSONB NOT NULL DEFAULT '{}'::jsonb,
  verification_passed BOOLEAN DEFAULT FALSE,
  verified_at TIMESTAMPTZ,
  verified_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Foreign key & query indexes
CREATE INDEX IF NOT EXISTS idx_work_orders_asset_id ON public.maintenance_work_orders(asset_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_user_id ON public.maintenance_work_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON public.maintenance_work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_incident_id ON public.maintenance_work_orders(incident_id);

ALTER TABLE public.maintenance_work_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view work orders"
  ON public.maintenance_work_orders
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create work orders"
  ON public.maintenance_work_orders
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update work orders"
  ON public.maintenance_work_orders
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);


-- 4. DIAGNOSTIC RECORDS & CAUSAL EVIDENCE TABLE
CREATE TABLE IF NOT EXISTS public.diagnostic_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id TEXT NOT NULL REFERENCES public.elevator_assets(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  technician_name TEXT,
  fault_scenario_id TEXT NOT NULL,
  fault_title TEXT NOT NULL,
  subsystem TEXT NOT NULL,
  primary_cause TEXT NOT NULL,
  confidence NUMERIC(5,2) NOT NULL,
  evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
  sensor_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  repair_recommendations JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_diagnostics_asset_id ON public.diagnostic_records(asset_id);
CREATE INDEX IF NOT EXISTS idx_diagnostics_user_id ON public.diagnostic_records(user_id);
CREATE INDEX IF NOT EXISTS idx_diagnostics_fault_scenario ON public.diagnostic_records(fault_scenario_id);
CREATE INDEX IF NOT EXISTS idx_diagnostics_created_at ON public.diagnostic_records(created_at DESC);

ALTER TABLE public.diagnostic_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view diagnostics"
  ON public.diagnostic_records
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert diagnostics"
  ON public.diagnostic_records
  FOR INSERT
  TO authenticated
  WITH CHECK (true);


-- 5. AUDIT TRAIL / AUDIT EVENTS TABLE
CREATE TABLE IF NOT EXISTS public.audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id TEXT REFERENCES public.elevator_assets(id) ON DELETE SET NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_name TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  from_state TEXT,
  to_state TEXT,
  evidence TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_audit_events_user_id ON public.audit_events(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_asset_id ON public.audit_events(asset_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_timestamp ON public.audit_events(timestamp DESC);

ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view audit events"
  ON public.audit_events
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can record audit events"
  ON public.audit_events
  FOR INSERT
  TO authenticated
  WITH CHECK (true);


-- 6. GRANT MINIMAL SPECIFIC PRIVILEGES TO authenticated AND anon ROLES
GRANT USAGE ON SCHEMA public TO authenticated, anon;

GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;

GRANT SELECT, UPDATE, INSERT ON public.elevator_assets TO authenticated;
GRANT SELECT ON public.elevator_assets TO anon;

GRANT SELECT, INSERT, UPDATE ON public.maintenance_work_orders TO authenticated;
GRANT SELECT ON public.maintenance_work_orders TO anon;

GRANT SELECT, INSERT ON public.diagnostic_records TO authenticated;
GRANT SELECT ON public.diagnostic_records TO anon;

GRANT SELECT, INSERT ON public.audit_events TO authenticated;
GRANT SELECT ON public.audit_events TO anon;

