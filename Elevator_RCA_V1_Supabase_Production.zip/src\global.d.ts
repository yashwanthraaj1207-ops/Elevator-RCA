/// <reference types="vite/client" />
/// <reference types="@react-three/fiber" />

declare const process: {
  env: Record<string, string | undefined>;
};
