// src/lib/syncService.ts
/**
 * Offline-Resilient Cloud Synchronization Service for Elevator-RCA.
 *
 * Automatically captures maintenance work orders, audit events, and diagnostic logs.
 * When online, commits transactions directly to Supabase cloud tables.
 * When offline, persists events in a tamper-resistant local queue and drains
 * automatically when connectivity is restored.
 */

import { supabase, isSupabaseConfigured } from "./supabase";
import type { MaintenanceWorkOrder, MaintenanceAuditEntry } from "../simulation/maintenance";

export interface SyncQueueItem {
  id: string;
  type: "work_order" | "audit_event" | "diagnostic_record";
  payload: any;
  createdAt: string;
  retryCount: number;
  lastError?: string;
}

const SYNC_QUEUE_KEY = "elevator_rca_sync_queue";

class SyncService {
  private queue: SyncQueueItem[] = [];
  private isFlushing = false;

  constructor() {
    this.loadQueue();
    if (typeof window !== "undefined") {
      window.addEventListener("online", () => {
        console.log("[SyncService] Network restored. Initiating sync flush...");
        this.flushQueue();
      });
    }
  }

  private loadQueue(): void {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(SYNC_QUEUE_KEY);
      if (raw) {
        this.queue = JSON.parse(raw);
      }
    } catch (err) {
      console.warn("[SyncService] Failed to load offline sync queue:", err);
      this.queue = [];
    }
  }

  private persistQueue(): void {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(this.queue));
    } catch (err) {
      console.error("[SyncService] Failed to persist offline queue to localStorage:", err);
    }
  }

  public getPendingCount(): number {
    return this.queue.length;
  }

  public enqueue(type: SyncQueueItem["type"], payload: any): void {
    const item: SyncQueueItem = {
      id: `queue-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      type,
      payload,
      createdAt: new Date().toISOString(),
      retryCount: 0,
    };
    this.queue.push(item);
    this.persistQueue();

    // If online, attempt immediate flush
    if (typeof navigator !== "undefined" && navigator.onLine) {
      this.flushQueue();
    }
  }

  public async pushWorkOrderToCloud(
    order: MaintenanceWorkOrder,
    userId?: string
  ): Promise<{ success: boolean; queued: boolean; error?: string }> {
    if (!isSupabaseConfigured || (typeof navigator !== "undefined" && !navigator.onLine)) {
      this.enqueue("work_order", { order, userId });
      return { success: true, queued: true };
    }

    try {
      const { error } = await supabase.from("maintenance_work_orders").upsert(
        {
          work_order_id: order.id,
          asset_id: "ELEV-01",
          user_id: userId || null,
          technician_name: order.assignedTechnician || "Field Technician",
          incident_id: order.incidentId,
          subsystem: order.subsystem,
          title: order.title,
          description: order.description,
          status: order.status,
          priority: order.priority,
          inspection_steps: order.inspectionSteps || [],
          parts_replaced: order.partsReplaced || [],
          technician_notes: order.technicianNotes || "",
          before_values: order.beforeValues || {},
          after_values: order.afterValues || {},
          target_thresholds: order.targetThresholds || {},
          verification_passed: order.verificationPassed ?? false,
          verified_at: order.verifiedAt || null,
          verified_by: order.verifiedBy || null,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "work_order_id" }
      );

      if (error) throw error;
      return { success: true, queued: false };
    } catch (err: any) {
      console.warn("[SyncService] Cloud work order sync failed, enqueueing:", err?.message || err);
      this.enqueue("work_order", { order, userId });
      return { success: true, queued: true, error: err?.message };
    }
  }

  public async pushAuditEntryToCloud(
    entry: MaintenanceAuditEntry,
    userId?: string,
    assetId: string = "ELEV-01"
  ): Promise<{ success: boolean; queued: boolean; error?: string }> {
    if (!isSupabaseConfigured || (typeof navigator !== "undefined" && !navigator.onLine)) {
      this.enqueue("audit_event", { entry, userId, assetId });
      return { success: true, queued: true };
    }

    try {
      const { error } = await supabase.from("audit_events").insert({
        asset_id: assetId,
        user_id: userId || null,
        actor_name: entry.actor,
        actor_role: entry.actor.includes("Lead") ? "lead_pe" : "field_technician",
        action: entry.action,
        from_state: entry.fromState,
        to_state: entry.toState,
        evidence: entry.evidence,
        timestamp: entry.timestamp,
      });

      if (error) throw error;
      return { success: true, queued: false };
    } catch (err: any) {
      console.warn("[SyncService] Cloud audit sync failed, enqueueing:", err?.message || err);
      this.enqueue("audit_event", { entry, userId, assetId });
      return { success: true, queued: true, error: err?.message };
    }
  }

  public async pushDiagnosticRecordToCloud(
    record: {
      faultScenarioId: string;
      faultTitle: string;
      subsystem: string;
      primaryCause: string;
      confidence: number;
      evidence: any[];
      sensorSnapshot: Record<string, any>;
      repairRecommendations?: string[];
      technicianName?: string;
    },
    userId?: string,
    assetId: string = "ELEV-01"
  ): Promise<{ success: boolean; queued: boolean; error?: string }> {
    if (!isSupabaseConfigured || (typeof navigator !== "undefined" && !navigator.onLine)) {
      this.enqueue("diagnostic_record", { record, userId, assetId });
      return { success: true, queued: true };
    }

    try {
      const { error } = await supabase.from("diagnostic_records").insert({
        asset_id: assetId,
        user_id: userId || null,
        technician_name: record.technicianName || "Certified Investigator",
        fault_scenario_id: record.faultScenarioId,
        fault_title: record.faultTitle,
        subsystem: record.subsystem,
        primary_cause: record.primaryCause,
        confidence: record.confidence,
        evidence: record.evidence || [],
        sensor_snapshot: record.sensorSnapshot || {},
        repair_recommendations: record.repairRecommendations || [],
      });

      if (error) throw error;
      return { success: true, queued: false };
    } catch (err: any) {
      console.warn("[SyncService] Cloud diagnostic sync failed, enqueueing:", err?.message || err);
      this.enqueue("diagnostic_record", { record, userId, assetId });
      return { success: true, queued: true, error: err?.message };
    }
  }

  public async flushQueue(): Promise<{ processed: number; remaining: number }> {
    if (this.isFlushing || this.queue.length === 0 || !isSupabaseConfigured) {
      return { processed: 0, remaining: this.queue.length };
    }

    if (typeof navigator !== "undefined" && !navigator.onLine) {
      return { processed: 0, remaining: this.queue.length };
    }

    this.isFlushing = true;
    let processed = 0;
    const itemsToProcess = [...this.queue];

    for (const item of itemsToProcess) {
      try {
        if (item.type === "work_order") {
          const { order, userId } = item.payload;
          const { error } = await supabase.from("maintenance_work_orders").upsert(
            {
              work_order_id: order.id,
              asset_id: "ELEV-01",
              user_id: userId || null,
              technician_name: order.assignedTechnician || "Field Technician",
              incident_id: order.incidentId,
              subsystem: order.subsystem,
              title: order.title,
              description: order.description,
              status: order.status,
              priority: order.priority,
              inspection_steps: order.inspectionSteps || [],
              parts_replaced: order.partsReplaced || [],
              technician_notes: order.technicianNotes || "",
              before_values: order.beforeValues || {},
              after_values: order.afterValues || {},
              target_thresholds: order.targetThresholds || {},
              verification_passed: order.verificationPassed ?? false,
              verified_at: order.verifiedAt || null,
              verified_by: order.verifiedBy || null,
              updated_at: new Date().toISOString(),
            },
            { onConflict: "work_order_id" }
          );
          if (error) throw error;
        } else if (item.type === "audit_event") {
          const { entry, userId, assetId } = item.payload;
          const { error } = await supabase.from("audit_events").insert({
            asset_id: assetId || "ELEV-01",
            user_id: userId || null,
            actor_name: entry.actor,
            actor_role: entry.actor?.includes("Lead") ? "lead_pe" : "field_technician",
            action: entry.action,
            from_state: entry.fromState,
            to_state: entry.toState,
            evidence: entry.evidence,
            timestamp: entry.timestamp,
          });
          if (error) throw error;
        } else if (item.type === "diagnostic_record") {
          const { record, userId, assetId } = item.payload;
          const { error } = await supabase.from("diagnostic_records").insert({
            asset_id: assetId || "ELEV-01",
            user_id: userId || null,
            technician_name: record.technicianName || "Certified Investigator",
            fault_scenario_id: record.faultScenarioId,
            fault_title: record.faultTitle,
            subsystem: record.subsystem,
            primary_cause: record.primaryCause,
            confidence: record.confidence,
            evidence: record.evidence || [],
            sensor_snapshot: record.sensorSnapshot || {},
            repair_recommendations: record.repairRecommendations || [],
          });
          if (error) throw error;
        }

        // Successfully synced — remove item from queue
        this.queue = this.queue.filter((q) => q.id !== item.id);
        processed++;
      } catch (err: any) {
        console.warn(`[SyncService] Retry failed for queue item ${item.id}:`, err?.message || err);
        item.retryCount = (item.retryCount || 0) + 1;
        item.lastError = err?.message || String(err);
        // Break to avoid hammering rate limit if offline
        break;
      }
    }

    this.persistQueue();
    this.isFlushing = false;
    return { processed, remaining: this.queue.length };
  }
}

export const syncService = new SyncService();

