// src/simulation/floors.ts
/**
 * Configurable Floor System for ELEVATOR-RCA Prototype.
 * Provides:
 * - 12 configurable floors (Ground, 1, 2, ... 11)
 * - Deterministic physical metrics: height per floor (3.2m), floor elevations
 * - Passenger floor queue / call requests
 * - Ground floor return command
 * - Motion phase simulation (acceleration, nominal cruise, deceleration, leveling, door cycle)
 *
 * NOTE: This is a research simulation prototype, not a physically certified controller.
 */

export interface FloorDefinition {
  index: number; // 0 to 11
  label: string; // "G", "1", "2", ... "11"
  displayName: string; // "Ground Floor", "Floor 1", etc.
  elevation: number; // meters from pit (index * 3.2m)
  isGround: boolean;
}

export const DEFAULT_TOTAL_FLOORS = 12;
export const FLOOR_HEIGHT_METERS = 3.2; // 12 floors * 3.2m = 35.2m total shaft travel

export function generateFloors(count: number = DEFAULT_TOTAL_FLOORS): FloorDefinition[] {
  const floors: FloorDefinition[] = [];
  for (let i = 0; i < count; i++) {
    const isGround = i === 0;
    floors.push({
      index: i,
      label: isGround ? "G" : `${i}`,
      displayName: isGround ? "Ground Floor (Lobby)" : `Floor ${i}`,
      elevation: Number((i * FLOOR_HEIGHT_METERS).toFixed(2)),
      isGround,
    });
  }
  return floors;
}

export const PRESET_FLOORS: FloorDefinition[] = generateFloors(12);

export type DoorState = "CLOSED" | "OPENING" | "OPEN" | "CLOSING";
export type TravelPhase = "IDLE" | "ACCELERATING" | "CRUISING" | "DECELERATING" | "LEVELING";

export interface FloorNavigationState {
  currentFloorIndex: number;
  targetFloorIndex: number;
  callQueue: number[]; // Floor indices requested by passengers
  doorState: DoorState;
  doorProgress: number; // 0 (closed) to 1 (fully open)
  travelPhase: TravelPhase;
  serviceAvailable: boolean; // false during critical fault or unverified maintenance
  groundReturnInProgress: boolean;
  totalFloors: number;
}

export const INITIAL_FLOOR_NAV_STATE: FloorNavigationState = {
  currentFloorIndex: 0,
  targetFloorIndex: 0,
  callQueue: [],
  doorState: "CLOSED",
  doorProgress: 0,
  travelPhase: "IDLE",
  serviceAvailable: true,
  groundReturnInProgress: false,
  totalFloors: 12,
};

