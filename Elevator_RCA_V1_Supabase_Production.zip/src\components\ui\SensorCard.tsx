// src/components/ui/SensorCard.tsx
import React from "react";
import { Card } from "./Card";
import { useElevatorStore } from "../../simulation/store";
import { Activity } from "lucide-react";

interface Props {
  sensorKey: string;
}

export const SensorCard: React.FC<Props> = ({ sensorKey }) => {
  const sensor = useElevatorStore((state) => state.sensors[sensorKey]);

  if (!sensor) return null;

  const latest = sensor.readings[sensor.readings.length - 1];
  const value = latest ? latest.value.toFixed(2) : "—";

  const isFault = sensor.status === "fault";
  const isWarning = sensor.status === "warning";

  const valueColor = isFault
    ? "text-coral"
    : isWarning
    ? "text-amber-warm"
    : "text-text-primary";

  const borderClass = isFault
    ? "border-coral/40"
    : isWarning
    ? "border-amber-warm/40"
    : "border-border";

  return (
    <Card className={`p-3.5 transition-all hover:border-border-strong ${borderClass}`}>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-medium text-text-secondary truncate max-w-[140px]">
          {sensor.name}
        </span>
        <Activity
          className={`w-3.5 h-3.5 ${
            isFault ? "text-coral animate-pulse" : isWarning ? "text-amber-warm" : "text-sage"
          }`}
        />
      </div>

      <div className="flex items-baseline justify-between mt-2">
        <div className={`text-xl font-bold font-mono tracking-tight ${valueColor}`}>
          {value}
          <span className="text-xs font-sans font-normal text-text-muted ml-1">
            {sensor.unit}
          </span>
        </div>

        <span
          className={`text-[10px] font-mono px-1.5 py-0.5 rounded uppercase font-semibold ${
            isFault
              ? "bg-coral/15 text-coral"
              : isWarning
              ? "bg-amber-warm/15 text-amber-warm"
              : "bg-sage/15 text-sage"
          }`}
        >
          {sensor.status}
        </span>
      </div>
    </Card>
  );
};

export default SensorCard;
